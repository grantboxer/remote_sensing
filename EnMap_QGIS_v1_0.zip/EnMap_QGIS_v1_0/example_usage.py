"""
Example Usage Script for EnMAP Processor Plugin

This script demonstrates how to use the EnMAP Processor programmatically
from the QGIS Python console or in a custom script.
"""

from qgis.core import QgsProcessingFeedback
from qgis import processing

# Define your parameters
params = {
    'select_enmap_xml': '/path/to/your/ENMAP-METADATA.XML',
    'select_directory': '/path/to/output/directory',
    'output_prefix': 'MyScene'
}

# Create a feedback object to monitor progress
feedback = QgsProcessingFeedback()

# Run the algorithm
result = processing.run(
    "enmapprocessor:enmap_spectral_indices_full",
    params,
    feedback=feedback
)

print("Processing complete!")
print("Results:", result)

# Alternative: Using the algorithm directly
from enmap_processor_plugin.enmap_processing_algorithm_full import EnMapProcessingAlgorithm

# Create algorithm instance
alg = EnMapProcessingAlgorithm()

# Initialize it
alg.initAlgorithm()

# Create a context
from qgis.core import QgsProcessingContext
context = QgsProcessingContext()

# Run the algorithm
results = alg.processAlgorithm(params, context, feedback)

print("Direct processing complete!")
