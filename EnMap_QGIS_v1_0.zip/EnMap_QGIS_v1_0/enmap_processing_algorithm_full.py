"""
EnMAP Processing Algorithm - Full Implementation
Processes EnMAP hyperspectral satellite imagery and generates spectral indices
"""

from typing import Any, Optional
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterString,
    QgsProcessingParameterFile,
    QgsProcessingParameterFolderDestination,
    QgsExpression
)
from qgis import processing


class EnMapProcessingAlgorithm(QgsProcessingAlgorithm):
    """
    Full EnMAP processing algorithm with all 119 steps
    """
    
    # Parameter names
    OUTPUT_PREFIX = 'output_prefix'
    OUTPUT_DIRECTORY = 'select_directory'
    ENMAP_XML = 'select_enmap_xml'
    
    def tr(self, string):
        """Translate string"""
        return QCoreApplication.translate('Processing', string)
    
    def createInstance(self):
        """Create a new instance of the algorithm"""
        return EnMapProcessingAlgorithm()
    
    def name(self):
        """Algorithm name"""
        return 'enmap_spectral_indices_full'
    
    def displayName(self):
        """Display name for the algorithm"""
        return self.tr('EnMap_processing')
    
    def group(self):
        """Algorithm group"""
        return self.tr('')
    
    def groupId(self):
        """Group ID"""
        return ''
    
    def shortHelpString(self):
        """Help string"""
        return self.tr("""
        Process EnMAP L2A hyperspectral satellite imagery to generate spectral indices.
        
        This algorithm:
        - Imports EnMAP L2A products (without excluding bad bands)
        - Calculates multiple mineral and alteration indices
        - Generates RGB composite images
        - Exports all results as GeoTIFF files
        - Loads results into the current QGIS project
        
        Input: EnMAP L2A metadata XML file
        Output: Multiple spectral index rasters saved to specified directory
        
        Progress: 119 processing steps with detailed progress tracking
        """)

    def initAlgorithm(self, config: Optional[dict[str, Any]] = None):
        """Initialize algorithm parameters"""
        # EnMAP XML file input
        self.addParameter(
            QgsProcessingParameterFile(
                self.ENMAP_XML,
                self.tr('EnMAP L2A Metadata XML File'),
                behavior=QgsProcessingParameterFile.File,
                fileFilter='XML Files (*.xml *.XML);;All Files (*.*)',
                defaultValue=None
            )
        )
        
        # Output directory
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_DIRECTORY,
                self.tr('Output Directory'),
                defaultValue=None
            )
        )
        
        # Output file prefix
        self.addParameter(
            QgsProcessingParameterString(
                self.OUTPUT_PREFIX,
                self.tr('Output File Prefix'),
                multiLine=False,
                defaultValue='EnMAP'
            )
        )

    def processAlgorithm(self, parameters: dict[str, Any], context: QgsProcessingContext, model_feedback: QgsProcessingFeedback) -> dict[str, Any]:
        """Execute the processing algorithm"""
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(119, model_feedback)
        results = {}
        outputs = {}
        
        # Get parameters
        xml_file = self.parameterAsFile(parameters, self.ENMAP_XML, context)
        output_dir = self.parameterAsFile(parameters, self.OUTPUT_DIRECTORY, context)
        output_prefix = self.parameterAsString(parameters, self.OUTPUT_PREFIX, context)
        
        feedback.pushInfo("=" * 60)
        feedback.pushInfo("EnMAP Hyperspectral Processing Started")
        feedback.pushInfo("=" * 60)
        feedback.pushInfo(f"Input XML: {xml_file}")
        feedback.pushInfo(f"Output Directory: {output_dir}")
        feedback.pushInfo(f"Output Prefix: {output_prefix}")
        feedback.pushInfo("=" * 60)

        # Import EnMAP L2A - DIRECT GDAL APPROACH
        feedback.pushInfo("Step 1/119: Importing EnMAP L2A product...")
        feedback.pushInfo("Using direct GDAL import to ensure all 224 bands are loaded")
        
        # Parse the XML to find the SPECTRAL_IMAGE file
        import os
        import xml.etree.ElementTree as ET
        
        try:
            tree = ET.parse(xml_file)
            root = tree.getroot()
            
            # Find the spectral image file reference in the XML
            spectral_image_file = None
            xml_dir = os.path.dirname(xml_file)
            
            # Look for SPECTRAL_IMAGE file in the same directory
            for file in os.listdir(xml_dir):
                if 'SPECTRAL_IMAGE' in file and file.endswith('.TIF'):
                    spectral_image_file = os.path.join(xml_dir, file)
                    break
            
            if not spectral_image_file:
                feedback.reportError("Could not find SPECTRAL_IMAGE.TIF file")
                return {}
            
            feedback.pushInfo(f"Found spectral image: {os.path.basename(spectral_image_file)}")
            
            # Open directly with GDAL (bypassing EnMAP-Box import)
            from osgeo import gdal
            ds = gdal.Open(spectral_image_file)
            if ds is None:
                feedback.reportError(f"Could not open {spectral_image_file}")
                return {}
            
            band_count = ds.RasterCount
            feedback.pushInfo(f"✓ Direct GDAL import: {band_count} bands detected")
            ds = None  # Close the dataset
            
            # Now use the file path directly for processing
            outputs['ImportEnmapL2a'] = {'outputEnmapL2ARaster': spectral_image_file}
            
        except Exception as e:
            feedback.reportError(f"Error during import: {str(e)}")
            return {}

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}
        
        # Verify the import
        from qgis.core import QgsRasterLayer
        imported_raster = QgsRasterLayer(outputs['ImportEnmapL2a']['outputEnmapL2ARaster'], "temp")
        if imported_raster.isValid():
            band_count = imported_raster.bandCount()
            feedback.pushInfo("=" * 60)
            feedback.pushInfo(f"✓ Successfully imported {band_count} bands")
            if band_count >= 224:
                feedback.pushInfo("✓ All 224 bands available - full processing will proceed")
            else:
                feedback.pushWarning(f"⚠ Only {band_count} bands detected")
            feedback.pushInfo("=" * 60)

        # Chlorite-epidote abundance 2250D
        alg_params = {
            'BAND_A': 155,
            'BAND_B': 160,
            'BAND_C': 158,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ChloriteepidoteAbundance2250d'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Subset p2395
        alg_params = {
            'bandList': [213,214,215,216,217,218,219,220,221,222] if band_count >= 222 else list(range(max(1, band_count - 9), band_count + 1)),
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        if band_count < 222:
            feedback.pushWarning(f"Subset p2395: Using bands {max(1, band_count - 9)}-{band_count} (adapted for {band_count}-band product)")
        outputs['SubsetP2395'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Alunite composition 1480W
        alg_params = {
            'BAND_A': 74,
            'BAND_B': 76,
            'BAND_C': 83,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AluniteComposition1480w'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Kaolin Crystallinity
        alg_params = {
            'BAND_A': 188,
            'BAND_B': 194,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KaolinCrystallinity'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Save Alunite Composition layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_AluniteCom_1480W.tif",
            'raster': outputs['AluniteComposition1480w']['OUTPUT'],
            
        }
        outputs['SaveAluniteCompositionLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # 2320D Dolomitisation 1
        alg_params = {
            'BAND_A': 193,
            'BAND_B': 210,
            'BAND_C': 208,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['DDolomitisation1'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # Subset B193
        alg_params = {
            'bandList': [193],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB193'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # Subset p2260
        alg_params = {
            'bandList': [210,211,212,213,214,215,216],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP2260'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # Subset p2330
        alg_params = {
            'bandList': [205,206,207,208,209,210,211,212,213],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP2330'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # Save Kaolin XL layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_KaoliniteXL.tif",
            'raster': outputs['KaolinCrystallinity']['OUTPUT'],
            
        }
        outputs['SaveKaolinXlLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            return {}

        # Av_p2260-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E)/5',
            'INPUT_A': outputs['SubsetP2260']['outputRaster'],
            'INPUT_B': outputs['SubsetP2260']['outputRaster'],
            'INPUT_C': outputs['SubsetP2260']['outputRaster'],
            'INPUT_D': outputs['SubsetP2260']['outputRaster'],
            'INPUT_E': outputs['SubsetP2260']['outputRaster'],
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p22601'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            return {}

        # Av_p2260-2
        alg_params = {
            'BAND_A': 6,
            'BAND_B': 7,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['SubsetP2260']['outputRaster'],
            'INPUT_B': outputs['SubsetP2260']['outputRaster'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p22602'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(13)
        if feedback.isCanceled():
            return {}

        # Save Chl-Ep Abundance layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_Chl-EpiditeAbund_2250D.tif",
            'raster': outputs['ChloriteepidoteAbundance2250d']['OUTPUT'],
            
        }
        outputs['SaveChlepAbundanceLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(14)
        if feedback.isCanceled():
            return {}

        # Load Alunite Composition into project
        alg_params = {
            'INPUT': outputs['SaveAluniteCompositionLayerAs']['outputRaster'],
            'NAME': QgsExpression("'AluniteComp_1480W'").evaluate()
        }
        outputs['LoadAluniteCompositionIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}

        # Subset B030
        alg_params = {
            'bandList': [30],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB030'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(16)
        if feedback.isCanceled():
            return {}

        # Subset p1650
        alg_params = {
            'bandList': [148,149,150,151,152,153,154,155,156,157],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP1650'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(17)
        if feedback.isCanceled():
            return {}

        # Muscovite Index
        alg_params = {
            'BAND_A': 204,
            'BAND_B': 194,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['MuscoviteIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(18)
        if feedback.isCanceled():
            return {}

        # Load Chl-Ep Abundance into project
        alg_params = {
            'INPUT': outputs['SaveChlepAbundanceLayerAs']['outputRaster'],
            'NAME': QgsExpression("'2250D_Chl-Ep_Abund'").evaluate()
        }
        outputs['LoadChlepAbundanceIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(19)
        if feedback.isCanceled():
            return {}

        # Raster calculator p 2300
        alg_params = {
            'BAND_A': 204,
            'BAND_B': 205,
            'BAND_C': 206,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C)/3',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RasterCalculatorP2300'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(20)
        if feedback.isCanceled():
            return {}

        # Subset B016
        alg_params = {
            'bandList': [16],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB016'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(21)
        if feedback.isCanceled():
            return {}

        # Save Dolimitisation 1 layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_Dolomitisation_2320D.tif",
            'raster': outputs['DDolomitisation1']['OUTPUT'],
            
        }
        outputs['SaveDolimitisation1LayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(22)
        if feedback.isCanceled():
            return {}

        # Subset B149
        alg_params = {
            'bandList': [149],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB149'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(23)
        if feedback.isCanceled():
            return {}

        # Subset tm3
        alg_params = {
            'bandList': [42,43,44,45,46,47,48,49,50,51,52],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetTm3'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(24)
        if feedback.isCanceled():
            return {}

        # Subset p2165
        alg_params = {
            'bandList': [187,188,189,190,191],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP2165'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(25)
        if feedback.isCanceled():
            return {}

        # Kaolin Gp abundance 2160D
        alg_params = {
            'BAND_A': 145,
            'BAND_B': 153,
            'BAND_C': 148,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KaolinGpAbundance2160d'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(26)
        if feedback.isCanceled():
            return {}

        # 1480D alunite-jarosite abundance
        alg_params = {
            'BAND_A': 72,
            'BAND_B': 81,
            'BAND_C': 75,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['DAlunitejarositeAbundance'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(27)
        if feedback.isCanceled():
            return {}

        # Av_p2395-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP2395']['outputRaster'],
            'INPUT_B': outputs['SubsetP2395']['outputRaster'],
            'INPUT_C': outputs['SubsetP2395']['outputRaster'],
            'INPUT_D': outputs['SubsetP2395']['outputRaster'],
            'INPUT_E': outputs['SubsetP2395']['outputRaster'],
            'INPUT_F': outputs['SubsetP2395']['outputRaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p23951'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(28)
        if feedback.isCanceled():
            return {}

        # Subset p820
        alg_params = {
            'bandList': [64,65,66,67,68,69,70,71,72,73,74],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP820'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(29)
        if feedback.isCanceled():
            return {}

        # Av_p2330-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': 9,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C)/3',
            'INPUT_A': outputs['SubsetP2330']['outputRaster'],
            'INPUT_B': outputs['SubsetP2330']['outputRaster'],
            'INPUT_C': outputs['SubsetP2330']['outputRaster'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p23302'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(30)
        if feedback.isCanceled():
            return {}

        # Load Dolomitsation 1 into project
        alg_params = {
            'INPUT': outputs['SaveDolimitisation1LayerAs']['outputRaster'],
            'NAME': QgsExpression("'Dolomitisation_1_2320D'").evaluate()
        }
        outputs['LoadDolomitsation1IntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(31)
        if feedback.isCanceled():
            return {}

        # Av_p1650-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': 9,
            'BAND_D': 10,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D)/4',
            'INPUT_A': outputs['SubsetP1650']['outputRaster'],
            'INPUT_B': outputs['SubsetP1650']['outputRaster'],
            'INPUT_C': outputs['SubsetP1650']['outputRaster'],
            'INPUT_D': outputs['SubsetP1650']['outputRaster'],
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p16502'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(32)
        if feedback.isCanceled():
            return {}

        # 900D
        alg_params = {
            'BAND_A': 64,
            'BAND_B': 23,
            'BAND_C': 83,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['D'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(33)
        if feedback.isCanceled():
            return {}

        # Av_p820-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': 9,
            'BAND_D': 10,
            'BAND_E': 11,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E)/5',
            'INPUT_A': outputs['SubsetP820']['outputRaster'],
            'INPUT_B': outputs['SubsetP820']['outputRaster'],
            'INPUT_C': outputs['SubsetP820']['outputRaster'],
            'INPUT_D': outputs['SubsetP820']['outputRaster'],
            'INPUT_E': outputs['SubsetP820']['outputRaster'],
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p8202'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(34)
        if feedback.isCanceled():
            return {}

        # Kaolinite-Alunite-Pyrophyllite 2160W
        alg_params = {
            'BAND_A': 147,
            'BAND_B': 148,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Kaolinitealunitepyrophyllite2160w'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(35)
        if feedback.isCanceled():
            return {}

        # Av_p820-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP820']['outputRaster'],
            'INPUT_B': outputs['SubsetP820']['outputRaster'],
            'INPUT_C': outputs['SubsetP820']['outputRaster'],
            'INPUT_D': outputs['SubsetP820']['outputRaster'],
            'INPUT_E': outputs['SubsetP820']['outputRaster'],
            'INPUT_F': outputs['SubsetP820']['outputRaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p8201'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(36)
        if feedback.isCanceled():
            return {}

        # 2200W Al-sheet silicate composition
        alg_params = {
            'BAND_A': 151,
            'BAND_B': 154,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['WAlsheetSilicateComposition'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(37)
        if feedback.isCanceled():
            return {}

        # 900W
        alg_params = {
            'BAND_A': 74,
            'BAND_B': 82,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['W'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(38)
        if feedback.isCanceled():
            return {}

        # SWIR-active mafic minerals
        alg_params = {
            'BAND_A': 210,
            'BAND_B': 205,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SwiractiveMaficMinerals'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(39)
        if feedback.isCanceled():
            return {}

        # Alunite abundance 1760D
        alg_params = {
            'BAND_A': 107,
            'BAND_B': 112,
            'BAND_C': 110,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AluniteAbundance1760d'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(40)
        if feedback.isCanceled():
            return {}

        # Subset p2205
        alg_params = {
            'bandList': [191,192,193,194,195,196],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP2205'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(41)
        if feedback.isCanceled():
            return {}

        # Av_p2330-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP2330']['outputRaster'],
            'INPUT_B': outputs['SubsetP2330']['outputRaster'],
            'INPUT_C': outputs['SubsetP2330']['outputRaster'],
            'INPUT_D': outputs['SubsetP2330']['outputRaster'],
            'INPUT_E': outputs['SubsetP2330']['outputRaster'],
            'INPUT_F': outputs['SubsetP2330']['outputRaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p23301'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(42)
        if feedback.isCanceled():
            return {}

        # Save SWIR-active mafic layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_SWIR_mafic.tif",
            'raster': outputs['SwiractiveMaficMinerals']['OUTPUT'],
            
        }
        outputs['SaveSwiractiveMaficLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(43)
        if feedback.isCanceled():
            return {}

        # Subset p560
        alg_params = {
            'bandList': [22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP560'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(44)
        if feedback.isCanceled():
            return {}

        # Load SWIR mafic into project
        alg_params = {
            'INPUT': outputs['SaveSwiractiveMaficLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_SWIR-active_mafic_mins'").evaluate()
        }
        outputs['LoadSwirMaficIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(45)
        if feedback.isCanceled():
            return {}

        # Subset B048
        alg_params = {
            'bandList': [48],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB048'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(46)
        if feedback.isCanceled():
            return {}

        # Av_p2330
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Av_p23301']['OUTPUT'],
            'INPUT_B': outputs['Av_p23302']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p2330'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(47)
        if feedback.isCanceled():
            return {}

        # Al-Sheet Silicate Abundance 2200D
        alg_params = {
            'BAND_A': 148,
            'BAND_B': 156,
            'BAND_C': 153,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AlsheetSilicateAbundance2200d'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(48)
        if feedback.isCanceled():
            return {}

        # Av_p2260
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Av_p22601']['OUTPUT'],
            'INPUT_B': outputs['Av_p22602']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p2260'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(49)
        if feedback.isCanceled():
            return {}

        # Av_tm3-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetTm3']['outputRaster'],
            'INPUT_B': outputs['SubsetTm3']['outputRaster'],
            'INPUT_C': outputs['SubsetTm3']['outputRaster'],
            'INPUT_D': outputs['SubsetTm3']['outputRaster'],
            'INPUT_E': outputs['SubsetTm3']['outputRaster'],
            'INPUT_F': outputs['SubsetTm3']['outputRaster'],
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_tm31'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(50)
        if feedback.isCanceled():
            return {}

        # Save ASA composition layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_ASA_composition_2200W.tif",
            'raster': outputs['WAlsheetSilicateComposition']['OUTPUT'],
            
        }
        outputs['SaveAsaCompositionLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(51)
        if feedback.isCanceled():
            return {}

        # RGB Geology
        alg_params = {
            'ADD_ALPHA': False,
            'ASSIGN_CRS': None,
            'EXTRA': None,
            'INPUT': [outputs['SubsetB193']['outputRaster'],outputs['SubsetB149']['outputRaster'],outputs['SubsetB016']['outputRaster']],
            'PROJ_DIFFERENCE': False,
            'RESAMPLING': 0,  # Nearest Neighbour
            'RESOLUTION': 1,  # Highest
            'SEPARATE': True,
            'SRC_NODATA': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RgbGeology'] = processing.run('gdal:buildvirtualraster', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(52)
        if feedback.isCanceled():
            return {}

        # Subset B075
        alg_params = {
            'bandList': [75],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB075'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(53)
        if feedback.isCanceled():
            return {}

        # Av_p1650-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP1650']['outputRaster'],
            'INPUT_B': outputs['SubsetP1650']['outputRaster'],
            'INPUT_C': outputs['SubsetP1650']['outputRaster'],
            'INPUT_D': outputs['SubsetP1650']['outputRaster'],
            'INPUT_E': outputs['SubsetP1650']['outputRaster'],
            'INPUT_F': outputs['SubsetP1650']['outputRaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p16501'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(54)
        if feedback.isCanceled():
            return {}

        # Save Kaol-Alunite-Pyrophy layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_Kaol-Alunite-Pyroph_2160W.tif",
            'raster': outputs['Kaolinitealunitepyrophyllite2160w']['OUTPUT'],
            
        }
        outputs['SaveKaolalunitepyrophyLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(55)
        if feedback.isCanceled():
            return {}

        # Av_p2395-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': 9,
            'BAND_D': 10,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D)/4',
            'INPUT_A': outputs['SubsetP2395']['outputRaster'],
            'INPUT_B': outputs['SubsetP2395']['outputRaster'],
            'INPUT_C': outputs['SubsetP2395']['outputRaster'],
            'INPUT_D': outputs['SubsetP2395']['outputRaster'],
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p23952'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(56)
        if feedback.isCanceled():
            return {}

        # Av_tm3-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': 9,
            'BAND_D': 10,
            'BAND_E': 11,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E)/5',
            'INPUT_A': outputs['SubsetTm3']['outputRaster'],
            'INPUT_B': outputs['SubsetTm3']['outputRaster'],
            'INPUT_C': outputs['SubsetTm3']['outputRaster'],
            'INPUT_D': outputs['SubsetTm3']['outputRaster'],
            'INPUT_E': outputs['SubsetTm3']['outputRaster'],
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_tm32'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(57)
        if feedback.isCanceled():
            return {}

        # Load ASA Comosition into project
        alg_params = {
            'INPUT': outputs['SaveAsaCompositionLayerAs']['outputRaster'],
            'NAME': QgsExpression("'2200W_ASA_comp'").evaluate()
        }
        outputs['LoadAsaComositionIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(58)
        if feedback.isCanceled():
            return {}

        # Save Muscovite layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_MuscoviteIndex.tif",
            'raster': outputs['MuscoviteIndex']['OUTPUT'],
            
        }
        outputs['SaveMuscoviteLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(59)
        if feedback.isCanceled():
            return {}

        # Av_p2395
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Av_p23951']['OUTPUT'],
            'INPUT_B': outputs['Av_p23952']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p2395'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(60)
        if feedback.isCanceled():
            return {}

        # Av_p2205
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E)/5',
            'INPUT_A': outputs['SubsetP2205']['outputRaster'],
            'INPUT_B': outputs['SubsetP2205']['outputRaster'],
            'INPUT_C': outputs['SubsetP2205']['outputRaster'],
            'INPUT_D': outputs['SubsetP2205']['outputRaster'],
            'INPUT_E': outputs['SubsetP2205']['outputRaster'],
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p2205'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(61)
        if feedback.isCanceled():
            return {}

        # Load Kaolin XL into project
        alg_params = {
            'INPUT': outputs['SaveKaolinXlLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_KaolinXL'").evaluate()
        }
        outputs['LoadKaolinXlIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(62)
        if feedback.isCanceled():
            return {}

        # Av_p2165
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E)/5',
            'INPUT_A': outputs['SubsetP2165']['outputRaster'],
            'INPUT_B': outputs['SubsetP2165']['outputRaster'],
            'INPUT_C': outputs['SubsetP2165']['outputRaster'],
            'INPUT_D': outputs['SubsetP2165']['outputRaster'],
            'INPUT_E': outputs['SubsetP2165']['outputRaster'],
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p2165'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(63)
        if feedback.isCanceled():
            return {}

        # Save 900W layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_900W.tif",
            'raster': outputs['W']['OUTPUT'],
            
        }
        outputs['Save900wLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(64)
        if feedback.isCanceled():
            return {}

        # Load Muscovite into project
        alg_params = {
            'INPUT': outputs['SaveMuscoviteLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Muscovite Index'").evaluate()
        }
        outputs['LoadMuscoviteIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(65)
        if feedback.isCanceled():
            return {}

        # Save Kaolinite Gp Abundance layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_KaoliniteGpAbund_2160D.tif",
            'raster': outputs['KaolinGpAbundance2160d']['OUTPUT'],
            
        }
        outputs['SaveKaoliniteGpAbundanceLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(66)
        if feedback.isCanceled():
            return {}

        # Save Alunite Abundance layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_AluniteAbund_1760D.tif",
            'raster': outputs['AluniteAbundance1760d']['OUTPUT'],
            
        }
        outputs['SaveAluniteAbundanceLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(67)
        if feedback.isCanceled():
            return {}

        # Avp560-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP560']['outputRaster'],
            'INPUT_B': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_C': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_D': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_E': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'INPUT_F': outputs['ImportEnmapL2a']['outputEnmapL2ARaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Avp5601'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(68)
        if feedback.isCanceled():
            return {}

        # Avp560-3
        alg_params = {
            'BAND_A': 13,
            'BAND_B': 14,
            'BAND_C': 15,
            'BAND_D': 16,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D)/4',
            'INPUT_A': outputs['SubsetP560']['outputRaster'],
            'INPUT_B': outputs['SubsetP560']['outputRaster'],
            'INPUT_C': outputs['SubsetP560']['outputRaster'],
            'INPUT_D': outputs['SubsetP560']['outputRaster'],
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Avp5603'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(69)
        if feedback.isCanceled():
            return {}

        # Save Alunite Jarosite layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_AluniteJarosite_1480D.tif",
            'raster': outputs['DAlunitejarositeAbundance']['OUTPUT'],
            
        }
        outputs['SaveAluniteJarositeLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(70)
        if feedback.isCanceled():
            return {}

        # RGB Natural Colour
        alg_params = {
            'ADD_ALPHA': False,
            'ASSIGN_CRS': None,
            'EXTRA': None,
            'INPUT': [outputs['SubsetB048']['outputRaster'],outputs['SubsetB030']['outputRaster'],outputs['SubsetB016']['outputRaster']],
            'PROJ_DIFFERENCE': False,
            'RESAMPLING': 0,  # Nearest Neighbour
            'RESOLUTION': 1,  # Highest
            'SEPARATE': True,
            'SRC_NODATA': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RgbNaturalColour'] = processing.run('gdal:buildvirtualraster', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(71)
        if feedback.isCanceled():
            return {}

        # Avp560-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': 9,
            'BAND_D': 10,
            'BAND_E': 11,
            'BAND_F': 12,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP560']['outputRaster'],
            'INPUT_B': outputs['SubsetP560']['outputRaster'],
            'INPUT_C': outputs['SubsetP560']['outputRaster'],
            'INPUT_D': outputs['SubsetP560']['outputRaster'],
            'INPUT_E': outputs['SubsetP560']['outputRaster'],
            'INPUT_F': outputs['SubsetP560']['outputRaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Avp5602'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(72)
        if feedback.isCanceled():
            return {}

        # RGB Agriculture 2
        alg_params = {
            'ADD_ALPHA': False,
            'ASSIGN_CRS': None,
            'EXTRA': None,
            'INPUT': [outputs['SubsetB149']['outputRaster'],outputs['SubsetB075']['outputRaster'],outputs['SubsetB016']['outputRaster']],
            'PROJ_DIFFERENCE': False,
            'RESAMPLING': 0,  # Nearest Neighbour
            'RESOLUTION': 1,  # Highest
            'SEPARATE': True,
            'SRC_NODATA': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RgbAgriculture2'] = processing.run('gdal:buildvirtualraster', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(73)
        if feedback.isCanceled():
            return {}

        # Save 900D layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_900D.tif",
            'raster': outputs['D']['OUTPUT'],
            
        }
        outputs['Save900dLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(74)
        if feedback.isCanceled():
            return {}

        # Phyllic Altn Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['Av_p2165']['OUTPUT'],
            'INPUT_B': outputs['Av_p2260']['OUTPUT'],
            'INPUT_C': outputs['Av_p2205']['OUTPUT'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PhyllicAltnIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(75)
        if feedback.isCanceled():
            return {}

        # Propylitic Altn Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['Av_p2260']['OUTPUT'],
            'INPUT_B': outputs['Av_p2395']['OUTPUT'],
            'INPUT_C': outputs['Av_p2330']['OUTPUT'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PropyliticAltnIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(76)
        if feedback.isCanceled():
            return {}

        # Save Geology layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_Geology.tif",
            'raster': outputs['RgbGeology']['OUTPUT'],
            
        }
        outputs['SaveGeologyLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(77)
        if feedback.isCanceled():
            return {}

        # Save Ag2 layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_Ag2.tif",
            'raster': outputs['RgbAgriculture2']['OUTPUT'],
            
        }
        outputs['SaveAg2LayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(78)
        if feedback.isCanceled():
            return {}

        # Load Kaol-Alunite-Pyroph  into project
        alg_params = {
            'INPUT': outputs['SaveKaolalunitepyrophyLayerAs']['outputRaster'],
            'NAME': QgsExpression("'Kaolinite-alunite-pyrophyllite_2160W'").evaluate()
        }
        outputs['LoadKaolalunitepyrophIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(79)
        if feedback.isCanceled():
            return {}

        # Av_p820
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Av_p8201']['OUTPUT'],
            'INPUT_B': outputs['Av_p8202']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p820'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(80)
        if feedback.isCanceled():
            return {}

        # Phengitic Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['Av_p2165']['OUTPUT'],
            'INPUT_B': outputs['Av_p2205']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PhengiticIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(81)
        if feedback.isCanceled():
            return {}

        # Load Alunite Abundance into project
        alg_params = {
            'INPUT': outputs['SaveAluniteAbundanceLayerAs']['outputRaster'],
            'NAME': QgsExpression("'AluniteAbundance_1480D'").evaluate()
        }
        outputs['LoadAluniteAbundanceIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(82)
        if feedback.isCanceled():
            return {}

        # Av_tm3
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Av_tm31']['OUTPUT'],
            'INPUT_B': outputs['Av_tm32']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_tm3'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(83)
        if feedback.isCanceled():
            return {}

        # Save NatCol layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_NatCol.tif",
            'raster': outputs['RgbNaturalColour']['OUTPUT'],
            
        }
        outputs['SaveNatcolLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(84)
        if feedback.isCanceled():
            return {}

        # Save ASA layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_ASA2200D.tif",
            'raster': outputs['AlsheetSilicateAbundance2200d']['OUTPUT'],
            
        }
        outputs['SaveAsaLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(85)
        if feedback.isCanceled():
            return {}

        # Save Propyitic layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_PropyliticAltnIndex.tif",
            'raster': outputs['PropyliticAltnIndex']['OUTPUT'],
            
        }
        outputs['SavePropyiticLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(86)
        if feedback.isCanceled():
            return {}

        # Load Alunite Jarosite into project
        alg_params = {
            'INPUT': outputs['SaveAluniteJarositeLayerAs']['outputRaster'],
            'NAME': QgsExpression("'Alunite-Jarosite_Abund_1480D'").evaluate()
        }
        outputs['LoadAluniteJarositeIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(87)
        if feedback.isCanceled():
            return {}

        # Load Propylitic into project
        alg_params = {
            'INPUT': outputs['SavePropyiticLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Propylitic_Altn Index'").evaluate()
        }
        outputs['LoadPropyliticIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(88)
        if feedback.isCanceled():
            return {}

        # Load Ag2 into project
        alg_params = {
            'INPUT': outputs['SaveAg2LayerAs']['outputRaster'],
            'NAME': QgsExpression("'RGB_Ag2'").evaluate()
        }
        outputs['LoadAg2IntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(89)
        if feedback.isCanceled():
            return {}

        # Av_p560
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C)/3',
            'INPUT_A': outputs['Avp5601']['OUTPUT'],
            'INPUT_B': outputs['Avp5602']['OUTPUT'],
            'INPUT_C': outputs['Avp5603']['OUTPUT'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p560'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(90)
        if feedback.isCanceled():
            return {}

        # Load 900W into project
        alg_params = {
            'INPUT': outputs['Save900wLayerAs']['outputRaster'],
            'NAME': QgsExpression("'900W'").evaluate()
        }
        outputs['Load900wIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(91)
        if feedback.isCanceled():
            return {}

        # Ferrous Iron (Fe2+) Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': 1,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/(C+D)',
            'INPUT_A': outputs['Av_p2165']['OUTPUT'],
            'INPUT_B': outputs['Av_p820']['OUTPUT'],
            'INPUT_C': outputs['Av_p560']['OUTPUT'],
            'INPUT_D': outputs['Av_tm3']['OUTPUT'],
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FerrousIronFe2Index'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(92)
        if feedback.isCanceled():
            return {}

        # Load 900D into project
        alg_params = {
            'INPUT': outputs['Save900dLayerAs']['outputRaster'],
            'NAME': QgsExpression("'900D'").evaluate()
        }
        outputs['Load900dIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(93)
        if feedback.isCanceled():
            return {}

        # MgOH Carbonate Abund Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['Av_p2395']['OUTPUT'],
            'INPUT_B': outputs['Av_p2205']['OUTPUT'],
            'INPUT_C': outputs['Av_p2330']['OUTPUT'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['MgohCarbonateAbundIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(94)
        if feedback.isCanceled():
            return {}

        # Load Kaol Gp Abund into project
        alg_params = {
            'INPUT': outputs['SaveKaoliniteGpAbundanceLayerAs']['outputRaster'],
            'NAME': QgsExpression("'KaolinGp_Abund_2160D'").evaluate()
        }
        outputs['LoadKaolGpAbundIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(95)
        if feedback.isCanceled():
            return {}

        # Save Phengitic layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_PhengiticIndex.tif",
            'raster': outputs['PhengiticIndex']['OUTPUT'],
            
        }
        outputs['SavePhengiticLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(96)
        if feedback.isCanceled():
            return {}

        # Raster calculator p1650
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Av_p16501']['OUTPUT'],
            'INPUT_B': outputs['Av_p16502']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RasterCalculatorP1650'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(97)
        if feedback.isCanceled():
            return {}

        # Save Phyllitic layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_PhylliticAltnIndex.tif",
            'raster': outputs['PhyllicAltnIndex']['OUTPUT'],
            
        }
        outputs['SavePhylliticLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(98)
        if feedback.isCanceled():
            return {}

        # Alunite Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A*B)/(A*C)',
            'INPUT_A': outputs['Av_p2260']['OUTPUT'],
            'INPUT_B': outputs['Av_p2165']['OUTPUT'],
            'INPUT_C': outputs['Av_p2330']['OUTPUT'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AluniteIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(99)
        if feedback.isCanceled():
            return {}

        # Load NC into project
        alg_params = {
            'INPUT': outputs['SaveNatcolLayerAs']['outputRaster'],
            'NAME': QgsExpression("'RGB_Nat_Col'").evaluate()
        }
        outputs['LoadNcIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(100)
        if feedback.isCanceled():
            return {}

        # Save MgOH Carb Index layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_MgOHCarbIndex.tif",
            'raster': outputs['MgohCarbonateAbundIndex']['OUTPUT'],
            
        }
        outputs['SaveMgohCarbIndexLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(101)
        if feedback.isCanceled():
            return {}

        # Ferric Iron Altn Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': 1,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A/B)+(C/D)',
            'INPUT_A': outputs['Av_p2165']['OUTPUT'],
            'INPUT_B': outputs['Av_p820']['OUTPUT'],
            'INPUT_C': outputs['Av_p560']['OUTPUT'],
            'INPUT_D': outputs['Av_tm3']['OUTPUT'],
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FerricIronAltnIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(102)
        if feedback.isCanceled():
            return {}

        # Ferrous Silicates Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['Av_p2165']['OUTPUT'],
            'INPUT_B': outputs['RasterCalculatorP1650']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FerrousSilicatesIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(103)
        if feedback.isCanceled():
            return {}

        # Load Phyllitic into project
        alg_params = {
            'INPUT': outputs['SavePhylliticLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Phyllic_Altn Index'").evaluate()
        }
        outputs['LoadPhylliticIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(104)
        if feedback.isCanceled():
            return {}

        # Load Geology into project
        alg_params = {
            'INPUT': outputs['SaveGeologyLayerAs']['outputRaster'],
            'NAME': QgsExpression("'RGB_Geology'").evaluate()
        }
        outputs['LoadGeologyIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(105)
        if feedback.isCanceled():
            return {}

        # Save Ferrous Silicates layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_FerrousSilicatesIndex.tif",
            'raster': outputs['FerrousSilicatesIndex']['OUTPUT'],
            
        }
        outputs['SaveFerrousSilicatesLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(106)
        if feedback.isCanceled():
            return {}

        # Load ASA into project
        alg_params = {
            'INPUT': outputs['SaveAsaLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ASA_2200D'").evaluate()
        }
        outputs['LoadAsaIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(107)
        if feedback.isCanceled():
            return {}

        # Save Ferric Iron Altn layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_FerricIronAltnIndex.tif",
            'raster': outputs['FerricIronAltnIndex']['OUTPUT'],
            
        }
        outputs['SaveFerricIronAltnLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(108)
        if feedback.isCanceled():
            return {}

        # RGB FerrSil-FerricIrAltn-MgOHCarb
        alg_params = {
            'ADD_ALPHA': False,
            'ASSIGN_CRS': None,
            'EXTRA': None,
            'INPUT': [outputs['FerrousSilicatesIndex']['OUTPUT'],outputs['FerricIronAltnIndex']['OUTPUT'],outputs['MgohCarbonateAbundIndex']['OUTPUT']],
            'PROJ_DIFFERENCE': False,
            'RESAMPLING': 0,  # Nearest Neighbour
            'RESOLUTION': 1,  # Highest
            'SEPARATE': True,
            'SRC_NODATA': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RgbFerrsilferriciraltnmgohcarb'] = processing.run('gdal:buildvirtualraster', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(109)
        if feedback.isCanceled():
            return {}

        # Save Ferrous Iron layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_FerrousIronIndex.tif",
            'raster': outputs['FerrousIronFe2Index']['OUTPUT'],
            
        }
        outputs['SaveFerrousIronLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(110)
        if feedback.isCanceled():
            return {}

        # Save Alunite layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_AluniteIndex.tif",
            'raster': outputs['AluniteIndex']['OUTPUT'],
            
        }
        outputs['SaveAluniteLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(111)
        if feedback.isCanceled():
            return {}

        # Load MgOH-Carb into project
        alg_params = {
            'INPUT': outputs['SaveMgohCarbIndexLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_MgOH Carb Abundance Index'").evaluate()
        }
        outputs['LoadMgohcarbIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(112)
        if feedback.isCanceled():
            return {}

        # Load Phengitic into project
        alg_params = {
            'INPUT': outputs['SavePhengiticLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Phengitic Index'").evaluate()
        }
        outputs['LoadPhengiticIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(113)
        if feedback.isCanceled():
            return {}

        # Save FeS-FeAlt-MgOH layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': f"{output_dir}/{output_prefix}_FeSil-FeAlt-MgOH.tif",
            'raster': outputs['RgbFerrsilferriciraltnmgohcarb']['OUTPUT'],
            
        }
        outputs['SaveFesfealtmgohLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(114)
        if feedback.isCanceled():
            return {}

        # Load layer into project
        alg_params = {
            'INPUT': outputs['SaveFerricIronAltnLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Ferric Iron Altn Index'").evaluate()
        }
        outputs['LoadLayerIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(115)
        if feedback.isCanceled():
            return {}

        # Load Ferrous Silicates into project
        alg_params = {
            'INPUT': outputs['SaveFerrousSilicatesLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Ferrous Silicates Index'").evaluate()
        }
        outputs['LoadFerrousSilicatesIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(116)
        if feedback.isCanceled():
            return {}

        # Load Ferrous Iron into project
        alg_params = {
            'INPUT': outputs['SaveFerrousIronLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Ferrous Iron Index'").evaluate()
        }
        outputs['LoadFerrousIronIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(117)
        if feedback.isCanceled():
            return {}

        # Load Alunite into project
        alg_params = {
            'INPUT': outputs['SaveAluniteLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Alunite_Index'").evaluate()
        }
        outputs['LoadAluniteIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(118)
        if feedback.isCanceled():
            return {}

        # Load layer into project
        alg_params = {
            'INPUT': outputs['SaveFesfealtmgohLayerAs']['outputRaster'],
            'NAME': QgsExpression("'RGB_FeSil-FeIrAltn-MgOHCarb'").evaluate()
        }
        outputs['LoadLayerIntoProject_2'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        
        # Processing complete!
        feedback.pushInfo("=" * 60)
        feedback.pushInfo("EnMAP Processing Completed Successfully!")
        feedback.pushInfo("=" * 60)
        feedback.pushInfo(f"All {output_prefix} spectral indices have been generated")
        feedback.pushInfo(f"Output location: {output_dir}")
        feedback.pushInfo("Layers have been loaded into the current project")
        feedback.pushInfo("=" * 60)
        
        return results

    def name(self) -> str:
        return 'enmap_spectral_indices_full'

    def displayName(self) -> str:
        return 'EnMap_processing'

    def group(self) -> str:
        return ''

    def groupId(self) -> str:
        return ''

    def createInstance(self):
        return self.__class__()
