# EnMAP Processor - Quick Start Guide

Get started with the EnMAP Processor plugin in 5 minutes!

## Installation (2 minutes)

### Step 1: Install EnMAP-Box
```
QGIS → Plugins → Manage and Install Plugins
Search: "EnMAP-Box"
Click: Install Plugin
```

### Step 2: Install EnMAP Processor
```
Option A - From ZIP:
1. Download enmap_processor_plugin.zip
2. QGIS → Plugins → Manage and Install Plugins → Install from ZIP
3. Select the ZIP file
4. Click Install Plugin

Option B - Manual:
1. Extract the ZIP file
2. Copy enmap_processor_plugin folder to:
   - Windows: %APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\
   - macOS: ~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/
   - Linux: ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/
3. Restart QGIS
4. Enable in Plugins → Manage and Install Plugins
```

## First Processing (3 minutes)

### Step 1: Prepare Data
- Have your EnMAP L2A metadata XML file ready
- Example: `ENMAP01-...-METADATA.XML`
- Create an output folder

### Step 2: Run Processing

**Quick Access - Choose One:**

**Option A: Menu (Fastest)**
```
Raster → EnMAP Processor → EnMAP Spectral Indices Processor
```

**Option B: Toolbar**
```
Click the EnMAP Processor icon in the toolbar
```

**Option C: Processing Toolbox**
```
Processing → Toolbox → Remote Sensing → EnMAP Spectral Indices Processor (Full)
```

**Then Set Parameters:**
   - XML File: Select your ENMAP-METADATA.XML
   - Output Directory: Choose output folder
   - Output Prefix: Enter name (e.g., "MyScene")
4. Click Run
5. Wait 15-30 minutes (grab a coffee!)

### Step 3: View Results
- All layers automatically load into QGIS
- Files saved in your output directory
- Adjust stretching for better visualization

## What You Get

After processing, you'll have 15+ spectral index layers:

**Mineral Indices:**
- Alunite Index & Composition
- Kaolin Crystallinity
- White Mica Composition
- Chlorite-Epidote Abundance

**Alteration Indices:**
- Ferric Iron Alteration
- Ferrous Iron Index
- Ferrous Silicates
- MgOH-Carbonate Abundance
- Phengitic Index

**Plus:**
- RGB Composite (FeSil-FeIrAltn-MgOHCarb)
- All as compressed GeoTIFF files

## Quick Tips

✅ **Do:**
- Use L2A (atmospherically corrected) data
- Ensure 10+ GB free disk space
- Let processing complete all 119 steps

❌ **Don't:**
- Interrupt processing
- Use network drives (very slow)
- Mix data from different scenes

## Troubleshooting

**Can't find the plugin?**
→ Check Plugins → Manage and Install Plugins → Installed

**EnMAP-Box algorithms not found?**
→ Install EnMAP-Box plugin first

**Processing very slow?**
→ Normal! EnMAP has 242 bands. Processing takes 15-30 minutes.

**Memory errors?**
→ Close other applications, ensure 8+ GB RAM

## Next Steps

📖 **Read the full documentation:**
- README.md - Feature overview
- USER_GUIDE.md - Detailed usage instructions
- INSTALL.md - Installation troubleshooting

🎯 **Advanced usage:**
- Batch process multiple scenes
- Create custom indices
- Export results to other software

📧 **Need help?**
- Check QGIS log messages
- Review processing log
- Contact: boxerg@iinet.net.au

## Processing Checklist

Before running:
- [ ] EnMAP-Box installed
- [ ] EnMAP Processor installed
- [ ] EnMAP L2A data downloaded
- [ ] Output directory created
- [ ] 10+ GB disk space available
- [ ] QGIS project saved

After processing:
- [ ] All 119 steps completed
- [ ] Output files created
- [ ] Layers loaded in QGIS
- [ ] Results look reasonable
- [ ] Project saved with results

---

**Welcome to hyperspectral processing with EnMAP!** 🛰️

For detailed information, see the full USER_GUIDE.md
