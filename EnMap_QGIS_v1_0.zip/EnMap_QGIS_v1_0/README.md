# EnMAP Processor - QGIS Plugin

A QGIS plugin for processing EnMAP hyperspectral satellite imagery to generate spectral indices for mineral mapping and remote sensing applications.

## Features

- **EnMAP L2A Import**: Imports EnMAP Level 2A hyperspectral imagery
- **Spectral Indices**: Calculates 50+ spectral indices including:
  - Mineral identification indices (Alunite, Kaolin, Chlorite, etc.)
  - Alteration indices (Ferric iron, Ferrous iron, MgOH-Carbonate)
  - Compositional indices (White mica, Amphibole, Epidote)
  - RGB composite images for visualization
- **Progress Tracking**: Real-time progress bar with detailed step information
- **Batch Processing**: Process entire EnMAP scenes with a single click
- **QGIS Integration**: Automatically loads results into your QGIS project

## Requirements

- QGIS 3.0 or higher
- EnMAP-Box plugin (for EnMAP data import tools)
- Python 3.6+

## Installation

### Method 1: Manual Installation

1. Download or clone this repository
2. Copy the `enmap_processor_plugin` folder to your QGIS plugins directory:
   - **Windows**: `C:\Users\<username>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - **macOS**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
   - **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`

3. Open QGIS
4. Go to `Plugins` → `Manage and Install Plugins`
5. Find "EnMAP Processor" in the list
6. Check the box to enable it

### Method 2: ZIP Installation

1. Download the plugin as a ZIP file
2. In QGIS, go to `Plugins` → `Manage and Install Plugins`
3. Click "Install from ZIP"
4. Select the downloaded ZIP file
5. Click "Install Plugin"

## Usage

### Basic Workflow

There are three ways to access the EnMAP Processor:

**Method 1: Menu Item (Easiest)**
1. Go to `Raster` → `EnMAP Processor` → `EnMAP Spectral Indices Processor`
2. The processing dialog will open automatically

**Method 2: Toolbar Button**
1. Look for the EnMAP Processor icon in the toolbar
2. Click the icon to open the processing dialog

**Method 3: Processing Toolbox**
1. Go to `Processing` → `Toolbox`
2. Navigate to `Remote Sensing` → `EnMAP Spectral Indices Processor (Full)`
3. Double-click to open

Once the dialog is open:

1. **Set Parameters**
   - **EnMAP L2A Metadata XML File**: Select your EnMAP metadata XML file
   - **Output Directory**: Choose where to save the results
   - **Output File Prefix**: Specify a prefix for output filenames (default: "EnMAP")

2. **Run the Algorithm**
   - Click "Run"
   - Monitor progress in the log panel (119 total steps)
   - Processing time varies based on scene size (typically 15-30 minutes)

3. **View Results**
   - All generated layers are automatically loaded into your QGIS project
   - Output files are saved as GeoTIFF (.tif) in your specified directory

### Output Products

The plugin generates the following spectral indices:

#### Mineral Indices
- Alunite Index
- Alunite Composition (1480W)
- Kaolin Crystallinity
- Chlorite-Epidote Abundance (2250D)
- White Mica Composition

#### Alteration Indices
- Ferric Iron Alteration Index
- Ferrous Iron Index
- Ferrous Silicates Index
- MgOH-Carbonate Abundance Index
- Phengitic Index
- ASA (Advanced Spectral Analysis) 2200D

#### Compositional Indices
- Amphibole Index
- Epidote Index
- Dolomitisation Index (2320D)

#### RGB Composites
- FeSil-FeIrAltn-MgOHCarb composite

## Important Notes

### Bad Bands
**This plugin does NOT exclude bad bands during import** as per the original workflow requirements. This ensures all spectral information is retained for analysis.

If you need to exclude bad bands, you can:
1. Pre-process your data with the EnMAP-Box
2. Modify the algorithm parameters manually

### Dependencies

This plugin requires:
- **EnMAP-Box**: For `enmapbox:importenmapl2aproduct` and `enmapbox:saverasterlayeras` algorithms
- **GDAL**: For raster calculator operations (included with QGIS)

Install EnMAP-Box from the QGIS Plugin Repository if not already installed.

## Progress Tracking

The plugin provides detailed progress information:
- **Step Counter**: Shows current step out of 119 total steps
- **Percentage**: Displays completion percentage
- **Step Descriptions**: Named descriptions for key processing steps
- **Cancellation**: You can cancel processing at any time

Example progress output:
```
============================================================
EnMAP Hyperspectral Processing Started
============================================================
Input XML: /path/to/ENMAP-METADATA.XML
Output Directory: /path/to/output
Output Prefix: MyScene
============================================================
Step 1/119: Importing EnMAP L2A product (NOT excluding bad bands)...
Step 2/119: Calculating Chlorite-epidote abundance 2250D...
Step 3/119: Creating subset p2395...
...
Progress: 50/119 steps completed (42%)...
...
============================================================
EnMAP Processing Completed Successfully!
============================================================
```

## Troubleshooting

### "EnMAP-Box algorithms not found"
- Install the EnMAP-Box plugin from the QGIS Plugin Repository
- Restart QGIS after installation

### "Output directory not writable"
- Ensure you have write permissions to the output directory
- Try selecting a different output location

### Processing is slow
- EnMAP processing is computationally intensive
- Processing time depends on scene size and computer specifications
- Expected time: 15-30 minutes for a full scene

### Memory errors
- Close other applications to free up RAM
- Process smaller subsets if possible
- Increase QGIS memory allocation in settings

## Technical Details

### Processing Steps
The algorithm performs 119 processing steps:
1. Import EnMAP L2A data
2-100. Calculate spectral indices using band ratios and formulas
101-110. Save results to GeoTIFF files
111-119. Load layers into QGIS project

### Output Format
- **Format**: GeoTIFF with LZW compression
- **Data Type**: Float32
- **Interleave**: Band interleave
- **Predictor**: 2 (horizontal differencing)
- **BigTIFF**: Enabled for large files

## Citation

If you use this plugin in your research, please cite:
- EnMAP Mission: [EnMAP website](https://www.enmap.org/)
- QGIS: QGIS Development Team (YEAR). QGIS Geographic Information System. Open Source Geospatial Foundation Project.

## License

This plugin is released under the GNU General Public License v3.0.

## Support

For issues, questions, or suggestions:
- GitHub Issues: [your-repo-url]/issues
- Email: boxerg@iinet.net.au

## Version History

### Version 1.0 (2024)
- Initial release
- Full EnMAP L2A processing workflow
- 50+ spectral indices
- Progress tracking with 119 steps
- Automatic layer loading

## Acknowledgments

Based on ENVI processing workflows for EnMAP hyperspectral data.

---

**Author**: Grant Boxer  
**Email**: boxerg@iinet.net.au  
**Last Updated**: January 2026
