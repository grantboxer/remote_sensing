# EnMAP Processor - User Guide

## Table of Contents
1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [Processing Workflow](#processing-workflow)
4. [Understanding Outputs](#understanding-outputs)
5. [Advanced Usage](#advanced-usage)
6. [Tips and Best Practices](#tips-and-best-practices)

## Introduction

The EnMAP Processor plugin automates the processing of EnMAP (Environmental Mapping and Analysis Program) hyperspectral satellite imagery. It generates a comprehensive suite of spectral indices used for geological mapping, mineral identification, and environmental monitoring.

### What is EnMAP?

EnMAP is a German hyperspectral satellite mission that acquires imaging spectrometry data in 242 spectral bands covering the wavelength range from 420 to 2450 nm. This rich spectral information enables detailed analysis of Earth surface materials.

### What does this plugin do?

This plugin:
- Imports EnMAP L2A (atmospherically corrected) data
- Calculates 50+ spectral indices based on diagnostic absorption features
- Creates RGB composite images for visualization
- Automatically saves and loads results into your QGIS project

## Getting Started

### Prerequisites

Before using the plugin, ensure you have:

1. **EnMAP L2A Data**: Download from [EnMAP Ground Segment](https://planning.enmap.org/)
   - You need the metadata XML file (e.g., `ENMAP01-...-METADATA.XML`)
   - All associated image files should be in the same directory

2. **QGIS 3.0+**: Download from [QGIS.org](https://qgis.org/)

3. **EnMAP-Box Plugin**: Install from QGIS Plugin Repository
   - In QGIS: Plugins → Manage and Install Plugins → Search "EnMAP-Box"

4. **Adequate Disk Space**: At least 10 GB free for processing

### First-Time Setup

1. Install the plugin (see INSTALL.md)
2. Verify installation:
   - Open Processing Toolbox (Processing → Toolbox)
   - Search for "EnMAP"
   - You should see "EnMAP Spectral Indices Processor (Full)"

## Processing Workflow

### Step-by-Step Guide

#### 1. Prepare Your Data

Organize your EnMAP data:
```
/data/enmap/
├── ENMAP01-...-METADATA.XML          (metadata file - YOU NEED THIS)
├── ENMAP01-...-SPECTRAL_IMAGE.TIF    (spectral image)
├── ENMAP01-...-QL_PIXELMASK.TIF      (quality layer)
└── ... (other files)
```

**Important**: You only need to select the XML file; the plugin will find associated files.

#### 2. Open the Algorithm

1. Open QGIS
2. Go to `Processing` → `Toolbox`
3. Navigate to `Remote Sensing`
4. Double-click `EnMAP Spectral Indices Processor (Full)`

#### 3. Configure Parameters

**Parameter 1: EnMAP L2A Metadata XML File**
- Click the `...` button
- Navigate to your EnMAP data folder
- Select the `-METADATA.XML` file
- Example: `ENMAP01-____L2A-DT0000059942_20240206T023005Z_002_V010402_20240412T024312Z-METADATA.XML`

**Parameter 2: Output Directory**
- Click the `...` button
- Select or create a folder for outputs
- Recommendation: Create a new folder for each scene
- Example: `/outputs/enmap_scene_20240206/`

**Parameter 3: Output File Prefix**
- Enter a descriptive prefix for your output files
- Default: "EnMAP"
- Recommendation: Use location and date
- Example: "Cardinya_20240206"

#### 4. Run the Algorithm

1. Click `Run`
2. The algorithm will start processing
3. Monitor progress in the log panel

### Understanding the Progress Bar

The plugin processes 119 steps. Here's what happens:

**Steps 1-10: Data Import & Initial Indices**
- Imports EnMAP L2A product
- Calculates initial spectral indices
- Creates spectral subsets

**Steps 11-50: Mineral Indices**
- Chlorite-Epidote abundance
- Alunite composition and indices
- Kaolin crystallinity
- White mica composition
- Amphibole indices

**Steps 51-80: Alteration Indices**
- Ferric iron alteration
- Ferrous iron and silicates
- MgOH-Carbonate abundance
- Phengitic composition
- Dolomitisation

**Steps 81-100: Additional Indices & Calculations**
- Epidote composition
- Carbonate indices
- Continuum depth calculations

**Steps 101-110: Saving Outputs**
- Saves all calculated indices as GeoTIFF files
- Applies compression and optimization

**Steps 111-119: Loading Results**
- Loads all layers into current QGIS project
- Applies default styling where applicable

### Expected Processing Time

- **Small scene** (< 100 km²): 10-15 minutes
- **Medium scene** (100-500 km²): 15-25 minutes
- **Large scene** (> 500 km²): 25-45 minutes

*Times vary based on computer specifications and disk speed*

## Understanding Outputs

### Output Files

All output files are saved as GeoTIFF with the following format:
```
{prefix}_{index_name}.tif
```

Example:
```
Cardinya_20240206_AluniteIndex.tif
Cardinya_20240206_FerrousIronIndex.tif
```

### Spectral Indices Explained

#### Mineral Identification Indices

**Alunite Index**
- **Purpose**: Identifies alunite mineral
- **Use Case**: Hydrothermal alteration mapping
- **Interpretation**: Higher values = more alunite

**Alunite Composition (1480W)**
- **Purpose**: Determines alunite composition
- **Use Case**: Distinguishing alunite types
- **Interpretation**: Ratio indicates compositional variation

**Kaolin Crystallinity**
- **Purpose**: Measures kaolin disorder/crystallinity
- **Use Case**: Hydrothermal alteration intensity
- **Interpretation**: Higher values = better crystallinity

**White Mica Composition**
- **Purpose**: Identifies white mica composition
- **Use Case**: Mapping muscovite vs. phengite
- **Interpretation**: Compositional gradient

#### Alteration Indices

**Ferric Iron Alteration Index**
- **Purpose**: Detects oxidized iron minerals
- **Use Case**: Weathering and oxidation zones
- **Interpretation**: Higher values = more Fe³⁺

**Ferrous Iron Index**
- **Purpose**: Detects reduced iron minerals
- **Use Case**: Fresh rock and mineral mapping
- **Interpretation**: Higher values = more Fe²⁺

**Ferrous Silicates Index**
- **Purpose**: Identifies Fe-bearing silicates
- **Use Case**: Mapping chlorite, biotite, amphibole
- **Interpretation**: Indicates mafic minerals

**MgOH-Carbonate Abundance Index**
- **Purpose**: Detects Mg-bearing minerals
- **Use Case**: Carbonate and serpentine mapping
- **Interpretation**: Higher values = more Mg-OH/carbonate

**Phengitic Index**
- **Purpose**: Identifies phengitic white micas
- **Use Case**: Low-grade metamorphism mapping
- **Interpretation**: Composition indicator

#### Compositional Indices

**Chlorite-Epidote Abundance (2250D)**
- **Purpose**: Measures chlorite-epidote content
- **Use Case**: Propylitic alteration mapping
- **Interpretation**: Alteration intensity

**Amphibole Index**
- **Purpose**: Identifies amphibole minerals
- **Use Case**: Mafic rock mapping
- **Interpretation**: Higher values = more amphibole

**Epidote Index**
- **Purpose**: Detects epidote mineral
- **Use Case**: Propylitic alteration zones
- **Interpretation**: Alteration indicator

**Dolomitisation Index (2320D)**
- **Purpose**: Identifies dolomite
- **Use Case**: Carbonate rock mapping
- **Interpretation**: Dolomitization degree

#### RGB Composites

**FeSil-FeIrAltn-MgOHCarb**
- **Red**: Ferrous Silicates
- **Green**: Ferric Iron Alteration
- **Blue**: MgOH-Carbonate Abundance
- **Use Case**: Quick visualization of alteration types

### Interpreting Results

#### Visualization Tips

1. **Use Stretch Settings**:
   - Right-click layer → Properties → Symbology
   - Set Min/Max to "Cumulative count cut" (2%-98%)
   - Improves visual contrast

2. **Create Color Ramps**:
   - Use "Spectral" or "RdYlGn" for indices
   - Higher values typically in warm colors (red/yellow)

3. **Combine Multiple Indices**:
   - Stack complementary indices
   - Use blend modes (multiply, overlay)

#### Common Patterns

**High Alunite + High Ferric Iron**:
- Suggests advanced argillic alteration
- Potential mineral deposit indicator

**High Ferrous Silicates + Low Ferric Iron**:
- Indicates fresh, unweathered rock
- Mafic lithologies

**High MgOH-Carbonate + High Dolomitisation**:
- Carbonate-rich terrain
- Potential ultramafic rocks

## Advanced Usage

### Batch Processing

To process multiple EnMAP scenes:

```python
# Run in QGIS Python Console

scenes = [
    '/path/to/scene1/METADATA.XML',
    '/path/to/scene2/METADATA.XML',
    '/path/to/scene3/METADATA.XML'
]

output_base = '/path/to/outputs/'

for i, scene in enumerate(scenes):
    scene_name = f"Scene_{i+1}"
    output_dir = f"{output_base}/{scene_name}"
    
    params = {
        'select_enmap_xml': scene,
        'select_directory': output_dir,
        'output_prefix': scene_name
    }
    
    processing.run("enmapprocessor:enmap_spectral_indices_full", params)
```

### Custom Processing

Modify the algorithm for custom workflows:

1. Copy `enmap_processing_algorithm_full.py`
2. Rename the class
3. Modify band numbers or formulas
4. Add as a custom script in Processing Toolbox

### Integration with Other Tools

Export results for use in:

**ENVI**: Load GeoTIFF outputs directly

**ArcGIS**: Import as raster layers

**Google Earth Engine**: Upload via GEE Asset Manager

**Python/R**: Read with GDAL/Rasterio/Terra

## Tips and Best Practices

### Before Processing

✅ **Do**:
- Verify EnMAP data integrity
- Check that all files are present
- Ensure sufficient disk space
- Create a dedicated output folder

❌ **Don't**:
- Mix data from different scenes
- Use network drives (slow I/O)
- Interrupt processing unless necessary

### During Processing

✅ **Do**:
- Monitor progress in log panel
- Check for error messages
- Allow completion of all 119 steps

❌ **Don't**:
- Close QGIS during processing
- Start multiple processing jobs
- Put computer to sleep

### After Processing

✅ **Do**:
- Verify all output files created
- Check layer statistics
- Save your QGIS project
- Document processing parameters

❌ **Don't**:
- Delete intermediate files immediately
- Forget to backup important results

### Optimization Tips

**For Faster Processing**:
1. Use SSD for output directory
2. Close unnecessary applications
3. Increase QGIS memory allocation:
   - Settings → Options → Advanced
   - Search "memory"
   - Adjust cache settings

**For Better Results**:
1. Use atmospherically corrected data (L2A)
2. Check data quality layers
3. Apply appropriate stretch for visualization
4. Cross-validate with ground truth

### Troubleshooting

**Problem**: Processing is very slow
**Solution**: 
- Check disk I/O speed
- Reduce other CPU usage
- Use local disk, not network

**Problem**: Some indices look strange
**Solution**:
- Check input data quality
- Verify no data values
- Examine processing log for warnings

**Problem**: Out of memory errors
**Solution**:
- Process smaller subsets
- Increase system RAM
- Close other applications

**Problem**: Results don't load into project
**Solution**:
- Check output directory permissions
- Verify files were created
- Manually add layers if needed

## Support and Resources

### Documentation
- EnMAP Mission: https://www.enmap.org/
- EnMAP-Box: https://enmap-box.readthedocs.io/
- QGIS: https://docs.qgis.org/

### Data Access
- EnMAP Ground Segment: https://planning.enmap.org/
- EnMAP Data Archive: Contact DLR

### Community
- QGIS Forums: https://gis.stackexchange.com/
- EnMAP-Box GitHub: https://github.com/EnMAP-Box/enmap-box

### Citation

When using this plugin, please cite:
```
EnMAP Mission: Guanter, L., et al. (2015). The EnMAP Spaceborne Imaging 
Spectroscopy Mission for Earth Observation. Remote Sensing, 7(7), 8830-8857.
```

---

**Last Updated**: January 2026  
**Plugin Version**: 1.0
