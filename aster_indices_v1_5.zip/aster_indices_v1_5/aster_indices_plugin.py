"""
ASTER Indices Plugin - Plugin loader for QGIS.
Registers the processing provider on plugin load.
"""

from qgis.core import QgsApplication
from .aster_indices_provider import AsterIndicesProvider


class AsterIndicesPlugin:
    """QGIS Plugin wrapper that registers the Processing provider."""

    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initProcessing(self):
        self.provider = AsterIndicesProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()

    def unload(self):
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
