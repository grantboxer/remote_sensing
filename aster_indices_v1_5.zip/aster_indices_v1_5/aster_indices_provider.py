"""
ASTER Indices Processing Provider.
"""

from qgis.core import QgsProcessingProvider
from .aster_indices_algorithm import AsterIndicesAlgorithm


class AsterIndicesProvider(QgsProcessingProvider):

    def loadAlgorithms(self):
        self.addAlgorithm(AsterIndicesAlgorithm())

    def id(self):
        return 'asterindices'

    def name(self):
        return 'ASTER Indices'

    def longName(self):
        return 'ASTER Satellite Geological Indices'

    def icon(self):
        return QgsProcessingProvider.icon(self)
