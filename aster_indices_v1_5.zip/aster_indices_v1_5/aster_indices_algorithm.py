"""
ASTER Indices Algorithm for QGIS Processing Framework.
Version 1.5

Computes a comprehensive suite of ASTER band ratio indices for geological
remote sensing and mineral exploration. ASTER band files are auto-detected
from a user-selected folder.

Band Detection:
    Searches the selected folder for GeoTIFF files matching ASTER band naming
    conventions. Supports standard ASTER L1T/L2 naming patterns where band
    numbers appear as 'Band1', 'Band01', 'B1', 'B01', '_1.tif', '_01.tif',
    etc. Files are matched to ASTER bands 1-14.

Indices Computed:
    VNIR/SWIR Ratios:
        - Alunite-Kaolinite-Pyrophyllite (AKP): (B4+B6)/B5
        - Clay: B5/B6
        - Amphibole: B6/B8
        - Kaolinite: B7/B5
        - Dolomite: (B6+B8)/B7
        - Laterite: B4/B5
        - Host Rock: B5/B6
        - Gossan: B4/B2 (B4 resampled to 15m)
        - Amphibole MgOH: (B6+B9)/B8
        - Epidote-Chlorite-Amphibole: (B6+B9)/(B7+B8)
        - Muscovite: B7/B6
        - Phengitic: B5/B6
        - Sericite-Muscovite-Illite-Smectite (SMIS): (B5+B7)/B6
        - Carbonate-Chlorite-Epidote: (B7+B9)/B8
        - Alteration: B4/B5
        - NDVI: (B3-B2)/(B3+B2)
        - Ferric Oxides: B4/B3 (B4 resampled to 15m)
        - Ferrous Silicates: B5/B4
        - Ferric Iron Ratio: B2/B1
        - Ferrous Iron Ratio: (B5/B3)+(B1/B2) (B5 resampled to 15m)
    TIR:
        - Carbonate: B13/B14
    Composites:
        - Natural Colour (B3, B2, B1)
        - Geological Discrimination 1 (B4/B1, B3/B1, B2/B1)
        - Geological Discrimination 2 (B4/B1, B4/B5, B4/B7)
        - Geological Discrimination 3 (B4/B7, Ferric Oxides, Ferric Iron Ratio)
"""

import os
import re
import glob
from typing import Any, Optional

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterFile,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFolderDestination,
    QgsRasterLayer,
    QgsRasterBandStats,
    QgsRectangle,
    QgsContrastEnhancement,
    QgsRasterMinMaxOrigin,
    QgsSingleBandGrayRenderer,
    QgsMultiBandColorRenderer,
    QgsProject,
)
from qgis import processing


class AsterIndicesAlgorithm(QgsProcessingAlgorithm):
    """Compute geological indices from ASTER satellite band files."""

    # Parameter keys
    INPUT_FOLDER = 'INPUT_FOLDER'
    SCENE_NAME = 'SCENE_NAME'
    OUTPUT_FOLDER = 'OUTPUT_FOLDER'
    LOAD_OUTPUTS = 'LOAD_OUTPUTS'

    # -------------------------------------------------------------------------
    # Band detection helpers
    # -------------------------------------------------------------------------
    @staticmethod
    def detect_bands(folder: str) -> dict:
        """
        Scan *folder* for ASTER band files and return a dict mapping
        band number (int 1-14) to the file path.

        Supports common ASTER naming conventions:
            AST_L1T_003..._Band1.tif
            AST_L1T_..._B01.tif
            ASTER_Band3N.tif
            band_1.tif / band01.tif
            B1.tif / B01.tif
            ..._1.tif / ..._01.tif
        """
        bands = {}
        # Collect all TIFF files in the folder (non-recursive)
        tif_files = []
        for ext in ('*.tif', '*.tiff', '*.TIF', '*.TIFF'):
            tif_files.extend(glob.glob(os.path.join(folder, ext)))

        # Patterns ordered from most specific to least specific
        # Each pattern captures the band number in group 1
        patterns = [
            # Band3N -> band 3 (ASTER VNIR nadir)
            re.compile(r'[Bb]and[_]?(\d{1,2})[Nn]', re.IGNORECASE),
            # Band1, Band01, Band_1, Band_01
            re.compile(r'[Bb]and[_]?0?(\d{1,2})(?!\d)', re.IGNORECASE),
            # B1, B01, B_1, B_01 (word boundary before B)
            re.compile(r'(?<![A-Za-z])[Bb][_]?0?(\d{1,2})(?!\d)'),
            # _1.tif, _01.tif (just before extension)
            re.compile(r'_0?(\d{1,2})\.\w+$'),
        ]

        for fpath in tif_files:
            fname = os.path.basename(fpath)
            for pat in patterns:
                m = pat.search(fname)
                if m:
                    bnum = int(m.group(1))
                    if 1 <= bnum <= 14:
                        # Only assign if not already matched (first pattern wins)
                        if bnum not in bands:
                            bands[bnum] = fpath
                    break  # stop after first matching pattern

        return bands

    # -------------------------------------------------------------------------
    # Algorithm definition
    # -------------------------------------------------------------------------
    def initAlgorithm(self, config: Optional[dict[str, Any]] = None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT_FOLDER,
                'ASTER Band Folder',
                behavior=QgsProcessingParameterFile.Folder,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.SCENE_NAME,
                'Scene Name (used as output filename prefix)',
                defaultValue='ASTER',
            )
        )

        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_FOLDER,
                'Output Folder',
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.LOAD_OUTPUTS,
                'Load output layers into project',
                defaultValue=True,
            )
        )

    # ------------------------------------------------------------------
    #  Helpers used inside processAlgorithm
    # ------------------------------------------------------------------
    def _out_path(self, output_dir: str, scene: str, suffix: str) -> str:
        """Build an output GeoTIFF path."""
        return os.path.join(output_dir, f'{scene}_{suffix}.tif')

    def _calc(self, formula, inputs, context, feedback, extent_opt=0):
        """
        Run gdal:rastercalculator with a simplified interface.
        *inputs* is a dict like {'A': path, 'B': path, ...}
        """
        letters = 'ABCDEF'
        params = {
            'FORMULA': formula,
            'NO_DATA': 0,
            'EXTENT_OPT': extent_opt,
            'EXTRA': None,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT,
        }
        for letter in letters:
            if letter in inputs:
                params[f'INPUT_{letter}'] = inputs[letter]
                params[f'BAND_{letter}'] = 1
            else:
                params[f'INPUT_{letter}'] = None
                params[f'BAND_{letter}'] = None
        return processing.run(
            'gdal:rastercalculator', params,
            context=context, feedback=feedback, is_child_algorithm=True,
        )

    def _save(self, src_path, dst_path, context, feedback):
        """Save a raster using gdal:translate (LZW-compressed GeoTIFF)."""
        params = {
            'INPUT': src_path,
            'TARGET_CRS': None,
            'NODATA': None,
            'COPY_SUBDATASETS': False,
            'OPTIONS': 'COMPRESS=LZW|PREDICTOR=2|BIGTIFF=YES',
            'EXTRA': '',
            'DATA_TYPE': 0,  # Use Input Layer Data Type
            'OUTPUT': dst_path,
        }
        return processing.run(
            'gdal:translate', params,
            context=context, feedback=feedback, is_child_algorithm=True,
        )

    def _resample_to_15m(self, input_path, context, feedback):
        """
        Resample a SWIR band (30 m) to 15 m to match VNIR resolution,
        using gdal:warpreproject with bilinear resampling.
        """
        params = {
            'INPUT': input_path,
            'SOURCE_CRS': None,
            'TARGET_CRS': None,
            'RESAMPLING': 1,  # Bilinear
            'NODATA': 0,
            'TARGET_RESOLUTION': 15,
            'OPTIONS': '',
            'DATA_TYPE': 0,
            'TARGET_EXTENT': None,
            'TARGET_EXTENT_CRS': None,
            'MULTITHREADING': True,
            'EXTRA': '',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT,
        }
        return processing.run(
            'gdal:warpreproject', params,
            context=context, feedback=feedback, is_child_algorithm=True,
        )

    def _build_vrt(self, layer_list, crs, separate, context, feedback):
        """Build a virtual raster (VRT) composite."""
        params = {
            'INPUT': layer_list,
            'RESOLUTION': 1,       # Highest
            'SEPARATE': separate,
            'PROJ_DIFFERENCE': True,
            'ADD_ALPHA': False,
            'ASSIGN_CRS': crs,
            'RESAMPLING': 0,       # Nearest Neighbour
            'SRC_NODATA': None,
            'EXTRA': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT,
        }
        return processing.run(
            'gdal:buildvirtualraster', params,
            context=context, feedback=feedback, is_child_algorithm=True,
        )

    # Names of outputs that are 3-band RGB composites
    MULTIBAND_OUTPUTS = {'NatCol', 'GeolDiscrim1', 'GeolDiscrim2', 'GeolDiscrim3'}

    def _apply_stretch(self, layer_path: str, name: str, feedback):
        """
        Open the saved raster, compute a 2-98% cumulative count cut stretch
        from the central 50% of the image area, apply it as the default
        renderer, and save a .qml sidecar style file so the stretch persists
        when the layer is opened later.
        """
        layer = QgsRasterLayer(layer_path, name)
        if not layer.isValid():
            feedback.pushInfo(f'  Warning: could not open {layer_path} for styling.')
            return

        provider = layer.dataProvider()
        subset_extent = self._central_extent(layer.extent(), 0.5)
        is_multiband = name in self.MULTIBAND_OUTPUTS and provider.bandCount() >= 3

        if is_multiband:
            self._apply_multiband_stretch(layer, provider, subset_extent, feedback)
        else:
            self._apply_singleband_stretch(layer, provider, subset_extent, feedback)

        # Save QML sidecar
        qml_path = os.path.splitext(layer_path)[0] + '.qml'
        msg, ok = layer.saveNamedStyle(qml_path)
        if ok:
            feedback.pushInfo(f'  Saved style: {os.path.basename(qml_path)}')
        else:
            feedback.pushInfo(f'  Warning: could not save style for {name}: {msg}')

    @staticmethod
    def _central_extent(extent: QgsRectangle, fraction: float) -> QgsRectangle:
        """
        Return a QgsRectangle covering the central *fraction* (0-1) of the
        image area.  fraction=0.5 gives a rectangle whose width and height
        are each ~70.7% of the original (sqrt(0.5)), centred on the image
        centre, so the area is 50% of the full extent.
        """
        import math
        scale = math.sqrt(fraction)  # linear scale factor for 50% area
        cx = extent.center().x()
        cy = extent.center().y()
        half_w = extent.width() * scale / 2.0
        half_h = extent.height() * scale / 2.0
        return QgsRectangle(cx - half_w, cy - half_h, cx + half_w, cy + half_h)

    def _apply_singleband_stretch(self, layer, provider, extent, feedback):
        """Apply a 2-98% grey stretch from the central subset of a single-band raster."""
        stats = provider.bandStatistics(
            1, QgsRasterBandStats.All, extent, 0
        )

        # Use mean +/- 2.5 stdDev as a robust approximation of 2-98%
        # cumulative cut, clamped to the actual data min/max.
        mean = stats.mean
        std = stats.stdDev
        stretch_min = max(stats.minimumValue, mean - 2.5 * std)
        stretch_max = min(stats.maximumValue, mean + 2.5 * std)

        # Avoid degenerate stretch
        if stretch_max <= stretch_min:
            stretch_min = stats.minimumValue
            stretch_max = stats.maximumValue

        ce = QgsContrastEnhancement(provider.dataType(1))
        ce.setContrastEnhancementAlgorithm(
            QgsContrastEnhancement.StretchToMinimumMaximum, False
        )
        ce.setMinimumValue(stretch_min)
        ce.setMaximumValue(stretch_max)

        renderer = QgsSingleBandGrayRenderer(provider, 1)
        renderer.setContrastEnhancement(ce)

        mm_origin = QgsRasterMinMaxOrigin()
        mm_origin.setLimits(QgsRasterMinMaxOrigin.CumulativeCut)
        mm_origin.setCumulativeCutLower(0.02)
        mm_origin.setCumulativeCutUpper(0.98)
        renderer.setMinMaxOrigin(mm_origin)

        layer.setRenderer(renderer)
        layer.triggerRepaint()

    def _apply_multiband_stretch(self, layer, provider, extent, feedback):
        """Apply a 2-98% RGB stretch from the central subset of a 3-band composite."""
        enhancements = []
        for band in (1, 2, 3):
            stats = provider.bandStatistics(
                band, QgsRasterBandStats.All, extent, 0
            )
            mean = stats.mean
            std = stats.stdDev
            stretch_min = max(stats.minimumValue, mean - 2.5 * std)
            stretch_max = min(stats.maximumValue, mean + 2.5 * std)
            if stretch_max <= stretch_min:
                stretch_min = stats.minimumValue
                stretch_max = stats.maximumValue

            ce = QgsContrastEnhancement(provider.dataType(band))
            ce.setContrastEnhancementAlgorithm(
                QgsContrastEnhancement.StretchToMinimumMaximum, False
            )
            ce.setMinimumValue(stretch_min)
            ce.setMaximumValue(stretch_max)
            enhancements.append(ce)

        renderer = QgsMultiBandColorRenderer(provider, 1, 2, 3)
        renderer.setRedContrastEnhancement(enhancements[0])
        renderer.setGreenContrastEnhancement(enhancements[1])
        renderer.setBlueContrastEnhancement(enhancements[2])

        mm_origin = QgsRasterMinMaxOrigin()
        mm_origin.setLimits(QgsRasterMinMaxOrigin.CumulativeCut)
        mm_origin.setCumulativeCutLower(0.02)
        mm_origin.setCumulativeCutUpper(0.98)
        renderer.setMinMaxOrigin(mm_origin)

        layer.setRenderer(renderer)
        layer.triggerRepaint()

    def _load_layer(self, path, name, context, feedback):
        """
        Load a raster layer into the current QGIS project and apply
        the QML sidecar style file if it exists.
        """
        layer = QgsRasterLayer(path, name)
        if not layer.isValid():
            feedback.pushInfo(f'  Warning: could not load {path}')
            return

        # Apply QML style if sidecar exists
        qml_path = os.path.splitext(path)[0] + '.qml'
        if os.path.exists(qml_path):
            msg, ok = layer.loadNamedStyle(qml_path)
            if ok:
                feedback.pushInfo(f'  Applied style to {name}')
            else:
                feedback.pushInfo(f'  Warning: style load failed for {name}: {msg}')
            layer.triggerRepaint()

        QgsProject.instance().addMapLayer(layer)

    # ------------------------------------------------------------------
    #  Main processing
    # ------------------------------------------------------------------
    def processAlgorithm(
        self,
        parameters: dict[str, Any],
        context: QgsProcessingContext,
        model_feedback: QgsProcessingFeedback,
    ) -> dict[str, Any]:

        # Total steps: 24 index calculations + 3 resamples + 4 composites
        #            + up to 27 saves + up to 27 loads  ≈ 68 steps
        feedback = QgsProcessingMultiStepFeedback(68, model_feedback)
        step = 0

        input_folder = self.parameterAsString(parameters, self.INPUT_FOLDER, context)
        scene = self.parameterAsString(parameters, self.SCENE_NAME, context)
        output_dir = self.parameterAsString(parameters, self.OUTPUT_FOLDER, context)
        load_outputs = self.parameterAsBool(parameters, self.LOAD_OUTPUTS, context)

        os.makedirs(output_dir, exist_ok=True)

        # ----- Detect bands -----
        bands = self.detect_bands(input_folder)
        feedback.pushInfo(f'Detected {len(bands)} ASTER bands in: {input_folder}')
        for bnum in sorted(bands.keys()):
            feedback.pushInfo(f'  Band {bnum}: {os.path.basename(bands[bnum])}')

        # Validate minimum required bands
        vnir_swir = {1, 2, 3, 4, 5, 6, 7, 8, 9}
        tir = {13, 14}
        missing_vnir_swir = vnir_swir - set(bands.keys())
        missing_tir = tir - set(bands.keys())

        if missing_vnir_swir:
            feedback.reportError(
                f'Missing VNIR/SWIR bands: {sorted(missing_vnir_swir)}. '
                'Indices requiring these bands will be skipped.'
            )
        if missing_tir:
            feedback.reportError(
                f'Missing TIR bands: {sorted(missing_tir)}. '
                'TIR indices (Carbonate 13/14) will be skipped.'
            )

        # Detect CRS from the first available band file
        first_band = bands[sorted(bands.keys())[0]]
        tmp_layer = QgsRasterLayer(first_band, 'tmp')
        if tmp_layer.isValid() and tmp_layer.crs().isValid():
            crs = tmp_layer.crs()
            feedback.pushInfo(f'CRS detected from band data: {crs.authid()}')
        else:
            crs = None
            feedback.pushInfo('No CRS detected from band data; composites will inherit source CRS.')

        if len(bands) < 2:
            raise Exception(
                f'Only {len(bands)} band(s) detected in {input_folder}. '
                'At least VNIR/SWIR bands 1-9 are required. '
                'Check that files follow ASTER naming conventions '
                '(e.g. Band1.tif, B01.tif, etc.).'
            )

        # Shorthand
        B = bands  # B[1] .. B[14]

        def has(*nums):
            return all(n in B for n in nums)

        outputs = {}
        results = {}

        # -----------------------------------------------------------------
        # Helper to advance step with cancellation check
        # -----------------------------------------------------------------
        def next_step():
            nonlocal step
            step += 1
            feedback.setCurrentStep(step)
            if feedback.isCanceled():
                return True
            return False

        # =================================================================
        #  RESAMPLING  (B4, B5 to 15m for cross-resolution ratios)
        # =================================================================
        b4_15m = None
        if has(4):
            feedback.pushInfo('Resampling Band 4 to 15 m ...')
            res = self._resample_to_15m(B[4], context, feedback)
            b4_15m = res['OUTPUT']
        if next_step():
            return {}

        b5_15m = None
        if has(5):
            feedback.pushInfo('Resampling Band 5 to 15 m ...')
            res = self._resample_to_15m(B[5], context, feedback)
            b5_15m = res['OUTPUT']
        if next_step():
            return {}

        # =================================================================
        #  INDEX CALCULATIONS
        # =================================================================
        index_results = {}  # name -> temp output path

        # --- Alunite-Kaolinite-Pyrophyllite (4+6)/5 ---
        if has(4, 5, 6):
            feedback.pushInfo('Computing AKP (4+6)/5 ...')
            r = self._calc('(A+B)/C', {'A': B[4], 'B': B[6], 'C': B[5]}, context, feedback)
            index_results['AKP'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Clay 5/6 ---
        if has(5, 6):
            feedback.pushInfo('Computing Clay 5/6 ...')
            r = self._calc('A/B', {'A': B[5], 'B': B[6]}, context, feedback)
            index_results['Clay'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Amphibole 6/8 ---
        if has(6, 8):
            feedback.pushInfo('Computing Amphibole 6/8 ...')
            r = self._calc('A/B', {'A': B[6], 'B': B[8]}, context, feedback, extent_opt=3)
            index_results['Amphibole'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Kaolinite 7/5 ---
        if has(5, 7):
            feedback.pushInfo('Computing Kaolinite 7/5 ...')
            r = self._calc('A/B', {'A': B[7], 'B': B[5]}, context, feedback)
            index_results['Kaolinite'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Dolomite (6+8)/7 ---
        if has(6, 7, 8):
            feedback.pushInfo('Computing Dolomite (6+8)/7 ...')
            r = self._calc('(A+B)/C', {'A': B[6], 'B': B[8], 'C': B[7]}, context, feedback, extent_opt=3)
            index_results['Dolomite'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Laterite 4/5 ---
        if has(4, 5):
            feedback.pushInfo('Computing Laterite 4/5 ...')
            r = self._calc('(A/B)', {'A': B[4], 'B': B[5]}, context, feedback)
            index_results['Laterite'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Host Rock 5/6 ---
        if has(5, 6):
            feedback.pushInfo('Computing Host Rock 5/6 ...')
            r = self._calc('A/B', {'A': B[5], 'B': B[6]}, context, feedback)
            index_results['HostRock'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Gossan 4/2 (B4 resampled to 15 m) ---
        if b4_15m and has(2):
            feedback.pushInfo('Computing Gossan 4/2 ...')
            r = self._calc('A/B', {'A': b4_15m, 'B': B[2]}, context, feedback, extent_opt=3)
            index_results['Gossan'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Amphibole MgOH (6+9)/8 ---
        if has(6, 8, 9):
            feedback.pushInfo('Computing Amphibole MgOH (6+9)/8 ...')
            r = self._calc('(A+B)/C', {'A': B[6], 'B': B[9], 'C': B[8]}, context, feedback, extent_opt=3)
            index_results['Amph-MgOH'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Epidote-Chlorite-Amphibole (6+9)/(7+8) ---
        if has(6, 7, 8, 9):
            feedback.pushInfo('Computing Epidote-Chlor-Amph (6+9)/(7+8) ...')
            r = self._calc('(A+B)/(C+D)', {'A': B[6], 'B': B[9], 'C': B[7], 'D': B[8]}, context, feedback)
            index_results['Ep-Chl-Amph'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Muscovite 7/6 ---
        if has(6, 7):
            feedback.pushInfo('Computing Muscovite 7/6 ...')
            r = self._calc('A/B', {'A': B[7], 'B': B[6]}, context, feedback)
            index_results['Muscovite'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Phengitic 5/6 ---
        if has(5, 6):
            feedback.pushInfo('Computing Phengitic 5/6 ...')
            r = self._calc('A/B', {'A': B[5], 'B': B[6]}, context, feedback, extent_opt=3)
            index_results['Phengitic'] = r['OUTPUT']
        if next_step():
            return {}

        # --- SMIS (5+7)/6 ---
        if has(5, 6, 7):
            feedback.pushInfo('Computing SMIS (5+7)/6 ...')
            r = self._calc('(A+B)/C', {'A': B[5], 'B': B[7], 'C': B[6]}, context, feedback)
            index_results['SMIS'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Carbonate-Chlorite-Epidote (7+9)/8 ---
        if has(7, 8, 9):
            feedback.pushInfo('Computing Carb-Chl-Ep (7+9)/8 ...')
            r = self._calc('(A+B)/C', {'A': B[7], 'B': B[9], 'C': B[8]}, context, feedback)
            index_results['Carb-Chl-Ep'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Alteration 4/5 ---
        if has(4, 5):
            feedback.pushInfo('Computing Alteration 4/5 ...')
            r = self._calc('A/B', {'A': B[4], 'B': B[5]}, context, feedback)
            index_results['Alteration'] = r['OUTPUT']
        if next_step():
            return {}

        # --- NDVI (3-2)/(3+2) ---
        if has(2, 3):
            feedback.pushInfo('Computing NDVI (3-2)/(3+2) ...')
            r = self._calc('(A-B)/(A+B)', {'A': B[3], 'B': B[2]}, context, feedback, extent_opt=2)
            index_results['NDVI'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Ferric Oxides 4/3 (B4 resampled to 15 m) ---
        if b4_15m and has(3):
            feedback.pushInfo('Computing Ferric Oxides 4/3 ...')
            r = self._calc('(A/B)', {'A': b4_15m, 'B': B[3]}, context, feedback, extent_opt=3)
            index_results['FerricOxides'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Ferrous Silicates 5/4 ---
        if has(4, 5):
            feedback.pushInfo('Computing Ferrous Silicates 5/4 ...')
            r = self._calc('(A/B)', {'A': B[5], 'B': B[4]}, context, feedback, extent_opt=3)
            index_results['FerrousSilicates'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Ferric Iron Ratio 2/1 ---
        if has(1, 2):
            feedback.pushInfo('Computing Ferric Iron Ratio 2/1 ...')
            r = self._calc('A/B', {'A': B[2], 'B': B[1]}, context, feedback)
            index_results['FerricIronRatio'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Ferrous Iron Ratio (5/3)+(1/2) (B5 resampled to 15 m) ---
        if b5_15m and has(1, 2, 3):
            feedback.pushInfo('Computing Ferrous Iron Ratio (5/3)+(1/2) ...')
            r = self._calc(
                '(A/B)+(C/D)',
                {'A': b5_15m, 'B': B[3], 'C': B[1], 'D': B[2]},
                context, feedback, extent_opt=3,
            )
            index_results['FerrousIronRatio'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Carbonate 13/14 (TIR) ---
        if has(13, 14):
            feedback.pushInfo('Computing Carbonate 13/14 ...')
            r = self._calc('A/B', {'A': B[13], 'B': B[14]}, context, feedback)
            index_results['Carbonate'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Ratio components for composites ---
        # B3/B1
        b3_d_b1 = None
        if has(1, 3):
            r = self._calc('A/B', {'A': B[3], 'B': B[1]}, context, feedback)
            b3_d_b1 = r['OUTPUT']
        if next_step():
            return {}

        # B4/B1 (resampled B4)
        b4_d_b1 = None
        if b4_15m and has(1):
            r = self._calc('A/B', {'A': b4_15m, 'B': B[1]}, context, feedback, extent_opt=3)
            b4_d_b1 = r['OUTPUT']
        if next_step():
            return {}

        # B2/B1 (same as FerricIronRatio but keep separate ref)
        b2_d_b1 = index_results.get('FerricIronRatio')

        # B4/B7
        b4_d_b7 = None
        if has(4, 7):
            r = self._calc('A/B', {'A': B[4], 'B': B[7]}, context, feedback)
            b4_d_b7 = r['OUTPUT']
        if next_step():
            return {}

        # B4/B5 (same as Laterite)
        b4_d_b5 = index_results.get('Laterite')

        # =================================================================
        #  COMPOSITES  (VRT stacks)
        # =================================================================

        # --- Natural Colour (B3, B2, B1) ---
        if has(1, 2, 3):
            feedback.pushInfo('Building Natural Colour composite ...')
            r = self._build_vrt(
                [B[3], B[2], B[1]], crs, True, context, feedback,
            )
            index_results['NatCol'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Geological Discrimination 1: B4/B1, B3/B1, B2/B1 ---
        if all(x is not None for x in [b4_d_b1, b3_d_b1, b2_d_b1]):
            feedback.pushInfo('Building Geol Discrimination 1 composite ...')
            r = self._build_vrt(
                [b4_d_b1, b3_d_b1, b2_d_b1], crs, True, context, feedback,
            )
            index_results['GeolDiscrim1'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Geological Discrimination 2: B4/B1, B4/B5, B4/B7 ---
        if all(x is not None for x in [b4_d_b1, b4_d_b5, b4_d_b7]):
            feedback.pushInfo('Building Geol Discrimination 2 composite ...')
            r = self._build_vrt(
                [b4_d_b1, b4_d_b5, b4_d_b7], crs, True, context, feedback,
            )
            index_results['GeolDiscrim2'] = r['OUTPUT']
        if next_step():
            return {}

        # --- Geological Discrimination 3: B4/B7, FerricOxides, FerricIronRatio ---
        if all(
            x is not None
            for x in [b4_d_b7, index_results.get('FerricOxides'), b2_d_b1]
        ):
            feedback.pushInfo('Building Geol Discrimination 3 composite ...')
            r = self._build_vrt(
                [b4_d_b7, index_results['FerricOxides'], b2_d_b1],
                crs, True, context, feedback,
            )
            index_results['GeolDiscrim3'] = r['OUTPUT']
        if next_step():
            return {}

        # =================================================================
        #  SAVE OUTPUTS & APPLY DEFAULT STRETCHES
        # =================================================================
        feedback.pushInfo(f'Saving {len(index_results)} outputs to {output_dir} ...')
        saved_paths = {}
        for name, tmp_path in index_results.items():
            out_path = self._out_path(output_dir, scene, name)
            feedback.pushInfo(f'  Saving {name} -> {os.path.basename(out_path)}')
            self._save(tmp_path, out_path, context, feedback)
            saved_paths[name] = out_path
            results[f'OUTPUT_{name.upper().replace("-", "_")}'] = out_path
            # Compute statistics and write QML style sidecar
            feedback.pushInfo(f'  Computing stretch for {name} ...')
            self._apply_stretch(out_path, name, feedback)
            if next_step():
                return {}

        # =================================================================
        #  LOAD INTO PROJECT
        # =================================================================
        display_names = {
            'AKP': 'Alunite-Kaol-Pyrophyllite',
            'Clay': 'Clay',
            'Amphibole': 'Amphibole',
            'Kaolinite': 'Kaolinite',
            'Dolomite': 'Dolomite',
            'Laterite': 'Laterite',
            'HostRock': 'Host Rock',
            'Gossan': 'Gossan',
            'Amph-MgOH': 'Amphibole-MgOH',
            'Ep-Chl-Amph': 'Epidote-Chlorite-Amph',
            'Muscovite': 'Muscovite',
            'Phengitic': 'Phengitic',
            'SMIS': 'Sericite-Musc-Illite-Smectite',
            'Carb-Chl-Ep': 'Carbonate-Chlorite-Epidote',
            'Alteration': 'Alteration',
            'NDVI': 'NDVI',
            'FerricOxides': 'Ferric Oxides',
            'FerrousSilicates': 'Ferrous Silicates',
            'FerricIronRatio': 'Ferric Iron Ratio',
            'FerrousIronRatio': 'Ferrous Iron Ratio',
            'Carbonate': 'Carbonate',
            'NatCol': 'Natural Colour',
            'GeolDiscrim1': 'Geol Discrimination 1',
            'GeolDiscrim2': 'Geol Discrimination 2',
            'GeolDiscrim3': 'Geol Discrimination 3',
        }

        if load_outputs:
            feedback.pushInfo('Loading outputs into QGIS project ...')
            for name, path in saved_paths.items():
                label = display_names.get(name, name)
                self._load_layer(path, label, context, feedback)
                if next_step():
                    return {}

        feedback.pushInfo('ASTER Indices processing complete.')
        return results

    # ------------------------------------------------------------------
    #  Algorithm metadata
    # ------------------------------------------------------------------
    def name(self) -> str:
        return 'asterindices'

    def displayName(self) -> str:
        return 'ASTER Indices'

    def group(self) -> str:
        return 'ASTER'

    def groupId(self) -> str:
        return 'aster'

    def shortHelpString(self) -> str:
        return (
            'Computes a comprehensive suite of ASTER band ratio indices for '
            'geological remote sensing and mineral exploration.\n\n'
            'INPUTS:\n'
            '  ASTER Band Folder – folder containing ASTER band GeoTIFF files.\n'
            '    Band files are auto-detected by filename pattern (Band1.tif, '
            'B01.tif, etc.).\n'
            '  Scene Name – prefix for output filenames.\n'
            '  Output Folder – destination for saved GeoTIFF outputs.\n\n'
            'The CRS is automatically detected from the input band files.\n\n'
            'INDICES COMPUTED:\n'
            '  AKP (4+6)/5, Clay 5/6, Amphibole 6/8, Kaolinite 7/5,\n'
            '  Dolomite (6+8)/7, Laterite 4/5, Host Rock 5/6, Gossan 4/2,\n'
            '  Amphibole MgOH (6+9)/8, Epidote-Chlor-Amph (6+9)/(7+8),\n'
            '  Muscovite 7/6, Phengitic 5/6, SMIS (5+7)/6,\n'
            '  Carb-Chl-Ep (7+9)/8, Alteration 4/5,\n'
            '  NDVI (3-2)/(3+2), Ferric Oxides 4/3, Ferrous Silicates 5/4,\n'
            '  Ferric Iron Ratio 2/1, Ferrous Iron Ratio (5/3)+(1/2),\n'
            '  Carbonate 13/14,\n'
            '  Natural Colour (B3,B2,B1),\n'
            '  Geol Discrimination 1 (4/1, 3/1, 2/1),\n'
            '  Geol Discrimination 2 (4/1, 4/5, 4/7),\n'
            '  Geol Discrimination 3 (4/7, FerricOx, FerricFe).\n\n'
            'SWIR bands used in cross-resolution ratios (Gossan, Ferric Oxides, '
            'Ferrous Iron Ratio) are automatically resampled to 15 m to match '
            'VNIR resolution.\n\n'
            'Outputs are saved as LZW-compressed GeoTIFFs and optionally loaded '
            'into the current QGIS project.'
        )

    def createInstance(self):
        return AsterIndicesAlgorithm()
