#!/bin/bash
# Package the EnMAP Processor plugin for distribution

PLUGIN_NAME="enmap_processor_plugin"
VERSION="1.0"
OUTPUT_NAME="${PLUGIN_NAME}_v${VERSION}.zip"

echo "Packaging EnMAP Processor Plugin v${VERSION}..."

# Create a temporary directory for packaging
TEMP_DIR=$(mktemp -d)
PLUGIN_DIR="${TEMP_DIR}/${PLUGIN_NAME}"

# Create plugin directory structure
mkdir -p "${PLUGIN_DIR}"

# Copy plugin files
echo "Copying plugin files..."
cp __init__.py "${PLUGIN_DIR}/"
cp metadata.txt "${PLUGIN_DIR}/"
cp enmap_processing_algorithm_full.py "${PLUGIN_DIR}/"
cp README.md "${PLUGIN_DIR}/"
cp INSTALL.md "${PLUGIN_DIR}/"
cp USER_GUIDE.md "${PLUGIN_DIR}/"
cp example_usage.py "${PLUGIN_DIR}/"

# Create a simple icon if none exists
if [ ! -f "icon.png" ]; then
    echo "Note: No icon.png found. Plugin will use default QGIS icon."
fi

# Create the ZIP file
cd "${TEMP_DIR}"
zip -r "${OUTPUT_NAME}" "${PLUGIN_NAME}"

# Move to current directory
mv "${OUTPUT_NAME}" "${OLDPWD}/"

# Cleanup
cd "${OLDPWD}"
rm -rf "${TEMP_DIR}"

echo "Plugin packaged successfully!"
echo "Output file: ${OUTPUT_NAME}"
echo ""
echo "To install:"
echo "1. Open QGIS"
echo "2. Go to Plugins → Manage and Install Plugins"
echo "3. Click 'Install from ZIP'"
echo "4. Select ${OUTPUT_NAME}"
echo "5. Click 'Install Plugin'"
