# EnMAP Processor Plugin - Installation Guide

## Quick Start

### Prerequisites
1. QGIS 3.0 or higher installed
2. EnMAP-Box plugin installed (available from QGIS Plugin Repository)

### Installation Steps

#### Windows
```batch
# 1. Locate your QGIS plugins directory
%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\

# 2. Copy the enmap_processor_plugin folder to this location

# 3. Restart QGIS

# 4. Enable the plugin
#    Go to: Plugins → Manage and Install Plugins
#    Find "EnMAP Processor" and check the box
```

#### macOS
```bash
# 1. Open Terminal

# 2. Navigate to QGIS plugins directory
cd ~/Library/Application\ Support/QGIS/QGIS3/profiles/default/python/plugins/

# 3. Copy the plugin folder here
cp -r /path/to/enmap_processor_plugin .

# 4. Restart QGIS

# 5. Enable the plugin
#    Go to: Plugins → Manage and Install Plugins
#    Find "EnMAP Processor" and check the box
```

#### Linux
```bash
# 1. Navigate to QGIS plugins directory
cd ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/

# 2. Copy the plugin folder
cp -r /path/to/enmap_processor_plugin .

# 3. Set proper permissions
chmod -R 755 enmap_processor_plugin

# 4. Restart QGIS

# 5. Enable the plugin
#    Go to: Plugins → Manage and Install Plugins
#    Find "EnMAP Processor" and check the box
```

## Verifying Installation

1. Open QGIS
2. Go to `Processing` → `Toolbox`
3. Look for "Remote Sensing" section
4. You should see "EnMAP Spectral Indices Processor (Full)"

If you see this, installation was successful!

## Installing Dependencies

### EnMAP-Box Plugin

The EnMAP Processor requires the EnMAP-Box plugin. Install it as follows:

1. In QGIS, go to `Plugins` → `Manage and Install Plugins`
2. Click on "All" tab
3. Search for "EnMAP-Box"
4. Click "Install Plugin"
5. Wait for installation to complete
6. Restart QGIS

### Verify EnMAP-Box Installation

1. Go to `Processing` → `Toolbox`
2. Search for "enmap"
3. You should see various EnMAP-Box algorithms like:
   - "Import EnMAP L2A Product"
   - "Save Raster Layer As"
   - "Subset Raster Layer Bands"

## Troubleshooting Installation

### Plugin doesn't appear in the list

**Check installation path:**
```bash
# Windows
dir %APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\enmap_processor_plugin

# macOS/Linux
ls -la ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/enmap_processor_plugin
```

**Verify folder structure:**
```
enmap_processor_plugin/
├── __init__.py
├── metadata.txt
├── enmap_processing_algorithm_full.py
└── README.md
```

### Plugin fails to load

1. Check the QGIS Python Console for errors:
   - Go to `Plugins` → `Python Console`
   - Look for error messages

2. Common issues:
   - **Missing `__init__.py`**: Ensure file exists and is not empty
   - **Syntax errors**: Check Python files for errors
   - **Permission issues**: Ensure files are readable

### EnMAP-Box not found

If you get errors about EnMAP-Box algorithms:

1. Verify EnMAP-Box is installed:
   - `Plugins` → `Manage and Install Plugins`
   - Check if "EnMAP-Box" is installed and enabled

2. Restart QGIS after installing EnMAP-Box

3. If still not working, reinstall EnMAP-Box

## Manual Plugin Configuration

If automatic installation doesn't work, try manual configuration:

### Edit metadata.txt
```ini
[general]
name=EnMAP Processor
qgisMinimumVersion=3.0
description=Process EnMAP hyperspectral satellite imagery
version=1.0
author=Grant Boxer
email=boxerg@iinet.net.au
```

### Check Python path
In QGIS Python Console, run:
```python
import sys
print('\n'.join(sys.path))
```

Ensure your plugins directory is in the path.

## Updating the Plugin

To update to a new version:

1. **Backup your current installation** (optional but recommended)
2. **Delete the old plugin folder**
3. **Copy the new version** to the plugins directory
4. **Restart QGIS**

## Uninstalling

To remove the plugin:

1. In QGIS: `Plugins` → `Manage and Install Plugins`
2. Find "EnMAP Processor"
3. Click "Uninstall Plugin"

Or manually delete the folder:
```bash
# Navigate to plugins directory and remove
rm -rf enmap_processor_plugin
```

## Getting Help

If you encounter installation issues:

1. Check the QGIS logs:
   - `View` → `Panels` → `Log Messages`

2. Check Python Console for errors:
   - `Plugins` → `Python Console`

3. Report issues:
   - GitHub: [your-repo]/issues
   - Email: boxerg@iinet.net.au

## System Requirements

- **QGIS**: 3.0 or higher (3.16+ recommended)
- **Python**: 3.6+ (included with QGIS)
- **RAM**: 8GB minimum, 16GB recommended
- **Disk Space**: 10GB free space for processing
- **Operating System**: Windows 10+, macOS 10.13+, or Linux

## Next Steps

After successful installation:

1. Read the [README.md](README.md) for usage instructions
2. Prepare your EnMAP L2A data
3. Run a test on a small scene
4. Review the outputs

Happy processing!
