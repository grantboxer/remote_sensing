"""
EnMAP Processor Plugin
A QGIS plugin for processing EnMAP hyperspectral satellite imagery
"""

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsProcessingProvider, QgsApplication
import os.path

from .enmap_processing_algorithm_full import EnMapProcessingAlgorithm


class EnMapProcessorProvider(QgsProcessingProvider):
    def loadAlgorithms(self, *args, **kwargs):
        self.addAlgorithm(EnMapProcessingAlgorithm())

    def id(self, *args, **kwargs):
        return 'enmapprocessor'

    def name(self, *args, **kwargs):
        return 'EnMAP Processor'

    def icon(self):
        return QgsProcessingProvider.icon(self)


class EnMapProcessorPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.provider = None
        self.action = None
        self.menu = self.tr('&EnMAP Processor')

    def tr(self, message):
        """Get the translation for a string using Qt translation API."""
        return QCoreApplication.translate('EnMapProcessor', message)

    def initProcessing(self):
        """Initialize the processing provider"""
        self.provider = EnMapProcessorProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI"""
        # Initialize processing
        self.initProcessing()
        
        # Create action that will start plugin configuration
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        if not os.path.exists(icon_path):
            # Use default QGIS raster icon if custom icon doesn't exist
            icon = QIcon(':/images/themes/default/mActionAddRasterLayer.svg')
        else:
            icon = QIcon(icon_path)
        
        self.action = QAction(
            icon,
            self.tr('EnMAP Spectral Indices Processor'),
            self.iface.mainWindow()
        )
        
        # Connect the action to the run method
        self.action.triggered.connect(self.run)
        
        # Add toolbar button
        self.iface.addToolBarIcon(self.action)
        
        # Add menu item to Raster menu
        self.iface.addPluginToRasterMenu(self.menu, self.action)
        
        # Optional: Also add to Plugins menu
        # self.iface.addPluginToMenu(self.menu, self.action)

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI"""
        # Remove the plugin menu item and icon
        self.iface.removePluginRasterMenu(self.menu, self.action)
        self.iface.removeToolBarIcon(self.action)
        
        # Remove processing provider
        QgsApplication.processingRegistry().removeProvider(self.provider)

    def run(self):
        """Run method that opens the processing algorithm dialog"""
        # Import processing module
        from qgis import processing
        
        # Execute and open the processing algorithm dialog
        processing.execAlgorithmDialog(
            'enmapprocessor:enmap_spectral_indices_full',
            {}  # Empty dict for default parameters
        )


def classFactory(iface):
    return EnMapProcessorPlugin(iface)
