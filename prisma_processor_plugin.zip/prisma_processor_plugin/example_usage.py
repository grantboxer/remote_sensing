"""
Example script for using the PRISMA Processor plugin
This can be run from the QGIS Python console
"""

from qgis.core import QgsProcessingFeedback
from qgis import processing

# Example parameters - modify these for your data
params = {
    'output_prefix': 'MyTest',  # Prefix for output files
    'select_directory': 'C:/temp/processing',  # Output directory
    'select_prisma_file': 'C:/path/to/your/PRISMA_L2D_file.he5'  # PRISMA file
}

# Create feedback object to see progress
feedback = QgsProcessingFeedback()

# Run the algorithm
try:
    result = processing.run(
        "prismaprocessor:PRISMA_ENVI_Indices",
        params,
        feedback=feedback
    )
    print("Processing completed successfully!")
    print("Results:", result)
except Exception as e:
    print(f"Error during processing: {str(e)}")
    print("Check the Processing log for details")

# Notes:
# - Make sure the output directory exists before running
# - Ensure you have write permissions to the output directory
# - The PRISMA file should be a valid L2D HDF5 (.he5) file
# - Processing may take several minutes depending on scene size
