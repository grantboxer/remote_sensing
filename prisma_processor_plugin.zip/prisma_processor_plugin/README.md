# PRISMA Processor Plugin for QGIS

A QGIS plugin for importing and processing PRISMA hyperspectral satellite data to create mineral indices and alteration maps.

## Features

This plugin processes PRISMA L2D hyperspectral data to create the following mineral indices:

- **Alunite Composition (1480W)**
- **Kaolinite-Alunite-Pyrophyllite (2160W)**
- **SWIR-active Mafic Minerals**
- **Ferrous Silicates Index**
- **Ferric Iron Alteration Index**
- **MgOH Carbonate Abundance Index**
- **Phyllic Alteration Index**
- **Propylitic Alteration Index**
- **RGB Composite Layers** for visualization

## Requirements

- QGIS 3.0 or higher
- **EnMAP-Box plugin** (required for PRISMA data import)
- Python 3.x

## Installation

### Method 1: Manual Installation

1. Download or clone this repository
2. Copy the `prisma_processor_plugin` folder to your QGIS plugins directory:
   - **Windows**: `C:\Users\YourUsername\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - **macOS**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
   - **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`

3. Open QGIS and go to `Plugins > Manage and Install Plugins`
4. Click on the `Installed` tab
5. Find and enable "PRISMA Processor"

### Method 2: Install EnMAP-Box First

Before using this plugin, make sure you have installed the EnMAP-Box plugin:

1. In QGIS, go to `Plugins > Manage and Install Plugins`
2. Search for "EnMAP-Box"
3. Install the EnMAP-Box plugin
4. Then install this PRISMA Processor plugin

## Usage

### Running the Algorithm

1. Open QGIS
2. Go to `Processing > Toolbox`
3. Expand `PRISMA Processor > PRISMA Hyperspectral Data Processor`
4. Double-click on `PRISMA_ENVI_Indices`

### Input Parameters

The algorithm requires three inputs:

1. **Output Prefix**: A prefix for all output files (e.g., "Site_A_2024")
2. **Select Directory**: The directory where processed images will be saved
3. **Select PRISMA File**: The PRISMA L2D HDF5 file to process

### Process

The algorithm will:

1. Import the PRISMA L2D product (both spectral and panchromatic cubes)
2. Create various band subsets and ratios
3. Calculate mineral indices using spectral band mathematics
4. Save all processed images to the specified directory
5. Load the final products into your QGIS project

### Important Notes

- **Bad bands are NOT excluded** during import, as per your requirements
- Processing can take several minutes depending on the size of your PRISMA scene
- All output files are saved as GeoTIFF with LZW compression
- The algorithm creates 119 processing steps

## Output Files

The plugin creates the following output files (using your specified prefix):

- `{prefix}_AluniteComposition.tif`
- `{prefix}_Kaolinite-Alunite-Pyro.tif`
- `{prefix}_SWIR_MaficMinerals.tif`
- `{prefix}_FerrousSilicatesIndex.tif`
- `{prefix}_FerricIronAltnIndex.tif`
- `{prefix}_MgOHCarbIndex.tif`
- `{prefix}_PhyllicAltnIndex.tif`
- `{prefix}_PropyliticAltnIndex.tif`
- `{prefix}_FeSil-FeAlt-MgOH.tif` (RGB composite)
- Plus many intermediate products

## Troubleshooting

### "EnMAP-Box algorithms not found" error

- Make sure the EnMAP-Box plugin is installed and enabled
- Restart QGIS after installing EnMAP-Box

### Processing fails or stops

- Check that your PRISMA file is a valid L2D product
- Ensure you have write permissions to the output directory
- Check the QGIS message log for detailed error messages

### Output directory issues

- Make sure the directory exists before running
- Use forward slashes (/) in paths, even on Windows
- Avoid special characters in directory paths

## Technical Details

### Processing Steps

The algorithm performs 119 processing steps including:

1. PRISMA L2D import using EnMAP-Box
2. Band subsetting for specific wavelength ranges
3. Spectral averaging for continuum removal
4. Band ratio calculations for mineral indices
5. RGB composite generation
6. File saving with compression

### Band Configuration

- Import mode: VNIR/SWIR combined
- Bad band threshold: None (all bands retained)
- Invalid pixel filtering: L1 product invalids only

## License

[Specify your license here]

## Authors

Grant Boxer  
Email: boxerg@iinet.net.au

## Citation

If you use this plugin in your research, please cite:

[Add citation information if applicable]

## Acknowledgments

- PRISMA data: ASI (Italian Space Agency)
- EnMAP-Box: www.enmap.org
