"""
PRISMA Processor Plugin
"""

def classFactory(iface):
    from .prisma_processor import PrismaProcessorPlugin
    return PrismaProcessorPlugin(iface)
