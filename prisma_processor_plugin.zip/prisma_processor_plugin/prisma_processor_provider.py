"""
PRISMA Processor Provider
Processing provider class
"""

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
import os

from .prisma_processing_algorithm import PrismaEnviIndices


class PrismaProcessorProvider(QgsProcessingProvider):
    """Processing Provider for PRISMA Processor algorithms."""

    def __init__(self):
        QgsProcessingProvider.__init__(self)

    def loadAlgorithms(self):
        """Load all algorithms belonging to this provider."""
        self.addAlgorithm(PrismaEnviIndices())

    def id(self):
        """Return the unique provider id."""
        return 'prismaprocessor'

    def name(self):
        """Return the provider name."""
        return 'PRISMA Processor'

    def longName(self):
        """Return the provider full name."""
        return 'PRISMA Hyperspectral Data Processor'

    def icon(self):
        """Return provider icon."""
        return QgsProcessingProvider.icon(self)
