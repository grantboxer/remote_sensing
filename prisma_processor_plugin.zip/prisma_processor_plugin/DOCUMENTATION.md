# PRISMA Processor Plugin - Complete Documentation

## Table of Contents

1. [Overview](#overview)
2. [Scientific Background](#scientific-background)
3. [Algorithm Details](#algorithm-details)
4. [Input/Output Specifications](#inputoutput-specifications)
5. [Processing Workflow](#processing-workflow)
6. [Output Products](#output-products)
7. [Technical Specifications](#technical-specifications)
8. [Best Practices](#best-practices)

## Overview

The PRISMA Processor plugin is designed to automatically process PRISMA hyperspectral satellite data and generate a comprehensive suite of mineral indices useful for geological mapping, mineral exploration, and environmental monitoring.

PRISMA (PRecursore IperSpettrale della Missione Applicativa) is an Italian Space Agency (ASI) hyperspectral satellite that acquires data in 239 spectral bands from 400 to 2500 nm.

## Scientific Background

### Hyperspectral Remote Sensing

Hyperspectral imagery provides continuous spectral information across the electromagnetic spectrum, enabling the identification and mapping of minerals based on their diagnostic absorption features.

### Mineral Indices

This plugin calculates various mineral indices based on established spectral analysis techniques:

1. **Band Ratios**: Simple ratios between bands sensitive to specific mineral absorptions
2. **Spectral Averaging**: Continuum removal and normalization techniques
3. **Composite Indices**: Multi-band calculations for complex mineral assemblages

## Algorithm Details

### Processing Steps

The algorithm performs 119 sequential processing steps:

#### 1. Data Import (Steps 1)
- Imports PRISMA L2D HDF5 file
- Extracts spectral cube (VNIR/SWIR combined)
- Extracts panchromatic cube
- **Important**: Bad bands are NOT excluded during import

#### 2. Band Subsetting (Steps 2-50)
- Creates subsets for specific wavelength ranges
- Enables targeted spectral analysis
- Maintains full spectral resolution

#### 3. Spectral Averaging (Steps 51-100)
- Calculates average reflectance over diagnostic wavelength ranges
- Implements continuum removal for specific features
- Prepares data for index calculations

#### 4. Index Calculation (Steps 101-110)
- Computes mineral-specific indices using band math
- Applies standardized formulas from literature
- Generates alteration mapping products

#### 5. Composite Generation (Steps 111-115)
- Creates RGB composite layers
- Combines related indices for visualization
- Optimizes for geological interpretation

#### 6. Output and Loading (Steps 116-119)
- Saves all products as GeoTIFF
- Applies LZW compression
- Loads final products into QGIS

### Mineral Indices Calculated

#### Alunite Composition Index (1480W)
**Formula**: Band 52 / Band 53
**Interpretation**: Identifies alunite and related sulfate minerals
**Absorption Feature**: ~1480 nm (Al-OH)

#### Kaolinite-Alunite-Pyrophyllite Index (2160W)
**Formula**: Band 125 / Band 126
**Interpretation**: Maps clay minerals with ~2160 nm absorption
**Absorption Feature**: ~2160 nm (Al-OH)

#### SWIR-Active Mafic Minerals
**Formula**: Band 211 / Band 206
**Interpretation**: Detects mafic minerals with SWIR features
**Absorption Feature**: SWIR region pyroxene/amphibole features

#### Ferrous Silicates Index
**Formula**: Av_p2165 / RasterCalc_p1650
**Interpretation**: Maps Fe2+ bearing silicate minerals
**Absorption Feature**: ~2165 nm vs ~1650 nm

#### Ferric Iron Alteration Index
**Formula**: Complex multi-band calculation
**Interpretation**: Identifies Fe3+ oxidation products
**Absorption Feature**: Multiple Fe3+ features

#### MgOH Carbonate Abundance Index
**Formula**: Complex ratio using p2330 average
**Interpretation**: Maps Mg-bearing carbonates and phyllosilicates
**Absorption Feature**: ~2330 nm (Mg-OH)

#### Phyllic Alteration Index
**Formula**: Multi-band ratio
**Interpretation**: Identifies phyllic/sericitic alteration
**Minerals**: Muscovite, sericite, illite

#### Propylitic Alteration Index
**Formula**: Multi-band ratio
**Interpretation**: Maps propylitic alteration assemblages
**Minerals**: Chlorite, epidote, calcite

## Input/Output Specifications

### Input Requirements

**PRISMA File**:
- Format: HDF5 (.he5)
- Product Level: L2D (geometrically and atmospherically corrected)
- Spectral Range: VNIR/SWIR (400-2500 nm)
- Typical Size: 2-5 GB

**Output Directory**:
- Must exist before processing
- Requires write permissions
- Recommended: Dedicated folder with sufficient space (>10 GB)

**Output Prefix**:
- Used to name all output files
- Recommended format: SiteName_Date (e.g., "MineralHill_20240115")
- Avoid special characters

### Output Products

All outputs are saved as GeoTIFF with the following specifications:

**File Format**: GeoTIFF
**Compression**: LZW with predictor=2
**Data Type**: Float32
**Interleave**: Band sequential
**BigTIFF**: Yes (for large files)
**Metadata**: Preserved from source
**Styling**: Preserved where applicable

### File Naming Convention

```
{prefix}_AluniteComposition.tif
{prefix}_Kaolinite-Alunite-Pyro.tif
{prefix}_SWIR_MaficMinerals.tif
{prefix}_FerrousSilicatesIndex.tif
{prefix}_FerricIronAltnIndex.tif
{prefix}_MgOHCarbIndex.tif
{prefix}_PhyllicAltnIndex.tif
{prefix}_PropyliticAltnIndex.tif
{prefix}_FeSil-FeAlt-MgOH.tif
```

## Processing Workflow

### Recommended Workflow

1. **Prepare Data**:
   - Download PRISMA L2D product
   - Create output directory
   - Decide on naming convention

2. **Run Processing**:
   - Open QGIS Processing Toolbox
   - Find PRISMA Processor algorithm
   - Set parameters
   - Run (expect 10-30 minutes depending on scene size)

3. **Review Results**:
   - Check output directory for all files
   - Load layers into QGIS
   - Apply appropriate symbology
   - Validate against known geology

4. **Interpretation**:
   - Compare indices to identify mineral assemblages
   - Use RGB composites for overview mapping
   - Integrate with other geological data

### Quality Control

**Check for**:
- Complete file generation (all expected outputs)
- Proper georeferencing
- Reasonable value ranges
- Absence of processing artifacts
- Alignment with known geology

## Technical Specifications

### Band Numbers and Wavelengths

The plugin uses specific PRISMA bands (refer to PRISMA documentation for exact wavelengths):

- Bands 16-26: ~560 nm region (vegetation indices)
- Band 52-53: ~1480 nm region (Al-OH minerals)
- Band 125-126: ~2160 nm region (clay minerals)
- Band 206-211: SWIR mafic region
- Various other bands for specific mineral features

### Performance

**Typical Processing Times**:
- Small scene (100 km²): 5-10 minutes
- Medium scene (500 km²): 15-25 minutes
- Large scene (1000+ km²): 30-60 minutes

**Memory Requirements**:
- Minimum: 8 GB RAM
- Recommended: 16 GB RAM
- Large scenes: 32 GB RAM

**Disk Space**:
- Input: 2-5 GB (PRISMA file)
- Temporary: 5-10 GB
- Output: 3-8 GB (all products)

## Best Practices

### Data Selection

1. **Choose cloud-free scenes** when possible
2. **Check acquisition conditions** (sun angle, atmospheric conditions)
3. **Verify L2D processing quality** before investing time
4. **Consider seasonal effects** on vegetation cover

### Processing Tips

1. **Use descriptive prefixes** that include location and date
2. **Keep output directories organized** by project/area
3. **Monitor processing logs** for warnings or errors
4. **Run test on small subset** before processing large campaigns
5. **Backup original PRISMA files** before processing

### Interpretation Guidelines

1. **Compare multiple indices** for mineral identification
2. **Use known geology** for validation and calibration
3. **Be aware of false positives** from vegetation, water, atmosphere
4. **Cross-validate with field data** when available
5. **Consider topographic effects** (slopes, shadows)

### Common Issues and Solutions

**Issue**: Processing fails at import step
- **Solution**: Verify PRISMA file integrity and format

**Issue**: Some indices show unusual values
- **Solution**: Check for bad pixels, atmospheric effects, or calibration issues

**Issue**: Output files are very large
- **Solution**: Verify LZW compression is applied; consider spatial subsetting

**Issue**: Indices don't match expected geology
- **Solution**: Check band wavelength assignments; validate with field data

## References

For more information on PRISMA and hyperspectral analysis:

1. ASI PRISMA Mission: http://www.asi.it/en/earth-science/prisma
2. EnMAP-Box Documentation: https://enmap-box.readthedocs.io/
3. Spectral geology references: [Add relevant papers]

## Version History

See [CHANGELOG.md](CHANGELOG.md) for version history and updates.

## Support

For questions, issues, or contributions:
- Email: boxerg@iinet.net.au
- Author: Grant Boxer
