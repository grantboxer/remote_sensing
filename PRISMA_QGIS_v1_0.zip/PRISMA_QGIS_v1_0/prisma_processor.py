"""
PRISMA Processor Plugin
Main plugin class
"""

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsApplication
import os
import processing

from .prisma_processor_provider import PrismaProcessorProvider


class PrismaProcessorPlugin:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.provider = None
        self.action = None

    def initProcessing(self):
        """Init Processing provider for QGIS >= 3.8."""
        self.provider = PrismaProcessorProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        self.initProcessing()
        
        # Create action for the Raster menu
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        if not os.path.exists(icon_path):
            icon_path = None
        
        self.action = QAction(
            QIcon(icon_path) if icon_path else QIcon(),
            "PRISMA Processor",
            self.iface.mainWindow()
        )
        self.action.setObjectName("prismaProcessorAction")
        self.action.setWhatsThis("Process PRISMA hyperspectral data")
        self.action.setStatusTip("Import and process PRISMA L2D hyperspectral data")
        self.action.triggered.connect(self.run)
        
        # Add to Raster menu
        self.iface.addPluginToRasterMenu("PRISMA Processor", self.action)

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
        
        # Remove from Raster menu
        if self.action is not None:
            self.iface.removePluginRasterMenu("PRISMA Processor", self.action)
    
    def run(self):
        """Run the PRISMA processing algorithm."""
        processing.execAlgorithmDialog("prismaprocessor:PRISMA_ENVI_Indices", {})
