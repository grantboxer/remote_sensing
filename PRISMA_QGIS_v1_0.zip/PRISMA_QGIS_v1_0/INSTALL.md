# PRISMA Processor Plugin - Installation Guide

## Prerequisites

Before installing the PRISMA Processor plugin, ensure you have:

1. **QGIS 3.0 or higher** installed on your system
2. **EnMAP-Box plugin** installed in QGIS (this is REQUIRED)

## Step-by-Step Installation

### Step 1: Install EnMAP-Box (Required Dependency)

The PRISMA Processor plugin depends on the EnMAP-Box plugin for PRISMA data import functionality.

1. Open QGIS
2. Go to **Plugins > Manage and Install Plugins**
3. Click on the **All** tab
4. In the search box, type "EnMAP-Box"
5. Select the **EnMAP-Box** plugin from the list
6. Click **Install Plugin**
7. Wait for installation to complete
8. Close the plugin manager

### Step 2: Install PRISMA Processor Plugin

#### Option A: From Plugin Directory (Recommended)

1. **Locate your QGIS plugins directory:**
   
   - **Windows**: 
     ```
     C:\Users\[YourUsername]\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\
     ```
   
   - **macOS**: 
     ```
     ~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/
     ```
   
   - **Linux**: 
     ```
     ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/
     ```

2. **Copy the plugin folder:**
   - Copy the entire `prisma_processor_plugin` folder to the plugins directory
   - The final path should look like:
     ```
     .../plugins/prisma_processor_plugin/
     ```

3. **Restart QGIS**

4. **Enable the plugin:**
   - Go to **Plugins > Manage and Install Plugins**
   - Click on the **Installed** tab
   - Find "PRISMA Processor" in the list
   - Check the box next to it to enable it

#### Option B: From ZIP File

1. **Create a ZIP file** (if you have the plugin as separate files):
   - Create a folder named `prisma_processor_plugin`
   - Place all plugin files inside
   - Compress the folder to `prisma_processor_plugin.zip`

2. **Install from ZIP:**
   - In QGIS, go to **Plugins > Manage and Install Plugins**
   - Click on **Install from ZIP**
   - Click **Browse** and select your ZIP file
   - Click **Install Plugin**
   - Close the plugin manager

### Step 3: Verify Installation

1. Open the **Processing Toolbox** (Processing > Toolbox)
2. Look for **PRISMA Processor** in the list of providers
3. Expand it to see **PRISMA Hyperspectral Data Processor**
4. You should see the **PRISMA_ENVI_Indices** algorithm

If you see these items, the plugin is successfully installed!

## Troubleshooting

### Issue: Plugin doesn't appear in the list

**Solution:**
- Check that all plugin files are in the correct directory
- Ensure the folder name is exactly `prisma_processor_plugin`
- Restart QGIS completely
- Check the QGIS log (View > Panels > Log Messages) for error messages

### Issue: "EnMAP-Box algorithms not found"

**Solution:**
- Install the EnMAP-Box plugin first (see Step 1)
- Ensure EnMAP-Box is enabled in Plugins > Manage and Install Plugins
- Restart QGIS after installing EnMAP-Box

### Issue: Permission errors

**Solution:**
- On Windows, run QGIS as Administrator
- On Linux/macOS, ensure you have write permissions to the plugins directory
- Try copying the plugin folder manually instead of using the ZIP installer

### Issue: Plugin loads but algorithm doesn't work

**Solution:**
- Check that you're using QGIS 3.0 or higher
- Verify EnMAP-Box is properly installed and enabled
- Check the Processing log for detailed error messages
- Ensure your PRISMA file is a valid L2D HDF5 file

## Uninstallation

To remove the plugin:

1. Go to **Plugins > Manage and Install Plugins**
2. Find **PRISMA Processor** in the **Installed** tab
3. Click **Uninstall Plugin**

Alternatively, manually delete the `prisma_processor_plugin` folder from your QGIS plugins directory.

## Getting Help

If you encounter issues not covered here:

1. Check the QGIS message log: **View > Panels > Log Messages**
2. Look for error messages in the **Processing** tab
3. Consult the README.md file for usage instructions
4. Report issues at [your issue tracker URL]

## Next Steps

After successful installation, see the [README.md](README.md) file for usage instructions and examples.
