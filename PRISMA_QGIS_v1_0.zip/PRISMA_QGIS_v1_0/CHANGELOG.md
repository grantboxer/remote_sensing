# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2024

### Added
- Initial release of PRISMA Processor plugin
- PRISMA L2D hyperspectral data import
- Mineral indices calculation:
  - Alunite Composition
  - Kaolinite-Alunite-Pyrophyllite
  - SWIR-active Mafic Minerals
  - Ferrous Silicates Index
  - Ferric Iron Alteration Index
  - MgOH Carbonate Abundance Index
  - Phyllic Alteration Index
  - Propylitic Alteration Index
- RGB composite generation
- Automatic layer loading into QGIS project
- Compressed GeoTIFF output format

### Configuration
- Bad band exclusion disabled (all bands retained during import)
- LZW compression for all output files
- Automatic metadata and styling preservation
