"""
Model exported as python.
Name : PRISMA_ENVI_Indices
Group : RemoteSensing
With QGIS : 34407
"""

import os
from typing import Any, Optional

from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingContext
from qgis.core import QgsProcessingFeedback, QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterString
from qgis.core import QgsProcessingParameterFile
from qgis.core import QgsExpression
from qgis import processing


class PrismaEnviIndices(QgsProcessingAlgorithm):

    def initAlgorithm(self, config: Optional[dict[str, Any]] = None):
        # Add file prefix for saved layers
        self.addParameter(QgsProcessingParameterString('output_prefix', 'Output_prefix', multiLine=False, defaultValue=None))
        self.addParameter(QgsProcessingParameterString('select_directory', 'Select Directory', multiLine=False, defaultValue='C:\\temp\\processing'))
        self.addParameter(QgsProcessingParameterFile('select_prisma_file', 'Select PRISMA file', behavior=QgsProcessingParameterFile.File, fileFilter='All Files (*.*)', defaultValue=None))

    def processAlgorithm(self, parameters: dict[str, Any], context: QgsProcessingContext, model_feedback: QgsProcessingFeedback) -> dict[str, Any]:
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(119, model_feedback)
        results = {}
        outputs = {}

        # Import PRISMA L2D product
        alg_params = {
            'badBandThreshold': None,
            'badPixelType': [0],  # Invalid pixel from L1 product
            'file': parameters['select_prisma_file'],
            'outputPrismaL2D_panCube': None,
            'spectralRegion': 0,  # VNIR/SWIR combined
            'outputPrismaL2D_panCube': QgsProcessing.TEMPORARY_OUTPUT,
            'outputPrismaL2D_spectralCube': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ImportPrismaL2dProduct'] = processing.run('enmapbox:importprismal2dproduct', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Subset B016
        alg_params = {
            'bandList': [12],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB016'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Subset p560
        alg_params = {
            'bandList': [16,17,18,19,20,21,22,23,24,25,26],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP560'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # SWIR-active mafic minerals
        alg_params = {
            'BAND_A': 211,
            'BAND_B': 206,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SwiractiveMaficMinerals'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Avp560-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP560']['outputRaster'],
            'INPUT_B': outputs['SubsetP560']['outputRaster'],
            'INPUT_C': outputs['SubsetP560']['outputRaster'],
            'INPUT_D': outputs['SubsetP560']['outputRaster'],
            'INPUT_E': outputs['SubsetP560']['outputRaster'],
            'INPUT_F': outputs['SubsetP560']['outputRaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Avp5601'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Alunite composition 1480W
        alg_params = {
            'BAND_A': 52,
            'BAND_B': 53,
            'BAND_C': 83,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AluniteComposition1480w'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # Kaolinite-Alunite-Pyrophyllite 2160W
        alg_params = {
            'BAND_A': 125,
            'BAND_B': 126,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Kaolinitealunitepyrophyllite2160w'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # Save Alunite Composition layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_AluniteCom_1480W.tif'),
            'raster': outputs['AluniteComposition1480w']['OUTPUT'],
        }
        outputs['SaveAluniteCompositionLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # Subset p2330
        alg_params = {
            'bandList': [206,207,208,209,210,211,212,213,214,215],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP2330'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # Subset p2165
        alg_params = {
            'bandList': [186,187,188,189,190,191],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP2165'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # 900W
        alg_params = {
            'BAND_A': 52,
            'BAND_B': 57,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['W'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            return {}

        # Chlorite-epidote abundance 2250D
        alg_params = {
            'BAND_A': 134,
            'BAND_B': 139,
            'BAND_C': 137,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ChloriteepidoteAbundance2250d'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            return {}

        # Kaolin Gp abundance 2160D
        alg_params = {
            'BAND_A': 123,
            'BAND_B': 131,
            'BAND_C': 126,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KaolinGpAbundance2160d'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(13)
        if feedback.isCanceled():
            return {}

        # 2320D Dolomitisation 1
        alg_params = {
            'BAND_A': 206,
            'BAND_B': 212,
            'BAND_C': 209,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['DDolomitisation1'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(14)
        if feedback.isCanceled():
            return {}

        # Al-Sheet Silicate Abundance 2200D
        alg_params = {
            'BAND_A': 126,
            'BAND_B': 135,
            'BAND_C': 131,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AlsheetSilicateAbundance2200d'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}

        # Subset B193
        alg_params = {
            'bandList': [193],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB193'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(16)
        if feedback.isCanceled():
            return {}

        # Avp560-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': 9,
            'BAND_D': 10,
            'BAND_E': 11,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E)/5',
            'INPUT_A': outputs['SubsetP560']['outputRaster'],
            'INPUT_B': outputs['SubsetP560']['outputRaster'],
            'INPUT_C': outputs['SubsetP560']['outputRaster'],
            'INPUT_D': outputs['SubsetP560']['outputRaster'],
            'INPUT_E': outputs['SubsetP560']['outputRaster'],
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Avp5602'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(17)
        if feedback.isCanceled():
            return {}

        # Subset p2205
        alg_params = {
            'bandList': [191,192,193,194,195,196],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP2205'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(18)
        if feedback.isCanceled():
            return {}

        # Muscovite Index
        alg_params = {
            'BAND_A': 205,
            'BAND_B': 194,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['MuscoviteIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(19)
        if feedback.isCanceled():
            return {}

        # Subset p820
        alg_params = {
            'bandList': [45,46,47,48,49,50,51,52],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP820'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(20)
        if feedback.isCanceled():
            return {}

        # Save Chl-Ep Abundance layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_Chl-EpiditeAbund_2250D.tif'),
            'raster': outputs['ChloriteepidoteAbundance2250d']['OUTPUT'],
        }
        outputs['SaveChlepAbundanceLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(21)
        if feedback.isCanceled():
            return {}

        # Av_p2330-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP2330']['outputRaster'],
            'INPUT_B': outputs['SubsetP2330']['outputRaster'],
            'INPUT_C': outputs['SubsetP2330']['outputRaster'],
            'INPUT_D': outputs['SubsetP2330']['outputRaster'],
            'INPUT_E': outputs['SubsetP2330']['outputRaster'],
            'INPUT_F': outputs['SubsetP2330']['outputRaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p23301'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(22)
        if feedback.isCanceled():
            return {}

        # Av_p2330-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': 9,
            'BAND_D': 10,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B+C+D)/4',
            'INPUT_A': outputs['SubsetP2330']['outputRaster'],
            'INPUT_B': outputs['SubsetP2330']['outputRaster'],
            'INPUT_C': outputs['SubsetP2330']['outputRaster'],
            'INPUT_D': outputs['SubsetP2330']['outputRaster'],
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p23302'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(23)
        if feedback.isCanceled():
            return {}

        # Subset p2260
        alg_params = {
            'bandList': [210,211,212,213,214,215,216],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP2260'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(24)
        if feedback.isCanceled():
            return {}

        # Av_p820-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP820']['outputRaster'],
            'INPUT_B': outputs['SubsetP820']['outputRaster'],
            'INPUT_C': outputs['SubsetP820']['outputRaster'],
            'INPUT_D': outputs['SubsetP820']['outputRaster'],
            'INPUT_E': outputs['SubsetP820']['outputRaster'],
            'INPUT_F': outputs['SubsetP820']['outputRaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p8201'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(25)
        if feedback.isCanceled():
            return {}

        # 1480D alunite-jarosite abundance
        alg_params = {
            'BAND_A': 51,
            'BAND_B': 56,
            'BAND_C': 52,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['DAlunitejarositeAbundance'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(26)
        if feedback.isCanceled():
            return {}

        # Load Alunite Composition into project
        alg_params = {
            'INPUT': outputs['SaveAluniteCompositionLayerAs']['outputRaster'],
            'NAME': QgsExpression("'AluniteComp_1480W'").evaluate()
        }
        outputs['LoadAluniteCompositionIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(27)
        if feedback.isCanceled():
            return {}

        # Subset B033
        alg_params = {
            'bandList': [33],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB033'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(28)
        if feedback.isCanceled():
            return {}

        # Save 900W layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_900W.tif'),
            'raster': outputs['W']['OUTPUT'],
        }
        outputs['Save900wLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(29)
        if feedback.isCanceled():
            return {}

        # 2200W Al-sheet silicate composition
        alg_params = {
            'BAND_A': 129,
            'BAND_B': 133,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['WAlsheetSilicateComposition'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(30)
        if feedback.isCanceled():
            return {}

        # Subset B052
        alg_params = {
            'bandList': [52],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB052'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(31)
        if feedback.isCanceled():
            return {}

        # Subset B052
        alg_params = {
            'bandList': [52],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB052_2'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(32)
        if feedback.isCanceled():
            return {}

        # Kaolin Crystallinity
        alg_params = {
            'BAND_A': 188,
            'BAND_B': 194,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KaolinCrystallinity'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(33)
        if feedback.isCanceled():
            return {}

        # Av_p2330
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Av_p23301']['OUTPUT'],
            'INPUT_B': outputs['Av_p23302']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p2330'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(34)
        if feedback.isCanceled():
            return {}

        # Save Kaol-Alunite-Pyrophy layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_Kaol-Alunite-Pyroph_2160W.tif'),
            'raster': outputs['Kaolinitealunitepyrophyllite2160w']['OUTPUT'],
        }
        outputs['SaveKaolalunitepyrophyLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(35)
        if feedback.isCanceled():
            return {}

        # Save pan layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_pan.tif'),
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_panCube'],
        }
        outputs['SavePanLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(36)
        if feedback.isCanceled():
            return {}

        # Subset B128
        alg_params = {
            'bandList': [128],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetB128'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(37)
        if feedback.isCanceled():
            return {}

        # Subset p2395
        alg_params = {
            'bandList': [215,216,217,218,219,220,221,222,223,224],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP2395'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(38)
        if feedback.isCanceled():
            return {}

        # Save Kaolin XL layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_KaoliniteXL.tif'),
            'raster': outputs['KaolinCrystallinity']['OUTPUT'],
        }
        outputs['SaveKaolinXlLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(39)
        if feedback.isCanceled():
            return {}

        # Subset tm3
        alg_params = {
            'bandList': [30,31,32,33,34,35],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetTm3'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(40)
        if feedback.isCanceled():
            return {}

        # Av_p820-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['SubsetP820']['outputRaster'],
            'INPUT_B': outputs['SubsetP820']['outputRaster'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p8202'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(41)
        if feedback.isCanceled():
            return {}

        # Save Kaolinite Gp Abundance layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_KaoliniteGpAbund_2160D.tif'),
            'raster': outputs['KaolinGpAbundance2160d']['OUTPUT'],
        }
        outputs['SaveKaoliniteGpAbundanceLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(42)
        if feedback.isCanceled():
            return {}

        # Subset p1650
        alg_params = {
            'bandList': [127,128,129,130,131,132,133,134,135,136],
            'excludeBadBands': False,
            'excludeDerivedBadBands': False,
            'raster': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'outputRaster': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['SubsetP1650'] = processing.run('enmapbox:subsetrasterlayerbands', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(43)
        if feedback.isCanceled():
            return {}

        # Av_p820
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Av_p8201']['OUTPUT'],
            'INPUT_B': outputs['Av_p8202']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p820'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(44)
        if feedback.isCanceled():
            return {}

        # RGB Geology
        alg_params = {
            'ADD_ALPHA': False,
            'ASSIGN_CRS': None,
            'EXTRA': None,
            'INPUT': [outputs['SubsetB193']['outputRaster'],outputs['SubsetB128']['outputRaster'],outputs['SubsetB016']['outputRaster']],
            'PROJ_DIFFERENCE': False,
            'RESAMPLING': 0,  # Nearest Neighbour
            'RESOLUTION': 1,  # Highest
            'SEPARATE': True,
            'SRC_NODATA': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RgbGeology'] = processing.run('gdal:buildvirtualraster', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(45)
        if feedback.isCanceled():
            return {}

        # Raster calculator p 2300
        alg_params = {
            'BAND_A': 206,
            'BAND_B': 207,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RasterCalculatorP2300'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(46)
        if feedback.isCanceled():
            return {}

        # Save B016 layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_B016.tif'),
            'raster': outputs['SubsetB016']['outputRaster'],
        }
        outputs['SaveB016LayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(47)
        if feedback.isCanceled():
            return {}

        # 900D
        alg_params = {
            'BAND_A': 44,
            'BAND_B': 17,
            'BAND_C': 57,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['D'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(48)
        if feedback.isCanceled():
            return {}

        # Av_p1650-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP1650']['outputRaster'],
            'INPUT_B': outputs['SubsetP1650']['outputRaster'],
            'INPUT_C': outputs['SubsetP1650']['outputRaster'],
            'INPUT_D': outputs['SubsetP1650']['outputRaster'],
            'INPUT_E': outputs['SubsetP1650']['outputRaster'],
            'INPUT_F': outputs['SubsetP1650']['outputRaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p16501'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(49)
        if feedback.isCanceled():
            return {}

        # Alunite abundance 1760D
        alg_params = {
            'BAND_A': 76,
            'BAND_B': 82,
            'BAND_C': 80,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_B': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_C': outputs['ImportPrismaL2dProduct']['outputPrismaL2D_spectralCube'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AluniteAbundance1760d'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(50)
        if feedback.isCanceled():
            return {}

        # Load Kaol-Alunite-Pyroph  into project
        alg_params = {
            'INPUT': outputs['SaveKaolalunitepyrophyLayerAs']['outputRaster'],
            'NAME': QgsExpression("'Kaolinite-alunite-pyrophyllite_2160W'").evaluate()
        }
        outputs['LoadKaolalunitepyrophIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(51)
        if feedback.isCanceled():
            return {}

        # Save SWIR-active mafic layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_SWIR_mafic.tif'),
            'raster': outputs['SwiractiveMaficMinerals']['OUTPUT'],
        }
        outputs['SaveSwiractiveMaficLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(52)
        if feedback.isCanceled():
            return {}

        # Load Chl-Ep Abundance into project
        alg_params = {
            'INPUT': outputs['SaveChlepAbundanceLayerAs']['outputRaster'],
            'NAME': QgsExpression("'2250D_Chl-Ep_Abund'").evaluate()
        }
        outputs['LoadChlepAbundanceIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(53)
        if feedback.isCanceled():
            return {}

        # Save Dolimitisation 1 layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_Dolomitisation_2320D.tif'),
            'raster': outputs['DDolomitisation1']['OUTPUT'],
        }
        outputs['SaveDolimitisation1LayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(54)
        if feedback.isCanceled():
            return {}

        # Save Muscovite layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_MuscoviteIndex.tif'),
            'raster': outputs['MuscoviteIndex']['OUTPUT'],
        }
        outputs['SaveMuscoviteLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(55)
        if feedback.isCanceled():
            return {}

        # Load Kaolin XL into project
        alg_params = {
            'INPUT': outputs['SaveKaolinXlLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_KaolinXL'").evaluate()
        }
        outputs['LoadKaolinXlIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(56)
        if feedback.isCanceled():
            return {}

        # Save Alunite Abundance layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_AluniteAbund_1760D.tif'),
            'raster': outputs['AluniteAbundance1760d']['OUTPUT'],
        }
        outputs['SaveAluniteAbundanceLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(57)
        if feedback.isCanceled():
            return {}

        # Load Dolomitsation 1 into project
        alg_params = {
            'INPUT': outputs['SaveDolimitisation1LayerAs']['outputRaster'],
            'NAME': QgsExpression("'Dolomitisation_1_2320D'").evaluate()
        }
        outputs['LoadDolomitsation1IntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(58)
        if feedback.isCanceled():
            return {}

        # RGB Agriculture 2
        alg_params = {
            'ADD_ALPHA': False,
            'ASSIGN_CRS': None,
            'EXTRA': None,
            'INPUT': [outputs['SubsetB128']['outputRaster'],outputs['SubsetB052']['outputRaster'],outputs['SubsetB016']['outputRaster']],
            'PROJ_DIFFERENCE': False,
            'RESAMPLING': 0,  # Nearest Neighbour
            'RESOLUTION': 1,  # Highest
            'SEPARATE': True,
            'SRC_NODATA': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RgbAgriculture2'] = processing.run('gdal:buildvirtualraster', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(59)
        if feedback.isCanceled():
            return {}

        # Av_p560
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Avp5601']['OUTPUT'],
            'INPUT_B': outputs['Avp5602']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p560'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(60)
        if feedback.isCanceled():
            return {}

        # Load 900W into project
        alg_params = {
            'INPUT': outputs['Save900wLayerAs']['outputRaster'],
            'NAME': QgsExpression("'900W'").evaluate()
        }
        outputs['Load900wIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(61)
        if feedback.isCanceled():
            return {}

        # Av_p2165
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E)/5',
            'INPUT_A': outputs['SubsetP2165']['outputRaster'],
            'INPUT_B': outputs['SubsetP2165']['outputRaster'],
            'INPUT_C': outputs['SubsetP2165']['outputRaster'],
            'INPUT_D': outputs['SubsetP2165']['outputRaster'],
            'INPUT_E': outputs['SubsetP2165']['outputRaster'],
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p2165'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(62)
        if feedback.isCanceled():
            return {}

        # Load pan
        alg_params = {
            'INPUT': outputs['SavePanLayerAs']['outputRaster'],
            'NAME': QgsExpression("'pan'").evaluate()
        }
        outputs['LoadPan'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(63)
        if feedback.isCanceled():
            return {}

        # Save Ag2 layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_Ag2.tif'),
            'raster': outputs['RgbAgriculture2']['OUTPUT'],
        }
        outputs['SaveAg2LayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(64)
        if feedback.isCanceled():
            return {}

        # RGB Natural Colour
        alg_params = {
            'ADD_ALPHA': False,
            'ASSIGN_CRS': None,
            'EXTRA': None,
            'INPUT': [outputs['SubsetB052_2']['outputRaster'],outputs['SubsetB033']['outputRaster'],outputs['SubsetB016']['outputRaster']],
            'PROJ_DIFFERENCE': False,
            'RESAMPLING': 0,  # Nearest Neighbour
            'RESOLUTION': 1,  # Highest
            'SEPARATE': True,
            'SRC_NODATA': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RgbNaturalColour'] = processing.run('gdal:buildvirtualraster', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(65)
        if feedback.isCanceled():
            return {}

        # Save ASA layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_ASA2200D.tif'),
            'raster': outputs['AlsheetSilicateAbundance2200d']['OUTPUT'],
        }
        outputs['SaveAsaLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(66)
        if feedback.isCanceled():
            return {}

        # Av_tm3
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetTm3']['outputRaster'],
            'INPUT_B': outputs['SubsetTm3']['outputRaster'],
            'INPUT_C': outputs['SubsetTm3']['outputRaster'],
            'INPUT_D': outputs['SubsetTm3']['outputRaster'],
            'INPUT_E': outputs['SubsetTm3']['outputRaster'],
            'INPUT_F': outputs['SubsetTm3']['outputRaster'],
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_tm3'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(67)
        if feedback.isCanceled():
            return {}

        # Load SWIR mafic into project
        alg_params = {
            'INPUT': outputs['SaveSwiractiveMaficLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_SWIR-active_mafic_mins'").evaluate()
        }
        outputs['LoadSwirMaficIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(68)
        if feedback.isCanceled():
            return {}

        # Av_p2395-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': 9,
            'BAND_D': 10,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D)/4',
            'INPUT_A': outputs['SubsetP2395']['outputRaster'],
            'INPUT_B': outputs['SubsetP2395']['outputRaster'],
            'INPUT_C': outputs['SubsetP2395']['outputRaster'],
            'INPUT_D': outputs['SubsetP2395']['outputRaster'],
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p23952'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(69)
        if feedback.isCanceled():
            return {}

        # Load Alunite Abundance into project
        alg_params = {
            'INPUT': outputs['SaveAluniteAbundanceLayerAs']['outputRaster'],
            'NAME': QgsExpression("'AluniteAbundance_1480D'").evaluate()
        }
        outputs['LoadAluniteAbundanceIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(70)
        if feedback.isCanceled():
            return {}

        # Av_p2205
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E)/5',
            'INPUT_A': outputs['SubsetP2205']['outputRaster'],
            'INPUT_B': outputs['SubsetP2205']['outputRaster'],
            'INPUT_C': outputs['SubsetP2205']['outputRaster'],
            'INPUT_D': outputs['SubsetP2205']['outputRaster'],
            'INPUT_E': outputs['SubsetP2205']['outputRaster'],
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p2205'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(71)
        if feedback.isCanceled():
            return {}

        # Save 900D layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_900D.tif'),
            'raster': outputs['D']['OUTPUT'],
        }
        outputs['Save900dLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(72)
        if feedback.isCanceled():
            return {}

        # Save B128 layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_B128.tif'),
            'raster': outputs['SubsetB128']['outputRaster'],
        }
        outputs['SaveB128LayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(73)
        if feedback.isCanceled():
            return {}

        # Av_p2260-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E)/5',
            'INPUT_A': outputs['SubsetP2260']['outputRaster'],
            'INPUT_B': outputs['SubsetP2260']['outputRaster'],
            'INPUT_C': outputs['SubsetP2260']['outputRaster'],
            'INPUT_D': outputs['SubsetP2260']['outputRaster'],
            'INPUT_E': outputs['SubsetP2260']['outputRaster'],
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p22601'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(74)
        if feedback.isCanceled():
            return {}

        # Save B052 layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_B052.tif'),
            'raster': outputs['SubsetB052']['outputRaster'],
        }
        outputs['SaveB052LayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(75)
        if feedback.isCanceled():
            return {}

        # Save Alunite Jarosite layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_AluniteJarosite_1480D.tif'),
            'raster': outputs['DAlunitejarositeAbundance']['OUTPUT'],
        }
        outputs['SaveAluniteJarositeLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(76)
        if feedback.isCanceled():
            return {}

        # Ferrous Iron (Fe2+) Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': 1,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/(C+D)',
            'INPUT_A': outputs['Av_p2165']['OUTPUT'],
            'INPUT_B': outputs['Av_p820']['OUTPUT'],
            'INPUT_C': outputs['Av_p560']['OUTPUT'],
            'INPUT_D': outputs['Av_tm3']['OUTPUT'],
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FerrousIronFe2Index'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(77)
        if feedback.isCanceled():
            return {}

        # Alunite Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A*B)/(A*C)',
            'INPUT_A': outputs['Av_p22601']['OUTPUT'],
            'INPUT_B': outputs['Av_p2165']['OUTPUT'],
            'INPUT_C': outputs['Av_p2330']['OUTPUT'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AluniteIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(78)
        if feedback.isCanceled():
            return {}

        # Phyllic Altn Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['Av_p2165']['OUTPUT'],
            'INPUT_B': outputs['Av_p22601']['OUTPUT'],
            'INPUT_C': outputs['Av_p2205']['OUTPUT'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PhyllicAltnIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(79)
        if feedback.isCanceled():
            return {}

        # Load 900D into project
        alg_params = {
            'INPUT': outputs['Save900dLayerAs']['outputRaster'],
            'NAME': QgsExpression("'900D'").evaluate()
        }
        outputs['Load900dIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(80)
        if feedback.isCanceled():
            return {}

        # Load Kaol Gp Abund into project
        alg_params = {
            'INPUT': outputs['SaveKaoliniteGpAbundanceLayerAs']['outputRaster'],
            'NAME': QgsExpression("'KaolinGp_Abund_2160D'").evaluate()
        }
        outputs['LoadKaolGpAbundIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(81)
        if feedback.isCanceled():
            return {}

        # Save ASA composition layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_ASA_composition_2200W.tif'),
            'raster': outputs['WAlsheetSilicateComposition']['OUTPUT'],
        }
        outputs['SaveAsaCompositionLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(82)
        if feedback.isCanceled():
            return {}

        # Av_p2395-1
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 2,
            'BAND_C': 3,
            'BAND_D': 4,
            'BAND_E': 5,
            'BAND_F': 6,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B+C+D+E+F)/6',
            'INPUT_A': outputs['SubsetP2395']['outputRaster'],
            'INPUT_B': outputs['SubsetP2395']['outputRaster'],
            'INPUT_C': outputs['SubsetP2395']['outputRaster'],
            'INPUT_D': outputs['SubsetP2395']['outputRaster'],
            'INPUT_E': outputs['SubsetP2395']['outputRaster'],
            'INPUT_F': outputs['SubsetP2395']['outputRaster'],
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p23951'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(83)
        if feedback.isCanceled():
            return {}

        # Av_p1650-2
        alg_params = {
            'BAND_A': 7,
            'BAND_B': 8,
            'BAND_C': 9,
            'BAND_D': 10,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B+C+D)/4',
            'INPUT_A': outputs['SubsetP1650']['outputRaster'],
            'INPUT_B': outputs['SubsetP1650']['outputRaster'],
            'INPUT_C': outputs['SubsetP1650']['outputRaster'],
            'INPUT_D': outputs['SubsetP1650']['outputRaster'],
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p16502'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(84)
        if feedback.isCanceled():
            return {}

        # Save Geology layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_Geology.tif'),
            'raster': outputs['RgbGeology']['OUTPUT'],
        }
        outputs['SaveGeologyLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(85)
        if feedback.isCanceled():
            return {}

        # Load Ag2 into project
        alg_params = {
            'INPUT': outputs['SaveAg2LayerAs']['outputRaster'],
            'NAME': QgsExpression("'RGB_Ag2'").evaluate()
        }
        outputs['LoadAg2IntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(86)
        if feedback.isCanceled():
            return {}

        # Save NatCol layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_NatCol.tif'),
            'raster': outputs['RgbNaturalColour']['OUTPUT'],
        }
        outputs['SaveNatcolLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(87)
        if feedback.isCanceled():
            return {}

        # Phengitic Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['Av_p2165']['OUTPUT'],
            'INPUT_B': outputs['Av_p2205']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PhengiticIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(88)
        if feedback.isCanceled():
            return {}

        # Ferric Iron Altn Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': 1,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A/B)+(C/D)',
            'INPUT_A': outputs['Av_p2165']['OUTPUT'],
            'INPUT_B': outputs['Av_p820']['OUTPUT'],
            'INPUT_C': outputs['Av_p560']['OUTPUT'],
            'INPUT_D': outputs['Av_tm3']['OUTPUT'],
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FerricIronAltnIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(89)
        if feedback.isCanceled():
            return {}

        # Save Ferric Iron Altn layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_FerricIronAltnIndex.tif'),
            'raster': outputs['FerricIronAltnIndex']['OUTPUT'],
        }
        outputs['SaveFerricIronAltnLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(90)
        if feedback.isCanceled():
            return {}

        # Load Muscovite into project
        alg_params = {
            'INPUT': outputs['SaveMuscoviteLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Muscovite Index'").evaluate()
        }
        outputs['LoadMuscoviteIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(91)
        if feedback.isCanceled():
            return {}

        # Load ASA Comosition into project
        alg_params = {
            'INPUT': outputs['SaveAsaCompositionLayerAs']['outputRaster'],
            'NAME': QgsExpression("'2200W_ASA_comp'").evaluate()
        }
        outputs['LoadAsaComositionIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(92)
        if feedback.isCanceled():
            return {}

        # Load Alunite Jarosite into project
        alg_params = {
            'INPUT': outputs['SaveAluniteJarositeLayerAs']['outputRaster'],
            'NAME': QgsExpression("'Alunite-Jarosite_Abund_1480D'").evaluate()
        }
        outputs['LoadAluniteJarositeIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(93)
        if feedback.isCanceled():
            return {}

        # Load ASA into project
        alg_params = {
            'INPUT': outputs['SaveAsaLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ASA_2200D'").evaluate()
        }
        outputs['LoadAsaIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(94)
        if feedback.isCanceled():
            return {}

        # Load NC into project
        alg_params = {
            'INPUT': outputs['SaveNatcolLayerAs']['outputRaster'],
            'NAME': QgsExpression("'RGB_Nat_Col'").evaluate()
        }
        outputs['LoadNcIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(95)
        if feedback.isCanceled():
            return {}

        # Save Phengitic layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_PhengiticIndex.tif'),
            'raster': outputs['PhengiticIndex']['OUTPUT'],
        }
        outputs['SavePhengiticLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(96)
        if feedback.isCanceled():
            return {}

        # Save Ferrous Iron layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_FerrousIronIndex.tif'),
            'raster': outputs['FerrousIronFe2Index']['OUTPUT'],
        }
        outputs['SaveFerrousIronLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(97)
        if feedback.isCanceled():
            return {}

        # Load layer into project
        alg_params = {
            'INPUT': outputs['SaveFerricIronAltnLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Ferric Iron Altn Index'").evaluate()
        }
        outputs['LoadLayerIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(98)
        if feedback.isCanceled():
            return {}

        # Save Alunite layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_AluniteIndex.tif'),
            'raster': outputs['AluniteIndex']['OUTPUT'],
        }
        outputs['SaveAluniteLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(99)
        if feedback.isCanceled():
            return {}

        # Load Phengitic into project
        alg_params = {
            'INPUT': outputs['SavePhengiticLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Phengitic Index'").evaluate()
        }
        outputs['LoadPhengiticIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(100)
        if feedback.isCanceled():
            return {}

        # Save Phyllitic layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_PhylliticAltnIndex.tif'),
            'raster': outputs['PhyllicAltnIndex']['OUTPUT'],
        }
        outputs['SavePhylliticLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(101)
        if feedback.isCanceled():
            return {}

        # Load Ferrous Iron into project
        alg_params = {
            'INPUT': outputs['SaveFerrousIronLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Ferrous Iron Index'").evaluate()
        }
        outputs['LoadFerrousIronIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(102)
        if feedback.isCanceled():
            return {}

        # Av_p2395
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Av_p23951']['OUTPUT'],
            'INPUT_B': outputs['Av_p23952']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Av_p2395'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(103)
        if feedback.isCanceled():
            return {}

        # Raster calculator p1650
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 0,  # Ignore
            'EXTRA': None,
            'FORMULA': '(A+B)/2',
            'INPUT_A': outputs['Av_p16501']['OUTPUT'],
            'INPUT_B': outputs['Av_p16502']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': -32768,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RasterCalculatorP1650'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(104)
        if feedback.isCanceled():
            return {}

        # Load Geology into project
        alg_params = {
            'INPUT': outputs['SaveGeologyLayerAs']['outputRaster'],
            'NAME': QgsExpression("'RGB_Geology'").evaluate()
        }
        outputs['LoadGeologyIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(105)
        if feedback.isCanceled():
            return {}

        # Propylitic Altn Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'CREATION_OPTIONS': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['Av_p22601']['OUTPUT'],
            'INPUT_B': outputs['Av_p2395']['OUTPUT'],
            'INPUT_C': outputs['Av_p2330']['OUTPUT'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PropyliticAltnIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(106)
        if feedback.isCanceled():
            return {}

        # Load Alunite into project
        alg_params = {
            'INPUT': outputs['SaveAluniteLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Alunite_Index'").evaluate()
        }
        outputs['LoadAluniteIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(107)
        if feedback.isCanceled():
            return {}

        # MgOH Carbonate Abund Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': 1,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': '(A+B)/C',
            'INPUT_A': outputs['Av_p2395']['OUTPUT'],
            'INPUT_B': outputs['Av_p2205']['OUTPUT'],
            'INPUT_C': outputs['Av_p2330']['OUTPUT'],
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['MgohCarbonateAbundIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(108)
        if feedback.isCanceled():
            return {}

        # Load Phyllitic into project
        alg_params = {
            'INPUT': outputs['SavePhylliticLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Phyllic_Altn Index'").evaluate()
        }
        outputs['LoadPhylliticIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(109)
        if feedback.isCanceled():
            return {}

        # Ferrous Silicates Index
        alg_params = {
            'BAND_A': 1,
            'BAND_B': 1,
            'BAND_C': None,
            'BAND_D': None,
            'BAND_E': None,
            'BAND_F': None,
            'EXTENT_OPT': 3,  # Intersect
            'EXTRA': None,
            'FORMULA': 'A/B',
            'INPUT_A': outputs['Av_p2165']['OUTPUT'],
            'INPUT_B': outputs['RasterCalculatorP1650']['OUTPUT'],
            'INPUT_C': None,
            'INPUT_D': None,
            'INPUT_E': None,
            'INPUT_F': None,
            'NO_DATA': 0,
            'OPTIONS': None,
            'PROJWIN': None,
            'RTYPE': 5,  # Float32
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FerrousSilicatesIndex'] = processing.run('gdal:rastercalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(110)
        if feedback.isCanceled():
            return {}

        # Save Ferrous Silicates layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_FerrousSilicatesIndex.tif'),
            'raster': outputs['FerrousSilicatesIndex']['OUTPUT'],
        }
        outputs['SaveFerrousSilicatesLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(111)
        if feedback.isCanceled():
            return {}

        # Save MgOH Carb Index layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_MgOHCarbIndex.tif'),
            'raster': outputs['MgohCarbonateAbundIndex']['OUTPUT'],
        }
        outputs['SaveMgohCarbIndexLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(112)
        if feedback.isCanceled():
            return {}

        # RGB FerrSil-FerricIrAltn-MgOHCarb
        alg_params = {
            'ADD_ALPHA': False,
            'ASSIGN_CRS': None,
            'EXTRA': None,
            'INPUT': [outputs['FerrousSilicatesIndex']['OUTPUT'],outputs['FerricIronAltnIndex']['OUTPUT'],outputs['MgohCarbonateAbundIndex']['OUTPUT']],
            'PROJ_DIFFERENCE': False,
            'RESAMPLING': 0,  # Nearest Neighbour
            'RESOLUTION': 1,  # Highest
            'SEPARATE': True,
            'SRC_NODATA': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RgbFerrsilferriciraltnmgohcarb'] = processing.run('gdal:buildvirtualraster', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(113)
        if feedback.isCanceled():
            return {}

        # Save Propyitic layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_PropyliticAltnIndex.tif'),
            'raster': outputs['PropyliticAltnIndex']['OUTPUT'],
        }
        outputs['SavePropyiticLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(114)
        if feedback.isCanceled():
            return {}

        # Load Ferrous Silicates into project
        alg_params = {
            'INPUT': outputs['SaveFerrousSilicatesLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Ferrous Silicates Index'").evaluate()
        }
        outputs['LoadFerrousSilicatesIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(115)
        if feedback.isCanceled():
            return {}

        # Load MgOH-Carb into project
        alg_params = {
            'INPUT': outputs['SaveMgohCarbIndexLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_MgOH Carb Abundance Index'").evaluate()
        }
        outputs['LoadMgohcarbIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(116)
        if feedback.isCanceled():
            return {}

        # Load Propylitic into project
        alg_params = {
            'INPUT': outputs['SavePropyiticLayerAs']['outputRaster'],
            'NAME': QgsExpression("'ENVI_Propylitic_Altn Index'").evaluate()
        }
        outputs['LoadPropyliticIntoProject'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(117)
        if feedback.isCanceled():
            return {}

        # Save FeS-FeAlt-MgOH layer as
        alg_params = {
            'copyMetadata': True,
            'copyStyle': True,
            'creationProfile': 'GTiff INTERLEAVE=BAND COMPRESS=LZW PREDICTOR=2 BIGTIFF=YES',
            'mode': 0,  # Auto (recommended)
            'outputRaster': os.path.join(parameters['select_directory'], parameters['output_prefix'] + '_FeSil-FeAlt-MgOH.tif'),
            'raster': outputs['RgbFerrsilferriciraltnmgohcarb']['OUTPUT'],
        }
        outputs['SaveFesfealtmgohLayerAs'] = processing.run('enmapbox:saverasterlayeras', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(118)
        if feedback.isCanceled():
            return {}

        # Load layer into project
        alg_params = {
            'INPUT': outputs['SaveFesfealtmgohLayerAs']['outputRaster'],
            'NAME': QgsExpression("'RGB_FeSil-FeIrAltn-MgOHCarb'").evaluate()
        }
        outputs['LoadLayerIntoProject_2'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        return results

    def name(self) -> str:
        return 'PRISMA_ENVI_Indices'

    def displayName(self) -> str:
        return 'PRISMA_processing'

    def group(self) -> str:
        return ''

    def groupId(self) -> str:
        return ''

    def createInstance(self):
        return self.__class__()
