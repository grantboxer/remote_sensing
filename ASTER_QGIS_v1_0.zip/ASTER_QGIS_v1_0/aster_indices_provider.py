"""
ASTER Indices Processing Provider.
"""

from qgis.core import QgsProcessingProvider
from .aster_indices_algorithm import AsterIndicesAlgorithm


class AsterIndicesProvider(QgsProcessingProvider):

    def loadAlgorithms(self):
        self.addAlgorithm(AsterIndicesAlgorithm())

    def id(self):
        return 'asterindices'

    def name(self):
        return 'ASTER_processing'

    def longName(self):
        return 'ASTER_processing'

    def icon(self):
        return QgsProcessingProvider.icon(self)
