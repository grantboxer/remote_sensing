"""
ASTER Indices Plugin for QGIS
Computes geological and mineral mapping indices from ASTER satellite imagery.
Version 1.0
"""


def classFactory(iface):
    from .aster_indices_plugin import AsterIndicesPlugin
    return AsterIndicesPlugin(iface)
