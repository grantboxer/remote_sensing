"""
Hyperspectral Analysis Tools Plugin for QGIS
Ported from HyPy (Hyperspectral Python)

Original Author: Wim Bakker, University of Twente
QGIS Port: [Your Name]
License: GPL v3
"""

def classFactory(iface):
    """Load HyperspectralPlugin class from file hyperspectral_plugin.
    
    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .hyperspectral_plugin import HyperspectralPlugin
    return HyperspectralPlugin(iface)
