#!/bin/bash
# Package QGIS Plugin
# Creates a ZIP file ready for installation in QGIS

PLUGIN_NAME="hyperspectral_tools"
VERSION=$(grep "version=" metadata.txt | cut -d'=' -f2)
OUTPUT_FILE="${PLUGIN_NAME}_v${VERSION}.zip"

echo "Packaging ${PLUGIN_NAME} version ${VERSION}..."

# Remove old package if exists
if [ -f "$OUTPUT_FILE" ]; then
    rm "$OUTPUT_FILE"
    echo "Removed old package"
fi

# Files to include
FILES=(
    "__init__.py"
    "metadata.txt"
    "hyperspectral_plugin.py"
    "hyppy_provider.py"
    "README.md"
    "INSTALL.md"
    "DEVELOPER.md"
    "icon.svg"
    "example_spectral_library.csv"
    "algorithms/__init__.py"
    "algorithms/sam_algorithm.py"
    "core/__init__.py"
)

# Create temp directory
TEMP_DIR=$(mktemp -d)
PLUGIN_DIR="${TEMP_DIR}/${PLUGIN_NAME}"
mkdir -p "$PLUGIN_DIR"

echo "Copying files..."
for file in "${FILES[@]}"; do
    # Create directory structure if needed
    DIR=$(dirname "$file")
    if [ "$DIR" != "." ]; then
        mkdir -p "${PLUGIN_DIR}/${DIR}"
    fi
    
    # Copy file
    if [ -f "$file" ]; then
        cp "$file" "${PLUGIN_DIR}/${file}"
        echo "  ✓ $file"
    else
        echo "  ✗ $file (not found)"
    fi
done

# Create ZIP
echo "Creating ZIP archive..."
cd "$TEMP_DIR"
zip -r "$OUTPUT_FILE" "$PLUGIN_NAME" -q

# Move to original directory
mv "$OUTPUT_FILE" "$OLDPWD/"

# Cleanup
rm -rf "$TEMP_DIR"

echo ""
echo "✓ Package created: $OUTPUT_FILE"
echo ""
echo "To install:"
echo "  1. Open QGIS"
echo "  2. Go to Plugins → Manage and Install Plugins"
echo "  3. Click 'Install from ZIP'"
echo "  4. Select $OUTPUT_FILE"
echo ""
