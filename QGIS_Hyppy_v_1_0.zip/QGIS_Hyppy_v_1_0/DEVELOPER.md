# Developer Guide

## Overview

This guide helps developers extend the Hyperspectral Analysis Tools plugin by porting additional algorithms from HyPy.

## Architecture

```
hyperspectral_tools/
├── __init__.py                 # Plugin entry point
├── metadata.txt               # Plugin metadata
├── hyperspectral_plugin.py    # Main plugin class
├── hyppy_provider.py          # Processing provider
├── algorithms/                # Processing algorithms
├── core/                      # Shared spectral functions
├── ui/                        # Custom UI widgets (future)
└── resources/                 # Icons and resources
```

## Porting an Algorithm from HyPy

### Step 1: Choose an Algorithm

Look at the HyPy modules (from the original `hyppy3.zip`):

**High Priority:**
- `pca.py` - Principal Component Analysis
- `linearunmixing.py` - Linear Spectral Unmixing
- `bandmath.py` - Band Mathematics
- `convexhull.py` - Convex Hull Removal
- `normalize.py` - Normalization

**Medium Priority:**
- Spectral filters (median, gradient, etc.)
- Classification tools
- Preprocessing tools

### Step 2: Understand the Original Code

Example: Let's port PCA

1. **Examine the original file:**
   ```python
   # From pca.py in HyPy
   def pca(nameIn, nameOut, bands=None, ...):
       im = envi2.Open(nameIn)
       # ... PCA logic
   ```

2. **Identify key components:**
   - Input: ENVI image file
   - Output: PCA-transformed image
   - Parameters: Number of components, standardization, etc.
   - Processing: Uses numpy/scipy for PCA calculation

### Step 3: Create QGIS Processing Algorithm

Create `algorithms/pca_algorithm.py`:

```python
"""
PCA Algorithm for QGIS Processing

Ported from HyPy pca.py
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
)
import numpy as np
from osgeo import gdal

class PCAAlgorithm(QgsProcessingAlgorithm):
    
    INPUT = 'INPUT'
    NUM_COMPONENTS = 'NUM_COMPONENTS'
    STANDARDIZE = 'STANDARDIZE'
    OUTPUT = 'OUTPUT'
    
    def initAlgorithm(self, config=None):
        """Define inputs and outputs"""
        
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Raster'
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.NUM_COMPONENTS,
                'Number of Components',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=3,
                minValue=1
            )
        )
        
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.STANDARDIZE,
                'Standardize Data',
                defaultValue=True
            )
        )
        
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output PCA Image'
            )
        )
    
    def processAlgorithm(self, parameters, context, feedback):
        """Execute the algorithm"""
        
        # Get parameters
        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        num_components = self.parameterAsInt(parameters, self.NUM_COMPONENTS, context)
        standardize = self.parameterAsBool(parameters, self.STANDARDIZE, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        
        # Open input
        ds = gdal.Open(input_layer.source())
        
        # Read data
        rows = ds.RasterYSize
        cols = ds.RasterXSize
        bands = ds.RasterCount
        
        # Read all bands
        data = np.zeros((rows, cols, bands))
        for b in range(bands):
            band = ds.GetRasterBand(b + 1)
            data[:, :, b] = band.ReadAsArray()
        
        # Reshape for PCA
        data_2d = data.reshape(-1, bands)
        
        # Perform PCA
        from sklearn.decomposition import PCA
        pca = PCA(n_components=num_components)
        
        if standardize:
            # Standardize data
            mean = np.mean(data_2d, axis=0)
            std = np.std(data_2d, axis=0)
            data_2d = (data_2d - mean) / (std + 1e-10)
        
        pca_result = pca.fit_transform(data_2d)
        
        # Reshape back
        pca_image = pca_result.reshape(rows, cols, num_components)
        
        # Create output
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(output_path, cols, rows, num_components, gdal.GDT_Float32)
        out_ds.SetGeoTransform(ds.GetGeoTransform())
        out_ds.SetProjection(ds.GetProjection())
        
        # Write bands
        for b in range(num_components):
            out_band = out_ds.GetRasterBand(b + 1)
            out_band.WriteArray(pca_image[:, :, b])
            out_band.SetDescription(f'PC{b+1}')
        
        out_ds = None
        ds = None
        
        return {self.OUTPUT: output_path}
    
    def name(self):
        return 'pca'
    
    def displayName(self):
        return 'Principal Component Analysis (PCA)'
    
    def group(self):
        return 'Dimensionality Reduction'
    
    def groupId(self):
        return 'dimensionality'
    
    def createInstance(self):
        return PCAAlgorithm()
```

### Step 4: Register the Algorithm

Edit `hyppy_provider.py`:

```python
from .algorithms.pca_algorithm import PCAAlgorithm

class HyppyProvider(QgsProcessingProvider):
    
    def loadAlgorithms(self):
        self.addAlgorithm(SpectralAngleMapperAlgorithm())
        self.addAlgorithm(PCAAlgorithm())  # Add new algorithm
```

### Step 5: Test

1. Reload the plugin in QGIS
2. Check Processing Toolbox for new algorithm
3. Test with sample data
4. Verify outputs match original HyPy results

## Code Patterns

### Reading Rasters

```python
from osgeo import gdal

ds = gdal.Open(filepath)
band = ds.GetRasterBand(band_number)  # 1-indexed!
array = band.ReadAsArray()
```

### Writing Rasters

```python
driver = gdal.GetDriverByName('GTiff')
out_ds = driver.Create(output_path, width, height, num_bands, gdal.GDT_Float32)

# Copy georeference
out_ds.SetGeoTransform(input_ds.GetGeoTransform())
out_ds.SetProjection(input_ds.GetProjection())

# Write data
for b in range(num_bands):
    out_band = out_ds.GetRasterBand(b + 1)
    out_band.WriteArray(data[:, :, b])
    out_band.FlushCache()

out_ds = None  # Close file
```

### Progress Reporting

```python
def processAlgorithm(self, parameters, context, feedback):
    total_steps = 100
    
    for i in range(total_steps):
        # Check if user canceled
        if feedback.isCanceled():
            return {}
        
        # Do work...
        
        # Update progress (0-100)
        feedback.setProgress(int((i + 1) / total_steps * 100))
        
        # Show messages
        feedback.pushInfo(f'Processing step {i+1}')
```

### Error Handling

```python
from qgis.core import QgsProcessingException

try:
    # Processing code
    pass
except Exception as e:
    raise QgsProcessingException(f'Algorithm failed: {str(e)}')
```

## Common Conversions

### HyPy → QGIS

| HyPy Pattern | QGIS Pattern |
|--------------|--------------|
| `envi2.Open(path)` | `gdal.Open(path)` |
| `im.samples` | `ds.RasterXSize` |
| `im.lines` | `ds.RasterYSize` |
| `im.bands` | `ds.RasterCount` |
| `im[j, i]` | `band.ReadAsArray()[j, i]` |
| `envi2.New(...)` | `driver.Create(...)` |
| Tkinter GUI | Processing parameters |

### ENVI Header → GDAL Metadata

HyPy uses ENVI headers extensively. In QGIS/GDAL:

```python
# Read metadata
ds = gdal.Open(filepath)
metadata = ds.GetMetadata('ENVI')

# Wavelengths (if available)
wavelengths = metadata.get('wavelength', '')
if wavelengths:
    wl_list = [float(w) for w in wavelengths.split(',')]

# Band names
for b in range(ds.RasterCount):
    band = ds.GetRasterBand(b + 1)
    band_name = band.GetDescription()
```

## Testing

### Unit Tests

Create `tests/test_sam.py`:

```python
import unittest
from ..core import spectral_angle
import numpy as np

class TestSpectralAngle(unittest.TestCase):
    
    def test_identical_spectra(self):
        """Identical spectra should have angle of 0"""
        s1 = np.array([1, 2, 3, 4])
        s2 = np.array([1, 2, 3, 4])
        angle = spectral_angle(s1, s2)
        self.assertAlmostEqual(angle, 0.0)
    
    def test_orthogonal_spectra(self):
        """Orthogonal spectra should have angle of π/2"""
        s1 = np.array([1, 0])
        s2 = np.array([0, 1])
        angle = spectral_angle(s1, s2)
        self.assertAlmostEqual(angle, np.pi/2)
```

### Integration Tests

Test with real data:

1. Create small test images (10x10, 5 bands)
2. Run algorithm
3. Verify output exists and has correct dimensions
4. Compare results with HyPy output

## Performance Optimization

### Memory Management

For large images:

```python
# Bad: Load entire image
data = np.zeros((rows, cols, bands))  # Memory intensive!

# Good: Process in chunks
chunk_size = 1000
for row_start in range(0, rows, chunk_size):
    row_end = min(row_start + chunk_size, rows)
    chunk = data[row_start:row_end, :, :]
    # Process chunk
```

### Vectorization

```python
# Bad: Nested loops
for i in range(rows):
    for j in range(cols):
        result[i, j] = process_pixel(data[i, j])

# Good: Vectorized
result = vectorized_process(data)
```

## Documentation

### Algorithm Help String

```python
def shortHelpString(self):
    return """
    <b>Algorithm Name</b>
    
    <p>Brief description of what the algorithm does.</p>
    
    <p><b>Inputs:</b></p>
    <ul>
    <li><b>Parameter 1:</b> Description</li>
    <li><b>Parameter 2:</b> Description</li>
    </ul>
    
    <p><b>Outputs:</b></p>
    <ul>
    <li><b>Output 1:</b> Description</li>
    </ul>
    
    <p><b>References:</b> Citation if applicable</p>
    
    <p><i>Ported from HyPy by Wim Bakker, University of Twente</i></p>
    """
```

## Debugging

### Python Console

In QGIS Python Console:

```python
import hyperspectral_tools
import importlib
importlib.reload(hyperspectral_tools.algorithms.sam_algorithm)

# Test function
from hyperspectral_tools.core import spectral_angle
import numpy as np
s1 = np.array([1, 2, 3])
s2 = np.array([1, 2, 3])
print(spectral_angle(s1, s2))
```

### Logging

```python
from qgis.core import QgsMessageLog, Qgis

QgsMessageLog.logMessage('Debug message', 'HypPy', Qgis.Info)
QgsMessageLog.logMessage('Error message', 'HypPy', Qgis.Critical)
```

## Contributing

1. **Fork** the repository
2. **Create** a feature branch: `git checkout -b feature/pca-algorithm`
3. **Develop** your algorithm following these patterns
4. **Test** thoroughly
5. **Document** in code and README
6. **Submit** pull request

## Resources

- **QGIS Processing API:** https://qgis.org/pyqgis/master/core/QgsProcessingAlgorithm.html
- **GDAL Python:** https://gdal.org/python/
- **NumPy:** https://numpy.org/doc/
- **SciPy:** https://docs.scipy.org/doc/scipy/
- **Original HyPy:** Contact Wim Bakker (w.h.bakker@utwente.nl)

---

**Happy Coding!** 🚀
