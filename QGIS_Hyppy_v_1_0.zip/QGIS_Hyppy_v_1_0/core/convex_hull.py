"""
Convex Hull Utilities for Hyperspectral Analysis

Ported from HyPy quickhull2d.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np


def qhulltop(sample):
    """
    Compute the top (upper) convex hull of a set of 2D points.
    
    Args:
        sample: Nx2 numpy array of (x, y) points
    
    Returns:
        Mx2 numpy array of hull points
    """
    link = lambda a, b: np.concatenate((a, b[1:]))
    edge = lambda a, b: np.concatenate(([a], [b]))
    
    def dome(sample, base):
        h, t = base
        dists = np.dot(sample - h, np.dot(((0, -1), (1, 0)), (t - h)))
        outer = np.repeat(sample, dists > 0, axis=0)
        
        if len(outer):
            pivot = sample[np.argmax(dists)]
            return link(dome(outer, edge(h, pivot)),
                       dome(outer, edge(pivot, t)))
        else:
            return base
    
    if len(sample) > 2:
        axis = sample[:, 0]
        base = np.take(sample, [np.argmin(axis), np.argmax(axis)], axis=0)
        return dome(sample, base)
    else:
        return sample


def resample_hull(hull, sample):
    """
    Resample convex hull to match x-coordinates of sample points.
    
    Performs linear interpolation to find hull y-values at sample x-values.
    
    Args:
        hull: Mx2 numpy array of hull points
        sample: Nx2 numpy array of sample points
    
    Returns:
        Nx2 numpy array of resampled hull points
    """
    xs = sample[:, 0].copy()
    xs.sort()
    ys = np.zeros(xs.shape)
    xhull = hull[:, 0]
    yhull = hull[:, 1]
    
    for i in range(len(xs)):
        i_hull = xhull.searchsorted(xs[i])
        if i_hull == 0:
            ys[i] = yhull[0]
        elif i_hull == len(hull):
            ys[i] = yhull[-1]
        elif xs[i] == xhull[i_hull]:
            ys[i] = yhull[i_hull]
        else:
            i_left = i_hull - 1
            i_right = i_hull
            # Linear interpolation
            ys[i] = (xs[i] - xhull[i_left]) / (xhull[i_right] - xhull[i_left]) * \
                    (yhull[i_right] - yhull[i_left]) + yhull[i_left]
    
    return np.vstack((xs, ys)).T


def hull_resampled(sample):
    """
    Compute convex hull and resample to original x-coordinates.
    
    This is useful for continuum removal in spectral analysis.
    
    Args:
        sample: Nx2 numpy array of (wavelength, reflectance) points
    
    Returns:
        Nx2 numpy array of (wavelength, hull_value) points
    """
    hull = qhulltop(sample)
    return resample_hull(hull, sample)
