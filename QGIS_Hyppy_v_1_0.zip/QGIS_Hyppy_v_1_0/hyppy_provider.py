"""
HyPpy Processing Provider

This provider makes all HyPy algorithms available in QGIS Processing Toolbox.

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
import os

from .algorithms.sam_algorithm import SpectralAngleMapperAlgorithm
from .algorithms.wavelength_of_minimum_algorithm import WavelengthOfMinimumAlgorithm
from .algorithms.wavelength_mapping_algorithm import WavelengthMappingAlgorithm
# Import more algorithms as they are created:
# from .algorithms.pca_algorithm import PCAAlgorithm
# from .algorithms.linear_unmixing_algorithm import LinearUnmixingAlgorithm


class HyppyProvider(QgsProcessingProvider):
    """Processing provider for Hyperspectral Analysis Tools"""

    def __init__(self):
        super().__init__()

    def load(self):
        """Called when the provider is first loaded"""
        self.refreshAlgorithms()
        return True

    def unload(self):
        """Called when provider is unloaded"""
        pass

    def loadAlgorithms(self):
        """Load all algorithms belonging to this provider."""
        
        # Classification and Spectral Matching
        self.addAlgorithm(SpectralAngleMapperAlgorithm())
        
        # Spectral Analysis
        self.addAlgorithm(WavelengthOfMinimumAlgorithm())
        self.addAlgorithm(WavelengthMappingAlgorithm())
        
        # Add more algorithms as they are ported:
        # self.addAlgorithm(PCAAlgorithm())
        # self.addAlgorithm(LinearUnmixingAlgorithm())
        # self.addAlgorithm(BandMathAlgorithm())
        # self.addAlgorithm(ConvexHullRemovalAlgorithm())
        # etc.

    def id(self):
        """Unique provider ID"""
        return 'hyppy'

    def name(self):
        """Human-readable provider name"""
        return 'QGIS_Hyppy_v_1.0'

    def longName(self):
        """Longer version of the provider name"""
        return 'QGIS_Hyppy_v_1.0 (HyPpy)'

    def icon(self):
        """Provider icon"""
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return QgsProcessingProvider.icon(self)

    def svgIconPath(self):
        """SVG icon path"""
        return os.path.join(os.path.dirname(__file__), 'icon.svg')
