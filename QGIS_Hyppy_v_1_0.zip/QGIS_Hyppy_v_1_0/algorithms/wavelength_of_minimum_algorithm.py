"""
Wavelength of Minimum v2 Algorithm for QGIS Processing

Determines interpolated wavelength of minimum and depth of the deepest
absorption features in hyperspectral data.

Ported from HyPy minwavelength2.py / tkMinWavelength2.py
Original Author: Wim Bakker, University of Twente (w.h.bakker@utwente.nl)

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2018 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis
)

from ..core.convex_hull import hull_resampled


# Band names for up to 9 features (wavelength, depth pairs)
BAND_NAMES = [
    'interpolated min. wav.',   'interpolated depth',
    'interpolated min. wav. 2', 'interpolated depth 2',
    'interpolated min. wav. 3', 'interpolated depth 3',
    'interpolated min. wav. 4', 'interpolated depth 4',
    'interpolated min. wav. 5', 'interpolated depth 5',
    'interpolated min. wav. 6', 'interpolated depth 6',
    'interpolated min. wav. 7', 'interpolated depth 7',
    'interpolated min. wav. 8', 'interpolated depth 8',
    'interpolated min. wav. 9', 'interpolated depth 9'
]


class WavelengthOfMinimumAlgorithm(QgsProcessingAlgorithm):
    """
    Wavelength of Minimum v2 Algorithm
    
    Determines the interpolated wavelength position and depth of absorption 
    features in hyperspectral data. Uses convex hull removal to isolate 
    absorption features, then fits parabolas to local minima to find precise 
    minimum wavelengths and feature depths.
    
    Based on HyPy minwavelength2.py by Wim Bakker.
    
    Outputs pairs of (interpolated min wavelength, interpolated depth) for
    each requested feature, sorted by depth (deepest first).
    """

    INPUT = 'INPUT'
    START_WAVELENGTH = 'START_WAVELENGTH'
    END_WAVELENGTH = 'END_WAVELENGTH'
    MODE = 'MODE'
    NUM_FEATURES = 'NUM_FEATURES'
    BROAD = 'BROAD'
    USE_BBL = 'USE_BBL'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        """Define inputs and outputs."""
        
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image',
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.START_WAVELENGTH,
                'Start Wavelength (nm)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=2000.0,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.END_WAVELENGTH,
                'End Wavelength (nm)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=2500.0,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterEnum(
                self.MODE,
                'Continuum Removal Mode',
                options=[
                    'Division (recommended)',
                    'Subtraction',
                    'None (use original spectrum)'
                ],
                defaultValue=0,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.NUM_FEATURES,
                'Number of features to match (1-9)',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=1,
                minValue=1,
                maxValue=9,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.BROAD,
                'Broad feature fitting',
                defaultValue=False,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Use Bad Band List (BBL)',
                defaultValue=True,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Wavelength Features',
                optional=False
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the algorithm."""
        
        # Get parameters
        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        start_wav = self.parameterAsDouble(parameters, self.START_WAVELENGTH, context)
        end_wav = self.parameterAsDouble(parameters, self.END_WAVELENGTH, context)
        mode_idx = self.parameterAsEnum(parameters, self.MODE, context)
        num_features = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        broad = self.parameterAsBool(parameters, self.BROAD, context)
        use_bbl = self.parameterAsBool(parameters, self.USE_BBL, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        
        modes = ['div', 'sub', 'none']
        mode = modes[mode_idx]
        
        feedback.pushInfo(f'Continuum removal mode: {mode}')
        feedback.pushInfo(f'Wavelength range: {start_wav} - {end_wav} nm')
        feedback.pushInfo(f'Number of features: {num_features}')
        feedback.pushInfo(f'Broad feature fitting: {broad}')
        
        # Open input raster
        input_ds = gdal.Open(input_layer.source(), gdal.GA_ReadOnly)
        if input_ds is None:
            raise QgsProcessingException('Failed to open input raster')
        
        cols = input_ds.RasterXSize
        rows = input_ds.RasterYSize
        num_bands = input_ds.RasterCount
        
        # Get wavelengths from metadata
        wavelengths = self.get_wavelengths(input_ds, num_bands, feedback)
        
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength information found. Image must have wavelength metadata.'
            )
        
        # Get bad band list if requested
        bbl = None
        if use_bbl:
            bbl = self.get_bbl(input_ds, num_bands, feedback)
        
        # Find band range
        start_band = self.wavelength_to_index(wavelengths, start_wav)
        end_band = self.wavelength_to_index(wavelengths, end_wav) + 1  # include end wavelength
        
        if start_band >= end_band:
            raise QgsProcessingException('Invalid wavelength range')
        
        wavs = wavelengths[start_band:end_band]
        
        # Apply BBL mask to wavelength subset if available
        bbl_mask = None
        if bbl is not None:
            bbl_mask = bbl[start_band:end_band]
            good_count = np.sum(bbl_mask)
            feedback.pushInfo(f'BBL: {good_count} of {len(bbl_mask)} bands are good in range')
        
        feedback.pushInfo(f'Using bands {start_band} to {end_band-1} ({len(wavs)} bands)')
        
        # Output bands: numfeatures * 2 (wavelength + depth pairs)
        num_output_bands = num_features * 2
        band_names = BAND_NAMES[:num_output_bands]
        
        # Create output raster
        feedback.pushInfo('Creating output raster...')
        driver = gdal.GetDriverByName('GTiff')
        output_ds = driver.Create(
            output_path,
            cols, rows, num_output_bands,
            gdal.GDT_Float64  # double precision as per minwavelength2.py
        )
        
        output_ds.SetGeoTransform(input_ds.GetGeoTransform())
        output_ds.SetProjection(input_ds.GetProjection())
        
        for b, name in enumerate(band_names):
            band = output_ds.GetRasterBand(b + 1)
            band.SetDescription(name)
            band.SetNoDataValue(np.nan)
        
        # Read input data for the wavelength subset
        feedback.pushInfo('Reading input data...')
        subset_bands = end_band - start_band
        image_data = np.zeros((rows, cols, subset_bands), dtype=np.float64)
        for b in range(subset_bands):
            if feedback.isCanceled():
                return {}
            band = input_ds.GetRasterBand(start_band + b + 1)
            image_data[:, :, b] = band.ReadAsArray()
            feedback.setProgress(int((b + 1) / subset_bands * 10))
        
        # Process each pixel
        feedback.pushInfo('Processing pixels...')
        output_data = np.full((rows, cols, num_output_bands), np.nan, dtype=np.float64)
        
        total_pixels = rows * cols
        processed = 0
        
        for row in range(rows):
            if feedback.isCanceled():
                return {}
            
            for col in range(cols):
                spec = image_data[row, col, :]
                
                # Check if spectrum is valid (not all zeros/nan)
                if np.all(np.isfinite(spec)) and not np.all(spec == 0):
                    # Apply BBL mask if available
                    if bbl_mask is not None:
                        working_wavs = wavs[bbl_mask.astype(bool)]
                        working_spec = spec[bbl_mask.astype(bool)]
                    else:
                        working_wavs = wavs
                        working_spec = spec
                    
                    if len(working_wavs) < 3:
                        processed += 1
                        continue
                    
                    # Apply continuum removal (nohull equivalent)
                    hull_removed = self.nohull(working_wavs, working_spec, mode)
                    
                    if hull_removed is None:
                        processed += 1
                        continue
                    
                    # Find local minima and fit parabolas
                    minwavs = self.minwav(
                        working_wavs, hull_removed, num_features, broad
                    )
                    
                    # Store results: sorted by depth (deepest first)
                    for k in range(len(minwavs)):
                        output_data[row, col, 2*k] = minwavs[k][0]      # wavelength
                        output_data[row, col, 2*k + 1] = minwavs[k][1]  # depth
                
                processed += 1
                if processed % 1000 == 0:
                    progress = 10 + int((processed / total_pixels) * 90)
                    feedback.setProgress(progress)
        
        # Write output bands
        feedback.pushInfo('Writing output...')
        for b in range(num_output_bands):
            if feedback.isCanceled():
                return {}
            band = output_ds.GetRasterBand(b + 1)
            band.WriteArray(output_data[:, :, b])
            band.FlushCache()
        
        # Cleanup
        output_ds = None
        input_ds = None
        
        feedback.pushInfo('Complete!')
        
        return {self.OUTPUT: output_path}

    def nohull(self, wavelengths, spectrum, mode):
        """
        Apply continuum removal using convex hull.
        
        Equivalent to HyPy Spectrum.nohull() method.
        
        Args:
            wavelengths: array of wavelength values
            spectrum: array of spectral values
            mode: 'div' for division, 'sub' for subtraction, 'none' for no removal
        
        Returns:
            Array of continuum-removed spectral values, or None on error
        """
        if mode == 'none':
            return spectrum.copy()
        
        try:
            points = np.column_stack((wavelengths, spectrum))
            hull_values = hull_resampled(points)[:, 1]
            
            if mode == 'div':
                # Avoid division by zero
                hull_safe = np.where(hull_values != 0, hull_values, 1e-10)
                return spectrum / hull_safe
            elif mode == 'sub':
                return 1.0 + (spectrum - hull_values)
            else:
                return spectrum.copy()
        except Exception:
            return None

    def minwav(self, wavelengths, hull_removed, num_features, broad):
        """
        Calculate minimum wavelength positions and depths.
        
        Equivalent to HyPy Spectrum.minwav() which computes:
            1 - S.nohull(mode).localminfit(n, broad)
        then returns (wavelength, depth) pairs sorted by depth descending.
        
        Args:
            wavelengths: array of wavelength values
            hull_removed: continuum-removed spectrum
            num_features: number of features to find
            broad: if True, use broad feature fitting
        
        Returns:
            List of (wavelength, depth) tuples sorted by depth (deepest first)
        """
        # Find local minima indices
        local_min_idx = self.localminidx(hull_removed, num_features)
        
        if len(local_min_idx) == 0:
            return []
        
        # Fit parabolas to local minima
        if broad:
            fitted = self.fitparabola_broad(wavelengths, hull_removed, local_min_idx)
        else:
            fitted = self.fitparabola(wavelengths, hull_removed, local_min_idx)
        
        # Convert to (wavelength, depth) pairs where depth = 1 - fitted_value
        # Sort by depth descending (deepest first)
        result = sorted(
            [(w, 1.0 - s) for w, s in fitted],
            key=lambda x: x[1],
            reverse=True
        )
        
        return result

    def localminidx(self, spectrum, n=None):
        """
        Find indices of the n smallest local minima.
        
        Equivalent to HyPy Spectrum.localminidx().
        
        Args:
            spectrum: 1D array of spectral values
            n: number of minima to return (None for all)
        
        Returns:
            Array of indices
        """
        a = spectrum
        # Find indices where value is less than both neighbors
        idx = np.where((a[1:-1] < a[:-2]) & (a[1:-1] < a[2:]))[0] + 1
        
        if n and len(idx):
            # Sort by value, take n smallest, then sort by index order
            s = spectrum[idx]
            pairs = sorted(zip(s, idx))[:n]
            pairs = sorted(pairs, key=lambda x: x[1])
            if pairs:
                s, idx = zip(*pairs)
                idx = list(idx)
            else:
                idx = []
        
        return np.array(idx)

    def fitparabola(self, wavelengths, spectrum, idx):
        """
        Fit parabola through three adjacent points at each local minimum.
        
        Equivalent to HyPy Spectrum._fitparabola().
        
        Args:
            wavelengths: array of wavelength values
            spectrum: array of spectral values
            idx: array of local minimum indices
        
        Returns:
            List of (wavelength, value) tuples at parabola vertices
        """
        results = []
        for i in idx:
            if i < 1 or i >= len(wavelengths) - 1:
                results.append((wavelengths[i], spectrum[i]))
                continue
            
            x = [wavelengths[i-1], wavelengths[i], wavelengths[i+1]]
            y = [spectrum[i-1], spectrum[i], spectrum[i+1]]
            
            try:
                coef = np.polyfit(x, y, 2)
                a, b, c = coef
                if a != 0:
                    x_ext = -b / (2 * a)
                    y_ext = np.polyval(coef, x_ext)
                    results.append((x_ext, y_ext))
                else:
                    results.append((wavelengths[i], spectrum[i]))
            except Exception:
                results.append((wavelengths[i], spectrum[i]))
        
        return results

    def fitparabola_broad(self, wavelengths, spectrum, idx):
        """
        Fit broad parabola through adjacent points at each local minimum.
        
        Uses points within the half-depth of the feature for a broader fit.
        
        Equivalent to HyPy Spectrum._fitparabola_broad().
        
        Args:
            wavelengths: array of wavelength values
            spectrum: array of spectral values
            idx: array of local minimum indices
        
        Returns:
            List of (wavelength, value) tuples at parabola vertices
        """
        results = []
        s = spectrum
        w = wavelengths
        
        for i in idx:
            # Expand fitting window to half-depth threshold
            lowidx = i - 1
            while lowidx - 1 > 0 and s[lowidx - 1] <= (s[i] + 1) / 2:
                lowidx -= 1
            
            highidx = i + 1
            while highidx + 1 < len(s) - 1 and s[highidx + 1] <= (s[i] + 1) / 2:
                highidx += 1
            
            x = w[lowidx:highidx + 1]
            y = s[lowidx:highidx + 1]
            
            if len(x) < 3:
                results.append((w[i], s[i]))
                continue
            
            try:
                coef = np.polyfit(x, y, 2)
                a, b, c = coef
                if a != 0:
                    x_ext = -b / (2 * a)
                    y_ext = np.polyval(coef, x_ext)
                    results.append((x_ext, y_ext))
                else:
                    results.append((w[i], s[i]))
            except Exception:
                results.append((w[i], s[i]))
        
        return results

    def get_wavelengths(self, dataset, num_bands, feedback):
        """Extract wavelength information from dataset metadata."""
        
        # Try ENVI metadata first
        metadata = dataset.GetMetadata('ENVI')
        if metadata and 'wavelength' in metadata:
            wl_str = metadata['wavelength']
            wl_str = wl_str.strip('{}')
            try:
                wavelengths = np.array([float(w.strip()) for w in wl_str.split(',')])
                if len(wavelengths) == num_bands:
                    feedback.pushInfo(f'Found {len(wavelengths)} wavelengths in ENVI metadata')
                    return wavelengths
            except Exception:
                pass
        
        # Try band descriptions
        wavelengths = []
        for b in range(num_bands):
            band = dataset.GetRasterBand(b + 1)
            desc = band.GetDescription()
            try:
                wav = float(desc)
                wavelengths.append(wav)
            except (ValueError, TypeError):
                wavelengths.append(None)
        
        if None not in wavelengths and len(wavelengths) == num_bands:
            feedback.pushInfo('Found wavelengths in band descriptions')
            return np.array(wavelengths)
        
        feedback.reportError('No wavelength metadata found. Using band numbers.')
        return None

    def get_bbl(self, dataset, num_bands, feedback):
        """Extract Bad Band List from dataset metadata."""
        metadata = dataset.GetMetadata('ENVI')
        if metadata and 'bbl' in metadata:
            bbl_str = metadata['bbl']
            bbl_str = bbl_str.strip('{}')
            try:
                bbl = np.array([int(b.strip()) for b in bbl_str.split(',')])
                if len(bbl) == num_bands:
                    feedback.pushInfo(f'Found BBL in metadata ({np.sum(bbl)} good bands)')
                    return bbl
            except Exception:
                pass
        return None

    def wavelength_to_index(self, wavelengths, target_wavelength):
        """Find band index closest to target wavelength."""
        return int(np.argmin(np.abs(wavelengths - target_wavelength)))

    def name(self):
        return 'wavelength_of_minimum'

    def displayName(self):
        return 'Wavelength of Minimum v2'

    def group(self):
        return 'Spectral Analysis'

    def groupId(self):
        return 'spectral_analysis'

    def shortHelpString(self):
        return """
        <b>Wavelength of Minimum v2</b>
        
        <p>Determines the interpolated wavelength position and depth of absorption 
        features in hyperspectral data. Based on HyPy minwavelength2.py by 
        Wim Bakker, University of Twente.</p>
        
        <p><b>Process:</b></p>
        <ol>
        <li>Applies convex hull continuum removal to isolate absorption features</li>
        <li>Finds local minima in the specified wavelength range</li>
        <li>Fits parabolas to refine minimum positions and calculate depths</li>
        <li>Returns results sorted by depth (deepest feature first)</li>
        </ol>
        
        <p><b>Inputs:</b></p>
        <ul>
        <li><b>Input Image:</b> Hyperspectral image with wavelength metadata</li>
        <li><b>Start/End Wavelength:</b> Analysis range (e.g., 2000-2500 nm for minerals)</li>
        <li><b>Mode:</b> Continuum removal method
            <ul>
            <li><b>Division:</b> Divide by hull (recommended, preserves shape)</li>
            <li><b>Subtraction:</b> Subtract hull (additive features)</li>
            <li><b>None:</b> Use original spectrum (no continuum removal)</li>
            </ul>
        </li>
        <li><b>Number of features:</b> How many absorption features to match (1-9)</li>
        <li><b>Broad feature fitting:</b> Uses wider fitting window for broad features</li>
        <li><b>Use BBL:</b> Apply bad band list from ENVI metadata if available</li>
        </ul>
        
        <p><b>Outputs (2 bands per feature):</b></p>
        <ul>
        <li>Interpolated minimum wavelength (parabola-fitted position)</li>
        <li>Interpolated depth (feature strength)</li>
        </ul>
        <p>Features are sorted by depth, deepest first.</p>
        
        <p><b>Applications:</b></p>
        <ul>
        <li>Mineral identification (absorption positions)</li>
        <li>Vegetation stress detection (chlorophyll absorption)</li>
        <li>Water content mapping (2000-2500 nm range)</li>
        <li>Material classification</li>
        </ul>
        
        <p><b>Tips:</b></p>
        <ul>
        <li>Use the interpolated wavelength for most accurate feature position</li>
        <li>Use depth to map feature strength</li>
        <li>Enable broad feature fitting for wide absorption features</li>
        <li>Combine wavelength and depth for mapping (see Wavelength Mapping tool)</li>
        </ul>
        
        <p><i>Ported from HyPy by Wim Bakker, University of Twente</i></p>
        """

    def createInstance(self):
        return WavelengthOfMinimumAlgorithm()
