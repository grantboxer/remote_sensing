"""
Hyperspectral Processing Algorithms

This package contains QGIS Processing algorithms ported from HyPy.
"""
