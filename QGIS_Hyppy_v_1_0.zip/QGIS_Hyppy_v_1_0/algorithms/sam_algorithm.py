"""
Spectral Angle Mapper (SAM) Algorithm for QGIS Processing

Ported from HyPy sam.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import numpy as np
from osgeo import gdal, osr

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterFile,
    QgsProcessingParameterEnum,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
    QgsRasterLayer,
    QgsMessageLog,
    Qgis
)

from ..core import (
    spectral_angle,
    bray_curtis_distance,
    spectral_information_divergence,
    euclidean_distance,
    intensity_difference,
    resample_spectrum
)


class SpectralAngleMapperAlgorithm(QgsProcessingAlgorithm):
    """
    Spectral Angle Mapper (SAM) Classification Algorithm
    
    SAM is a physically-based spectral classification that uses an n-dimensional
    angle to match pixels to reference spectra. The algorithm determines the
    spectral similarity between two spectra by calculating the angle between
    the spectra, treating them as vectors in a space with dimensionality equal
    to the number of bands.
    
    This implementation supports multiple spectral similarity measures:
    - SAM (Spectral Angle Mapper) - default
    - BC (Bray-Curtis Distance)
    - SID (Spectral Information Divergence)
    - ED (Euclidean Distance)
    - ID (Intensity Difference)
    """

    # Parameter names
    INPUT = 'INPUT'
    SPECLIB = 'SPECLIB'
    LIST_SPECTRA = 'LIST_SPECTRA'
    SPECFILTER = 'SPECFILTER'
    MODE = 'MODE'
    OUTPUT_RULES = 'OUTPUT_RULES'
    OUTPUT_CLASS = 'OUTPUT_CLASS'

    def initAlgorithm(self, config=None):
        """Define the inputs and outputs of the algorithm."""
        
        # Input hyperspectral image
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image',
                optional=False
            )
        )
        
        # Spectral library file
        self.addParameter(
            QgsProcessingParameterFile(
                self.SPECLIB,
                'Spectral Library',
                behavior=QgsProcessingParameterFile.File,
                fileFilter='ENVI Spectral Library (*.sli *.hdr);;CSV Spectral Library (*.csv *.txt);;All Files (*.*)',
                optional=False
            )
        )
        
        # List available spectra (run with this checked to see names before filtering)
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.LIST_SPECTRA,
                'List available spectra names (does not run SAM)',
                defaultValue=False,
                optional=True
            )
        )
        
        # Spectra filter
        self.addParameter(
            QgsProcessingParameterString(
                self.SPECFILTER,
                'Spectra filter (comma-separated names, supports * wildcards. Leave empty for all)',
                defaultValue='',
                optional=True
            )
        )
        
        # Similarity measure mode
        self.addParameter(
            QgsProcessingParameterEnum(
                self.MODE,
                'Similarity Measure',
                options=[
                    'SAM - Spectral Angle Mapper (recommended)',
                    'BC - Bray-Curtis Distance',
                    'SID - Spectral Information Divergence',
                    'ED - Euclidean Distance',
                    'ID - Intensity Difference'
                ],
                defaultValue=0,
                optional=False
            )
        )
        
        # Output rule image (continuous similarity values for each class)
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RULES,
                'Output Rule Image',
                optional=False
            )
        )
        
        # Output classification image (discrete class assignments)
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_CLASS,
                'Output Classification Image (optional)',
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the algorithm."""
        
        # Get parameters
        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        speclib_path = self.parameterAsFile(parameters, self.SPECLIB, context)
        list_spectra = self.parameterAsBool(parameters, self.LIST_SPECTRA, context)
        spec_filter = self.parameterAsString(parameters, self.SPECFILTER, context).strip()
        mode_idx = self.parameterAsEnum(parameters, self.MODE, context)
        output_rules_path = self.parameterAsOutputLayer(parameters, self.OUTPUT_RULES, context)
        output_class_path = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS, context)
        
        # Map mode index to function
        modes = ['SAM', 'BC', 'SID', 'ED', 'ID']
        mode = modes[mode_idx]
        
        distance_functions = {
            'SAM': spectral_angle,
            'BC': bray_curtis_distance,
            'SID': spectral_information_divergence,
            'ED': euclidean_distance,
            'ID': intensity_difference
        }
        
        diff_func = distance_functions[mode]
        
        feedback.pushInfo(f'Using {mode} similarity measure')
        
        # Open input raster
        input_ds = gdal.Open(input_layer.source(), gdal.GA_ReadOnly)
        if input_ds is None:
            raise QgsProcessingException(f'Failed to open input raster: {input_layer.source()}')
        
        # Get raster dimensions
        cols = input_ds.RasterXSize
        rows = input_ds.RasterYSize
        bands = input_ds.RasterCount
        
        feedback.pushInfo(f'Input image: {cols} x {rows} pixels, {bands} bands')
        
        # Read all bands into memory (for smaller images)
        # For large images, this should be done in chunks
        feedback.pushInfo('Reading input image...')
        image_data = np.zeros((rows, cols, bands), dtype=np.float32)
        
        for b in range(bands):
            if feedback.isCanceled():
                return {}
            
            band = input_ds.GetRasterBand(b + 1)
            image_data[:, :, b] = band.ReadAsArray()
            
            feedback.setProgress(int((b + 1) / bands * 20))  # 0-20% for reading
        
        # Load spectral library
        feedback.pushInfo(f'Loading spectral library: {speclib_path}')
        spectra, spec_names, spec_wavelengths = self.load_spectral_library(speclib_path, feedback)
        
        if len(spectra) == 0:
            raise QgsProcessingException('No spectra found in spectral library')
        
        feedback.pushInfo(f'Loaded {len(spectra)} reference spectra')
        
        # List spectra mode - just print names and exit
        if list_spectra:
            feedback.pushInfo('')
            feedback.pushInfo('=' * 60)
            feedback.pushInfo(f'Available spectra in library ({len(spec_names)} total):')
            feedback.pushInfo('=' * 60)
            for i, name in enumerate(spec_names):
                feedback.pushInfo(f'  {i + 1:4d}: {name}')
            feedback.pushInfo('=' * 60)
            feedback.pushInfo('')
            feedback.pushInfo('Copy spectrum names from the list above into the')
            feedback.pushInfo('"Spectra filter" field to select specific spectra.')
            feedback.pushInfo('Use * as wildcard (e.g. "Kaolinite*" or "*alunite*").')
            feedback.pushInfo('Separate multiple filters with commas.')
            
            # Return empty - we didn't produce output
            input_ds = None
            return {}
        
        # Apply spectra filter
        if spec_filter:
            spectra, spec_names = self.filter_spectra(
                spectra, spec_names, spec_filter, feedback
            )
            if len(spectra) == 0:
                raise QgsProcessingException(
                    f'No spectra matched the filter: "{spec_filter}". '
                    f'Check the "List available spectra names" option to see available names.'
                )
        
        num_spectra = len(spectra)
        feedback.pushInfo(f'Using {num_spectra} reference spectra for classification')
        
        # Get image wavelengths and resample spectra if needed
        image_wavelengths = self.get_wavelengths(input_ds, bands, feedback)
        
        if spec_wavelengths is not None and image_wavelengths is not None:
            # Detect and correct wavelength unit mismatch (micrometres vs nanometres)
            spec_max = np.max(spec_wavelengths)
            image_max = np.max(image_wavelengths)
            
            if spec_max < 100 and image_max > 100:
                # Library in micrometres, image in nanometres
                feedback.pushInfo(
                    f'Wavelength unit mismatch detected: library appears to be in micrometres '
                    f'({spec_wavelengths[0]:.4f}-{spec_wavelengths[-1]:.4f}), '
                    f'image in nanometres ({image_wavelengths[0]:.1f}-{image_wavelengths[-1]:.1f}). '
                    f'Converting library wavelengths to nanometres (x1000).'
                )
                spec_wavelengths = spec_wavelengths * 1000.0
            elif spec_max > 100 and image_max < 100:
                # Library in nanometres, image in micrometres
                feedback.pushInfo(
                    f'Wavelength unit mismatch detected: library appears to be in nanometres '
                    f'({spec_wavelengths[0]:.1f}-{spec_wavelengths[-1]:.1f}), '
                    f'image in micrometres ({image_wavelengths[0]:.4f}-{image_wavelengths[-1]:.4f}). '
                    f'Converting library wavelengths to micrometres (/1000).'
                )
                spec_wavelengths = spec_wavelengths / 1000.0
            
            # Check if resampling is needed
            if len(spec_wavelengths) != bands or not np.allclose(spec_wavelengths, image_wavelengths, atol=0.5):
                feedback.pushInfo(
                    f'Resampling {len(spec_wavelengths)}-band reference spectra '
                    f'to match {bands}-band image wavelengths...'
                )
                resampled_spectra = []
                for i, (spectrum, name) in enumerate(zip(spectra, spec_names)):
                    resampled = resample_spectrum(spectrum, spec_wavelengths, image_wavelengths)
                    valid_count = np.sum(~np.isnan(resampled))
                    feedback.pushInfo(
                        f'  {name}: {len(spectrum)} -> {valid_count} valid bands after resampling'
                    )
                    if valid_count == 0:
                        feedback.reportError(
                            f'Warning: spectrum "{name}" has no valid bands after resampling. '
                            f'Check wavelength ranges (library: {spec_wavelengths[0]:.1f}-{spec_wavelengths[-1]:.1f}, '
                            f'image: {image_wavelengths[0]:.1f}-{image_wavelengths[-1]:.1f})'
                        )
                    resampled_spectra.append(resampled)
                spectra = resampled_spectra
            else:
                feedback.pushInfo('Spectral library and image wavelengths match - no resampling needed')
        elif spec_wavelengths is None and image_wavelengths is not None:
            feedback.reportError(
                'Warning: No wavelength information in spectral library. '
                'Cannot resample. Spectra must already match image bands.'
            )
            # Verify band counts match
            for i, (spectrum, name) in enumerate(zip(spectra, spec_names)):
                if len(spectrum) != bands:
                    raise QgsProcessingException(
                        f'Band count mismatch: spectrum "{name}" has {len(spectrum)} bands '
                        f'but image has {bands} bands. Spectral library needs wavelength '
                        f'information in the header row for automatic resampling.'
                    )
        elif spec_wavelengths is not None and image_wavelengths is None:
            feedback.reportError(
                'Warning: No wavelength metadata in input image. '
                'Cannot resample. Spectra must already match image bands.'
            )
            for i, (spectrum, name) in enumerate(zip(spectra, spec_names)):
                if len(spectrum) != bands:
                    raise QgsProcessingException(
                        f'Band count mismatch: spectrum "{name}" has {len(spectrum)} bands '
                        f'but image has {bands} bands. Image needs wavelength metadata '
                        f'for automatic resampling.'
                    )
        else:
            # No wavelength info anywhere - just check band counts
            for i, (spectrum, name) in enumerate(zip(spectra, spec_names)):
                if len(spectrum) != bands:
                    raise QgsProcessingException(
                        f'Band count mismatch: spectrum "{name}" has {len(spectrum)} bands '
                        f'but image has {bands} bands. Add wavelength information to both '
                        f'the spectral library and image for automatic resampling.'
                    )
        
        # Create output rule image
        feedback.pushInfo('Creating output rule image...')
        driver = gdal.GetDriverByName('GTiff')
        rule_ds = driver.Create(
            output_rules_path,
            cols, rows, num_spectra,
            gdal.GDT_Float32
        )
        
        # Copy geotransform and projection
        rule_ds.SetGeoTransform(input_ds.GetGeoTransform())
        rule_ds.SetProjection(input_ds.GetProjection())
        
        # Process each reference spectrum
        for spec_idx, (spectrum, spec_name) in enumerate(zip(spectra, spec_names)):
            if feedback.isCanceled():
                return {}
            
            feedback.pushInfo(f'Processing spectrum {spec_idx + 1}/{num_spectra}: {spec_name}')
            
            # Create similarity map for this spectrum
            similarity_map = np.zeros((rows, cols), dtype=np.float32)
            
            # Process each pixel
            total_pixels = rows * cols
            for row in range(rows):
                if feedback.isCanceled():
                    return {}
                
                for col in range(cols):
                    pixel_spectrum = image_data[row, col, :]
                    similarity_map[row, col] = diff_func(pixel_spectrum, spectrum)
                
                # Update progress (20-100%)
                progress = 20 + int(((spec_idx * rows + row + 1) / (num_spectra * rows)) * 80)
                feedback.setProgress(progress)
            
            # Write this band to the output
            out_band = rule_ds.GetRasterBand(spec_idx + 1)
            out_band.WriteArray(similarity_map)
            out_band.SetDescription(spec_name)
            out_band.FlushCache()
        
        # Clean up
        rule_ds = None
        input_ds = None
        
        feedback.pushInfo('SAM analysis complete!')
        
        results = {self.OUTPUT_RULES: output_rules_path}
        
        # If classification output is requested, create it
        if output_class_path:
            feedback.pushInfo('Creating classification image...')
            self.create_classification(output_rules_path, output_class_path, 
                                      spec_names, mode, feedback)
            results[self.OUTPUT_CLASS] = output_class_path
        
        return results

    def filter_spectra(self, spectra, spec_names, filter_string, feedback):
        """
        Filter spectra by name using comma-separated patterns with wildcard support.
        
        Supports:
        - Exact names: "Kaolinite_KGa-1_TXCb"
        - Wildcards: "Kaolinite*", "*alunite*", "Actinolite_HS116.*"
        - Comma-separated: "Kaolinite*,Alunite*,Calcite*"
        - Index ranges: "1-10" or "1,5,10" (1-based)
        - Case-insensitive matching
        
        Returns:
            tuple: (filtered_spectra, filtered_names)
        """
        import fnmatch
        
        patterns = [p.strip() for p in filter_string.split(',') if p.strip()]
        
        if not patterns:
            return spectra, spec_names
        
        # Check if patterns are numeric indices
        selected_indices = set()
        has_name_patterns = False
        
        for pattern in patterns:
            # Check for index range like "1-10"
            if '-' in pattern and all(part.strip().isdigit() for part in pattern.split('-', 1)):
                parts = pattern.split('-', 1)
                start = int(parts[0]) - 1  # Convert to 0-based
                end = int(parts[1])        # End is inclusive, so no -1
                for idx in range(max(0, start), min(end, len(spectra))):
                    selected_indices.add(idx)
            elif pattern.isdigit():
                idx = int(pattern) - 1  # Convert to 0-based
                if 0 <= idx < len(spectra):
                    selected_indices.add(idx)
            else:
                has_name_patterns = True
        
        # Match by name patterns (case-insensitive)
        if has_name_patterns:
            for i, name in enumerate(spec_names):
                for pattern in patterns:
                    if pattern.isdigit() or (
                        '-' in pattern and 
                        all(p.strip().isdigit() for p in pattern.split('-', 1))
                    ):
                        continue  # Skip numeric patterns, already handled
                    if fnmatch.fnmatch(name.lower(), pattern.lower()):
                        selected_indices.add(i)
                        break
        
        # Build filtered lists maintaining original order
        sorted_indices = sorted(selected_indices)
        filtered_spectra = [spectra[i] for i in sorted_indices]
        filtered_names = [spec_names[i] for i in sorted_indices]
        
        feedback.pushInfo(f'Spectra filter: "{filter_string}"')
        feedback.pushInfo(f'Matched {len(filtered_spectra)} of {len(spectra)} spectra:')
        for name in filtered_names:
            feedback.pushInfo(f'  - {name}')
        
        return filtered_spectra, filtered_names

    def load_spectral_library(self, speclib_path, feedback):
        """
        Load spectral library from file.
        
        Supports two formats:
        1. ENVI spectral library (.sli with companion .hdr) - binary format read via GDAL
        2. CSV text format (.csv, .txt) - wavelengths in header row, spectra in subsequent rows
        
        Returns:
            tuple: (spectra list, spec_names list, wavelengths array or None)
        """
        ext = os.path.splitext(speclib_path)[1].lower()
        
        # Try ENVI format first for .sli and .hdr files, or if CSV loading fails
        if ext in ['.sli', '.hdr']:
            return self.load_envi_spectral_library(speclib_path, feedback)
        elif ext in ['.csv', '.txt']:
            return self.load_csv_spectral_library(speclib_path, feedback)
        else:
            # Unknown extension - try ENVI first, then CSV
            feedback.pushInfo(f'Unknown file extension "{ext}", trying ENVI format first...')
            try:
                result = self.load_envi_spectral_library(speclib_path, feedback)
                if len(result[0]) > 0:
                    return result
            except Exception:
                pass
            feedback.pushInfo('ENVI format failed, trying CSV format...')
            return self.load_csv_spectral_library(speclib_path, feedback)

    def load_envi_spectral_library(self, speclib_path, feedback):
        """
        Load an ENVI spectral library (.sli with companion .hdr).
        
        ENVI spectral library format:
        - samples = number of wavelength channels (e.g. 2151)
        - lines = number of spectra (e.g. 402)
        - bands = 1
        - data type = 4 (float32)
        - byte order = 0 (little-endian) or 1 (big-endian)
        - wavelength list has entries matching the samples count
        - spectra names lists the name for each line (spectrum)
        - No-data value is typically -1.23e34
        
        Tries GDAL first, falls back to direct binary reading if GDAL fails
        or returns unexpected dimensions.
        
        Returns:
            tuple: (spectra list, spec_names list, wavelengths array or None)
        """
        # Resolve .sli and .hdr file paths
        sli_path, hdr_path = self.resolve_envi_paths(speclib_path, feedback)
        
        if hdr_path is None:
            raise QgsProcessingException(
                f'Cannot find ENVI header file (.hdr) for: {speclib_path}'
            )
        if sli_path is None:
            raise QgsProcessingException(
                f'Cannot find ENVI data file (.sli) for: {speclib_path}'
            )
        
        feedback.pushInfo(f'ENVI data file: {sli_path}')
        feedback.pushInfo(f'ENVI header file: {hdr_path}')
        
        # Parse the .hdr file
        hdr = self.parse_envi_header(hdr_path, feedback)
        
        num_samples = hdr.get('samples', 0)
        num_lines = hdr.get('lines', 0)
        data_type = hdr.get('data_type', 4)
        byte_order = hdr.get('byte_order', 0)
        header_offset = hdr.get('header_offset', 0)
        spec_wavelengths = hdr.get('wavelengths', None)
        raw_names = hdr.get('spectra_names', [])
        
        if num_samples == 0:
            raise QgsProcessingException('Header has samples = 0')
        
        # Determine numpy dtype from ENVI data type and byte order
        envi_dtypes = {
            1: 'u1', 2: 'i2', 3: 'i4', 4: 'f4', 5: 'f8',
            12: 'u2', 13: 'u4', 14: 'i8', 15: 'u8'
        }
        base_dtype = envi_dtypes.get(data_type, 'f4')
        endian = '<' if byte_order == 0 else '>'
        dtype = np.dtype(f'{endian}{base_dtype}')
        bytes_per_value = dtype.itemsize
        
        feedback.pushInfo(
            f'Header: {num_samples} samples x {num_lines} lines, '
            f'data type {data_type} ({dtype}), byte order {byte_order}'
        )
        
        # Determine actual number of spectra from file size
        file_size = os.path.getsize(sli_path) - header_offset
        bytes_per_spectrum = num_samples * bytes_per_value
        actual_spectra = file_size // bytes_per_spectrum
        
        if actual_spectra != num_lines:
            feedback.pushInfo(
                f'Note: header says {num_lines} lines but file contains '
                f'{actual_spectra} spectra based on file size. Using {actual_spectra}.'
            )
            num_lines = actual_spectra
        
        if spec_wavelengths is not None:
            feedback.pushInfo(
                f'Spectral library wavelengths: {spec_wavelengths[0]:.4f} - '
                f'{spec_wavelengths[-1]:.4f} ({len(spec_wavelengths)} channels)'
            )
        
        feedback.pushInfo(f'Reading {num_lines} spectra with {num_samples} channels...')
        
        # Try GDAL first
        spectra = []
        gdal_success = False
        
        try:
            ds = gdal.Open(sli_path, gdal.GA_ReadOnly)
            if ds is not None:
                gdal_samples = ds.RasterXSize
                gdal_lines = ds.RasterYSize
                gdal_bands = ds.RasterCount
                
                if gdal_samples == num_samples and gdal_lines == num_lines and gdal_bands == 1:
                    band = ds.GetRasterBand(1)
                    data = band.ReadAsArray()
                    if data is not None:
                        if data.ndim == 1:
                            data = data.reshape(1, -1)
                        # Replace ENVI no-data (-1.23e34) with NaN
                        data = data.astype(np.float64)
                        data[data < -1e30] = np.nan
                        
                        for i in range(data.shape[0]):
                            spectra.append(data[i, :])
                        gdal_success = True
                        feedback.pushInfo(f'Read {len(spectra)} spectra via GDAL')
                else:
                    feedback.pushInfo(
                        f'GDAL dimensions ({gdal_samples}x{gdal_lines}x{gdal_bands}) '
                        f'differ from header ({num_samples}x{num_lines}x1), '
                        f'falling back to direct read'
                    )
                ds = None
        except Exception as e:
            feedback.pushInfo(f'GDAL read failed ({str(e)}), falling back to direct read')
        
        # Fallback: read binary directly
        if not gdal_success:
            feedback.pushInfo('Reading binary data directly...')
            with open(sli_path, 'rb') as f:
                if header_offset > 0:
                    f.seek(header_offset)
                raw = f.read()
            
            data = np.frombuffer(raw, dtype=dtype).reshape(num_lines, num_samples)
            data = data.astype(np.float64)
            data[data < -1e30] = np.nan
            
            for i in range(data.shape[0]):
                spectra.append(data[i, :])
            feedback.pushInfo(f'Read {len(spectra)} spectra via direct binary read')
        
        # Assign names
        spec_names = []
        for i in range(len(spectra)):
            if i < len(raw_names):
                spec_names.append(raw_names[i])
            else:
                spec_names.append(f'Spectrum_{i + 1}')
        
        feedback.pushInfo(
            f'Loaded {len(spectra)} spectra with {num_samples} channels '
            f'({len(raw_names)} named in header)'
        )
        
        return spectra, spec_names, spec_wavelengths

    def resolve_envi_paths(self, speclib_path, feedback):
        """
        Resolve the .sli data file and .hdr header file paths from
        whichever file the user selected.
        
        Returns:
            tuple: (sli_path, hdr_path) - either may be None if not found
        """
        base = os.path.splitext(speclib_path)[0]
        ext = os.path.splitext(speclib_path)[1].lower()
        
        if ext == '.hdr':
            hdr_path = speclib_path
            # Find companion data file
            sli_path = None
            for data_ext in ['.sli', '.dat', '.img', '.bin', '']:
                candidate = base + data_ext
                if os.path.exists(candidate) and candidate != speclib_path:
                    sli_path = candidate
                    break
        elif ext == '.sli':
            sli_path = speclib_path
            # Find companion header file
            hdr_path = base + '.hdr'
            if not os.path.exists(hdr_path):
                hdr_path = None
        else:
            sli_path = speclib_path
            hdr_path = base + '.hdr'
            if not os.path.exists(hdr_path):
                hdr_path = None
        
        return sli_path, hdr_path

    def parse_envi_header(self, hdr_path, feedback):
        """
        Parse an ENVI .hdr file and extract key fields.
        
        Returns dict with keys: samples, lines, bands, data_type, byte_order,
        header_offset, wavelengths, spectra_names, wavelength_units
        """
        result = {
            'samples': 0, 'lines': 0, 'bands': 1,
            'data_type': 4, 'byte_order': 0, 'header_offset': 0,
            'wavelengths': None, 'spectra_names': [], 'wavelength_units': None
        }
        
        with open(hdr_path, 'r') as f:
            content = f.read()
        
        # Parse simple key = value pairs
        import re
        for key, result_key, convert in [
            ('samples', 'samples', int),
            ('lines', 'lines', int),
            ('bands', 'bands', int),
            ('data type', 'data_type', int),
            ('byte order', 'byte_order', int),
            ('header offset', 'header_offset', int),
        ]:
            match = re.search(rf'^{key}\s*=\s*(\S+)', content, re.MULTILINE)
            if match:
                try:
                    result[result_key] = convert(match.group(1))
                except ValueError:
                    pass
        
        # Parse wavelength units
        match = re.search(r'^wavelength units\s*=\s*(.+)', content, re.MULTILINE)
        if match:
            result['wavelength_units'] = match.group(1).strip()
        
        # Parse multi-line brace-delimited fields
        def parse_braced_list(field_name):
            """Extract contents between { } for a given field."""
            pattern = rf'{field_name}\s*=\s*\{{([^}}]*)\}}'
            match = re.search(pattern, content, re.DOTALL)
            if match:
                return match.group(1)
            return None
        
        # Parse wavelengths
        wl_str = parse_braced_list('wavelength')
        if wl_str:
            try:
                wavelengths = [float(w.strip()) for w in wl_str.split(',') if w.strip()]
                result['wavelengths'] = np.array(wavelengths)
            except ValueError:
                feedback.reportError('Could not parse wavelengths from header')
        
        # Parse spectra names
        names_str = parse_braced_list('spectra names')
        if names_str:
            names = [n.strip() for n in names_str.split(',') if n.strip()]
            result['spectra_names'] = names
        
        return result

    def load_csv_spectral_library(self, speclib_path, feedback):
        """
        Load spectral library from CSV text file.
        
        Format expected:
        - First line: wavelengths (e.g., "wavelength,400,450,500,..." or just "400,450,500,...")
        - Following lines: spectrum_name, values...
        
        Returns:
            tuple: (spectra list, spec_names list, wavelengths array or None)
        """
        spectra = []
        spec_names = []
        spec_wavelengths = None
        
        try:
            with open(speclib_path, 'r') as f:
                lines = f.readlines()
                
                if len(lines) < 2:
                    raise QgsProcessingException('Spectral library file is too short')
                
                # First line should be wavelengths
                header_parts = lines[0].strip().split(',')
                
                # Try to parse wavelengths from header
                # Skip first element if it's a label like "wavelength"
                wl_values = []
                start_idx = 0
                try:
                    float(header_parts[0])
                except ValueError:
                    start_idx = 1  # First element is a label, skip it
                
                try:
                    wl_values = [float(x) for x in header_parts[start_idx:]]
                    if len(wl_values) > 0:
                        spec_wavelengths = np.array(wl_values)
                        feedback.pushInfo(
                            f'Spectral library wavelengths: {spec_wavelengths[0]:.1f} - '
                            f'{spec_wavelengths[-1]:.1f} nm ({len(spec_wavelengths)} bands)'
                        )
                except ValueError:
                    feedback.reportError('Could not parse wavelengths from spectral library header')
                    spec_wavelengths = None
                
                # Read spectra
                for i, line in enumerate(lines[1:]):
                    parts = line.strip().split(',')
                    if len(parts) < 2:
                        continue
                    
                    spec_name = parts[0].strip()
                    try:
                        spectrum = np.array([float(x) for x in parts[1:]])
                        spectra.append(spectrum)
                        spec_names.append(spec_name)
                    except ValueError:
                        feedback.reportError(f'Skipping invalid spectrum at line {i+2}')
                        continue
        
        except Exception as e:
            raise QgsProcessingException(f'Failed to load spectral library: {str(e)}')
        
        return spectra, spec_names, spec_wavelengths

    def create_classification(self, rules_path, output_path, class_names, mode, feedback):
        """
        Create classification image from rule image.
        
        Assigns each pixel to the class with minimum distance (for SAM, ED, etc.)
        or maximum similarity (depending on the measure).
        """
        feedback.pushInfo('Generating classification from rules...')
        
        # Open rule image
        rules_ds = gdal.Open(rules_path, gdal.GA_ReadOnly)
        cols = rules_ds.RasterXSize
        rows = rules_ds.RasterYSize
        num_classes = rules_ds.RasterCount
        
        # Read all rule bands
        rules_data = np.zeros((rows, cols, num_classes), dtype=np.float32)
        for b in range(num_classes):
            band = rules_ds.GetRasterBand(b + 1)
            rules_data[:, :, b] = band.ReadAsArray()
        
        # Find best class for each pixel (minimum distance for SAM, ED, BC, etc.)
        # Note: For some measures, we want minimum; for others, maximum
        reverse = mode in ['max']  # Adjust based on similarity measure
        
        if reverse:
            best_class = np.argmax(rules_data, axis=2) + 1  # +1 to reserve 0 for unclassified
        else:
            best_class = np.argmin(rules_data, axis=2) + 1
        
        # Create classification image
        driver = gdal.GetDriverByName('GTiff')
        class_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Byte)
        class_ds.SetGeoTransform(rules_ds.GetGeoTransform())
        class_ds.SetProjection(rules_ds.GetProjection())
        
        # Write classification
        class_band = class_ds.GetRasterBand(1)
        class_band.WriteArray(best_class.astype(np.uint8))
        class_band.SetDescription('Classification')
        
        # Set class names as metadata
        class_band.SetCategoryNames(['Unclassified'] + class_names)
        
        class_band.FlushCache()
        class_ds = None
        rules_ds = None
        
        feedback.pushInfo(f'Classification saved to {output_path}')

    def get_wavelengths(self, dataset, num_bands, feedback):
        """Extract wavelength information from dataset metadata."""
        
        # Try ENVI metadata first
        metadata = dataset.GetMetadata('ENVI')
        if metadata and 'wavelength' in metadata:
            wl_str = metadata['wavelength']
            wl_str = wl_str.strip('{}')
            try:
                wavelengths = np.array([float(w.strip()) for w in wl_str.split(',')])
                if len(wavelengths) == num_bands:
                    feedback.pushInfo(
                        f'Image wavelengths: {wavelengths[0]:.1f} - '
                        f'{wavelengths[-1]:.1f} nm ({len(wavelengths)} bands from ENVI metadata)'
                    )
                    return wavelengths
            except Exception:
                pass
        
        # Try band descriptions
        wavelengths = []
        for b in range(num_bands):
            band = dataset.GetRasterBand(b + 1)
            desc = band.GetDescription()
            try:
                wav = float(desc)
                wavelengths.append(wav)
            except (ValueError, TypeError):
                wavelengths.append(None)
        
        if None not in wavelengths and len(wavelengths) == num_bands:
            wl_arr = np.array(wavelengths)
            feedback.pushInfo(
                f'Image wavelengths: {wl_arr[0]:.1f} - '
                f'{wl_arr[-1]:.1f} nm ({len(wl_arr)} bands from band descriptions)'
            )
            return wl_arr
        
        feedback.reportError('No wavelength metadata found in input image.')
        return None

    def name(self):
        """Algorithm name for use in the processing framework."""
        return 'sam'

    def displayName(self):
        """Human-readable algorithm name."""
        return 'Spectral Angle Mapper (SAM)'

    def group(self):
        """Group for the algorithm in the Processing toolbox."""
        return 'Classification'

    def groupId(self):
        """Group ID for the algorithm."""
        return 'classification'

    def shortHelpString(self):
        """Short help/description of the algorithm."""
        return """
        <b>Spectral Angle Mapper (SAM) Classification</b>
        
        <p>SAM is a physically-based spectral classification that uses an n-dimensional 
        angle to match pixels to reference spectra. The algorithm determines the 
        spectral similarity between two spectra by calculating the angle between 
        the spectra, treating them as vectors in a space with dimensionality equal 
        to the number of bands.</p>
        
        <p><b>Inputs:</b></p>
        <ul>
        <li><b>Input Hyperspectral Image:</b> Multi-band raster (typically >10 bands)</li>
        <li><b>Spectral Library:</b> ENVI spectral library (.sli/.hdr) or CSV text file</li>
        <li><b>List available spectra names:</b> Check this to list all spectra in the 
        library without running SAM. Useful for finding names to use in the filter.</li>
        <li><b>Spectra filter:</b> Select specific spectra from the library. Leave empty 
        to use all spectra. Supports:
          <ul>
          <li>Exact names: <code>Kaolinite_KGa-1_TXCb</code></li>
          <li>Wildcards: <code>Kaolinite*</code>, <code>*alunite*</code></li>
          <li>Multiple patterns: <code>Kaolinite*,Alunite*,Calcite*</code></li>
          <li>Index numbers (1-based): <code>1,5,10</code></li>
          <li>Index ranges: <code>1-10</code></li>
          <li>Mixed: <code>Kaolinite*,1-5,Alunite*</code></li>
          </ul>
        Matching is case-insensitive.</li>
        <li><b>Similarity Measure:</b> Method for comparing spectra</li>
        </ul>
        
        <p><b>Outputs:</b></p>
        <ul>
        <li><b>Rule Image:</b> Multi-band raster with similarity values for each reference spectrum</li>
        <li><b>Classification Image (optional):</b> Single-band raster with class assignments</li>
        </ul>
        
        <p><b>Similarity Measures:</b></p>
        <ul>
        <li><b>SAM:</b> Spectral Angle Mapper (angle between spectra) - insensitive to illumination</li>
        <li><b>BC:</b> Bray-Curtis Distance</li>
        <li><b>SID:</b> Spectral Information Divergence</li>
        <li><b>ED:</b> Euclidean Distance</li>
        <li><b>ID:</b> Intensity Difference</li>
        </ul>
        
        <p><b>Reference:</b> Kruse et al. (1993) "The Spectral Image Processing System (SIPS)"</p>
        
        <p><i>Ported from HyPy by Wim Bakker, University of Twente</i></p>
        """

    def createInstance(self):
        """Create a new instance of the algorithm."""
        return SpectralAngleMapperAlgorithm()
