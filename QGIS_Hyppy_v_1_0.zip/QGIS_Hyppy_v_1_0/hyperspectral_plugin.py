"""
Hyperspectral Analysis Tools - Main Plugin Class

This file is part of the QGIS_Hyppy_v_1.0 plugin.
Ported from HyPy (Hyperspectral Python) by Wim Bakker.

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
from qgis.PyQt.QtCore import QCoreApplication, QTranslator
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsApplication

from .hyppy_provider import HyppyProvider


class HyperspectralPlugin:
    """QGIS Plugin Implementation for QGIS_Hyppy_v_1.0."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        
        # Initialize processing provider
        self.provider = None

    def initProcessing(self):
        """Initialize Processing provider"""
        self.provider = HyppyProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        self.initProcessing()
        
        # Future: Add custom dock widgets or toolbars here
        # For example: Spectral library viewer, interactive display, etc.

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
